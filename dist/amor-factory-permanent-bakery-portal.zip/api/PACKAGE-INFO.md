# Amor Factory System — Permanent Bakery Portal (migration 0017)

Purely additive on top of 0001-0016 — six brand-new tables only:
store_portal_token, retur_request, retur_request_evidence,
mutasi_request, mutasi_request_evidence, special_order_attachment.

ONE permanent, no-login, token-based link per bakery store
(api/_store/?token=...), covering:
  - Konfirmasi Penerimaan (Reject lives inside it, never a standalone menu)
  - Pesanan Khusus (reuses the existing SpecialOrderService engine)
  - Retur (100% store financial burden — NEVER reduces the invoice,
    NEVER auto-adjusts Factory stock_ledger)
  - Mutasi Produk (NEVER changes Factory stock_ledger; dual
    confirmation; qty_received is the future-invoice-authoritative figure,
    immutable after completion)
  - Riwayat (read-only aggregate across all of the above, this store only)

Plus Admin-side controls: Portal Bakery token management
(Generate/Regenerate/Revoke, one-time-shown link), Retur Review
(Verify/Reject), Mutasi Review (discrepancy resolution).

The automatic Bakery email's CTA now points at this permanent link
instead of the old per-shipment /api/_receive/ link — which stays
completely untouched, so every historic email already sent keeps
working exactly as before. A store's first-ever notification doubles
as onboarding (embeds a one-click deep link); every later email is a
bare reminder, since the raw token can never be re-shown once issued.
