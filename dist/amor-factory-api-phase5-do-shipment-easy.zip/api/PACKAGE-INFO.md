# Amor Factory — Phase 5 Fast-Track Draft DO / Staged Shipment Package

INCREMENTAL update for an existing Phase 4 (FG/Packing) deployment. This
domain's document root is public_html/factory/ — extract this ZIP
positioned INSIDE public_html/factory/ so it merges into your existing
public_html/factory/api/. It overwrites code files but NEVER includes
app/config/config.php, so your database credentials are untouched.

**Start here**: dist/README-FIRST-CPANEL-PHASE5-DO-SHIPMENT.md (delivered
alongside this ZIP) has the full step-by-step, non-technical guide. No SQL.
No CLI.

Quick facts:
- Log in as ADMIN: api/_admin-login/ (same as Phase 1-4)
- Apply migration 0006: api/_upgrade/ (adds a new store-scoped unique key
  to the ALREADY EXISTING delivery_order table ALONGSIDE its original one
  — never replacing it — plus lifecycle/attribution columns to
  delivery_order and shipment/shipment_item. Additive only, no table
  dropped, no Phase 0-4 data touched)
- Use Draft DO / Shipment: api/_do-uat/ (requires ADMIN login; temporary —
  delete this folder once Phase 5 is reviewed and accepted)
- ONE store produces ONE Delivery Order per day (identity = tanggal+store
  only), which can be shipped in MULTIPLE staged shipments (MAIN/PASTRY/
  OTHER or any other group label) — never a separate DO per shipment group.
- FG stock ONLY decreases on a real, confirmed SHIP action — creating,
  previewing, or preprinting a DO never touches stock_ledger.
- DO NOT YET IMPLEMENTED: shipment void/cancel-after-shipped (see the
  phase's own report for this residual risk — prefer safe omission over
  an unsafe delete), Invoice, Payment, Receivable aging, Return, Reject,
  store receipt confirmation, or any cutover of the live Apps
  Script/Sheets frontend to MySQL.
