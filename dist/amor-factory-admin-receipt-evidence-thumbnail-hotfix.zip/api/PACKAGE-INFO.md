# Amor Factory System — Admin Receipt Evidence Thumbnail Hotfix

FILES-ONLY hotfix. No new migration (0009 stays as the last one applied —
same schema as the previous Store Receipt Photo/Submit UX hotfix left it).

Quick facts:
- Admin -> Konfirmasi Toko -> Detail's "Bukti Foto dari Toko" now always
  renders a bounded 96x96px thumbnail (never the raw photo at natural
  size), with a defensive max-width/max-height cap on top.
- Clicking a thumbnail opens a bounded lightbox (max-width:90vw,
  max-height:80vh, object-fit:contain) with a close button, Escape, and
  click-outside-to-close — replacing the previous default of opening the
  raw image URL in a new tab.
- The Admin UI's shared layout (tokens.css/app.css/app.js) is now
  cache-busted (ADMIN_ASSET_VERSION), so a stale cached asset on a real
  device can no longer mask this fix.
- NO business rule change: receipt quantities/status, evidence ownership
  (Store-only upload, Admin-only view+verify), verification rules, and
  every server-side validation are all byte-for-byte unchanged (verified
  — see the diff sanity checks in this build script).
- This package does NOT touch stock deduction, Dispatch Claim/Release
  concurrency, receipt confirm math validation, the DO receipt QR token
  mechanism, email logic, PO/Production/FG business logic, User
  Management, Invoice preview, Surat Jalan print, or the Store-side
  receipt page itself.
