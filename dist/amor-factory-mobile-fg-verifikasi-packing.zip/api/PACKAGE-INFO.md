# Amor Factory System — Mobile-First FG Verifikasi + Packing per Toko

Code-only rework on top of the already-deployed FG Live UI Hotfix
package. Migration 0014 is already LIVE — this package adds NO new
migration, touches NO schema, and calls NO new backend endpoint.

## What changed

FG is split into two steps on the same page (?step=verifikasi default,
?step=packing):

- **FG Verifikasi** — mobile-first stacked cards (no wide table, no
  horizontal scroll) for both Per Produk (fgVerified/reject/hilang/
  notes/Sesuai — Packing removed entirely, moved to its own step) and
  Breakdown Toko (same fields, per store, also as cards).
- **FG Packing** — NEW, defaults to per-Toko: a store chip selector
  (product count / target pcs / status) plus a store detail view
  submitted ONE STORE AT A TIME. Packing Sesuai auto-fills Actual
  Packing to Ready Verified (this store's own fgVerified), never the
  raw PO target — mirroring the existing, unchanged PACKED_EXCEEDS_
  VERIFIED server rule, never a new formula.

A product still verified in default Per Produk mode (never exploded via
Breakdown Toko) still shows up in Packing — it has a real Regular PO
store-level target from Phase 2 PO import, independent of FG's own
explode step — but read-only, with an explanatory note, excluded from
its store's progress totals and from any "Submit Packing" payload (it
cannot be packed yet, and trying would attempt to split an existing
nonzero Per Produk number across stores, which the backend correctly
refuses to guess at).

## Genuine backend bug found and fixed

FgService::batchProductStores()'s "only stores with target > 0" filter
had an exception for a store that "already has real data" — but
explodeToStores() creates a real (all-zero) fg_item row for EVERY store,
including target=0 ones, so exploding ANY product reopened the exact bug
the prior hotfix closed (a target=0 store reappearing). Fixed: the
exception now requires the existing row to carry a real nonzero qty/
packed/reject/hilang value.

## What did NOT change

Shipment allocation logic, stock ledger logic, store_fg_balance locking,
the Regular shipment guard, special reservation logic, DO business
rules, and Production logic are all byte-for-byte unchanged (enforced by
this build script's own diff sanity checks). No new API endpoint.

## Testing

Full existing regression suite (PDFG/FG-STORE/REGSTORE/ALLOC-GLOBAL/
FINAL/ALLOC and every earlier Phase 0-5.5 suite) re-run, 100% green. New
RECON-01..08 (product-vs-store PO target reconciliation) and MOBILE-FG-
01..18 (a real headless-Chromium mobile-viewport (390x844) smoke test,
plus a desktop-viewport re-check) all pass: no horizontal scroll on
either step, Sesuai/Tidak Sesuai behavior on both Verifikasi and
Packing, store-selector scoping, the packing-cannot-exceed-ready-
verified rule (both the client auto-fill and the server-authoritative
rejection), submit-one-store-never-another, correct progress totals, and
no double counting between the two steps.
