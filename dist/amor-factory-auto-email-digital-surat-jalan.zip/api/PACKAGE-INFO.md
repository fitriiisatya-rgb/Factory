# Amor Factory System — Automatic Bakery Email / Digital Surat Jalan / Admin Resend

Adds ONE additive migration (0009 — store.email + shipment_email_delivery).
Everything else in the schema is unchanged.

Quick facts:
- The moment a REAL shipment departs, its store's registered email (if
  any) automatically receives a message linking to that ONE shipment's
  Digital Surat Jalan / Store Receipt page — never the whole DO.
- A missing store email never blocks a departure. An SMTP failure can
  never roll back a shipment or its stock deduction.
- Admin sees Email status (Belum Dikirim/Terkirim/Gagal/Email Toko Belum
  Diisi) separately from Penerimaan status on the existing Konfirmasi
  Toko Detail page, with a Kirim Ulang Email action.
- Resend reuses the SAME outbox row and NEVER creates a new shipment,
  stock movement, or store receipt, and never alters the DO.
- Master Data -> Toko now has an inline email editor (uses the existing
  PUT /api/stores/{id} endpoint).
- The Store photo-evidence rule (Store uploads, Admin only views/
  verifies) from the previous patch is UNCHANGED.
- SMTP credentials live only in config.php/environment — never in the
  database, never in this ZIP, never in a log or API response.
- This package does NOT touch stock deduction, Dispatch Claim/Release
  concurrency, receipt confirm math validation, the DO receipt QR token
  mechanism, PO/Production/FG business logic, User Management, Invoice
  preview, or Surat Jalan print.
