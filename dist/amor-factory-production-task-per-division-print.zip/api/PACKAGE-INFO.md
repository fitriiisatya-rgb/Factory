# Amor Factory System — Task per Divisi + Production Actual/Reject + Print

ONE NEW MIGRATION (0011) — additive only. Adds exactly 2 new columns
(special_order_item.aktual_produksi/reject_produksi) — no table is
created, altered elsewhere, renamed, or dropped.
production_item.reject already existed since the very first schema; this
package only wires up its write path (Ceklis Produksi's own PATCH
endpoint), it does not add a column for it.

Quick facts:
- New "Task per Divisi" tab on Produksi consolidates PO Reguler + Pesanan
  Khusus Toko + Pesanan Non-Toko demand into one read-only task list per
  division — every source stays traceable (badge + reference), never
  merged into an opaque total. Replacement Reject is listed as a source
  but shows zero rows until that module exists (never fabricated).
- Target=required good output, Actual=GOOD output only, Reject=tracked
  separately, Sisa=max(0, Target-Actual) — Reject is NEVER subtracted
  from Sisa.
- PO Reguler rows are READ-ONLY in Task per Divisi (edited only via the
  existing Ceklis Produksi, which now also has a Reject Produksi input
  column next to Actual). Pesanan Khusus/Non-Toko rows ARE editable here
  (their only home for actual/reject entry) via a new
  POST /api/special-orders/{id}/actual endpoint.
- Print Divisi Ini / Print Semua Divisi: A4 LANDSCAPE, printer-friendly
  (white background, black text, no dark theme), one division per page
  for "Semua Divisi". Physical backup only — never a second source of
  truth; the system stays authoritative.
- Reuses the EXISTING dark navy Admin UI and the EXISTING print.css
  document system exactly.
