# Amor Factory System — Driver Route Navigation / History / Logout Hotfix

FILES-ONLY INCREMENTAL patch for an existing Phase 5.5 + User Management +
FG Source Refresh + Driver UX/Shipment Tracing deployment. NO DATABASE
MIGRATION in this package.

Quick facts:
- A departed "Rute Saya" stop now opens Detail Pengiriman directly (one
  shipment) or a "Pengiriman untuk <toko>" chooser (more than one — e.g.
  MAIN + PASTRY) — it never again opens "Konfirmasi Berangkat" for a
  stop with nothing left to confirm.
- Riwayat cards and the Logout button were re-verified to already work
  correctly in this code (real headless-browser click test) — this
  package additionally cache-busts driver.css/driver.js/app.js so a
  browser (or a partial extract) can never keep serving stale copies.
- If a driver opens an old departure link after the shipment already
  went out, the screen now says "Pengiriman ini sudah diberangkatkan."
  with a real "Lihat Detail Pengiriman" button instead of a dead-end
  "Tidak ada klaim aktif" message.
- This package does NOT touch stock deduction, Dispatch Claim/Release
  concurrency, Store Receipt business rules, QR token logic, PO/
  Production/FG business logic, User Management, or Invoice preview.
