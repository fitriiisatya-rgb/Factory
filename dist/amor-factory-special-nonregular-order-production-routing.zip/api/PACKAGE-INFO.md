# Amor Factory System — Pesanan Khusus Toko / Pesanan Non-Toko + Production Routing

FILES + ONE NEW MIGRATION (0010). Adds exactly 3 new tables
(special_order, special_order_item, special_order_catalog) — no existing
table is altered, renamed, or dropped.

Quick facts:
- PO Reguler Toko is a completely separate, untouched demand source
  (po_batch/po_item/po_store_item are never read or written by this
  feature).
- Pesanan Khusus Toko (from a store, outside its regular PO) and Pesanan
  Non-Toko (Konsumen Langsung/CS/Sales Executive/Umum) share the same
  underlying tables (source_type column) but stay fully traceable.
- Every order item carries its own division_id, resolved at creation time
  (existing product -> product.division_id; special/custom item -> the
  catalog's own division_id) — a multi-division order routes PER ITEM,
  never forced into one bucket.
- A new "Cake & Custom" division (Karangtengah) and its DELUXE
  KARAKTER/ICING catalog are lazily created on first use — never baked
  into the migration's DDL, so this works correctly on both a fresh
  database and an already-seeded live one.
- Charge is an explicit per-item field; subtotal = qty*unitPrice + charge.
  Store pricing (50%/60% rules) is completely untouched.
- Production's new "Order Masuk / Demand Tambahan" inbox groups items by
  division, shows a read-only special note, and computes FG shortage
  READ-ONLY against the existing stock_balance table — it never reserves
  or writes stock (see the OUTPUT REPORT's known deferred enhancements
  for why a full reservation engine was deliberately not built).
- Reuses the EXISTING dark navy Admin UI exactly (kpi-card, data-table,
  btn, field, badge, alert classes) — app.css is byte-for-byte unchanged.
