# Amor Factory System — Integrasi finhub (migrations up to 0022)

Migration 0022 is purely additive: one new table, integration_api_key.

- Pengaturan → Integrasi finhub: Admin creates/revokes the key finhub uses.
- GET /api/integration/v1/shipments (X-Api-Key): read-only feed of departed
  shipments and what each store confirmed. See INTEGRASI-FINHUB.md.
- Includes everything from the Invoice per DO release (0021) and the faster
  FG & Packing page.

A server still at 0016-0021 is brought to 0022 by api/_upgrade/.
