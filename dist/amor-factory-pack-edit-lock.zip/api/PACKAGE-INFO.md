# Amor Factory System — Lock Packing After Submit + Edit/Resubmit Flow

UI-ONLY change on top of the already-deployed Real Persisted Packing
Submission State package (amor-factory-pack-submit-state.zip / migration
0015). NO NEW MIGRATION — nothing to run in cPanel beyond deploying these
files; migration 0015 stays the latest and is byte-for-byte unchanged.

## Why

Even with migration 0015's real submission state, a submitted store's
Reject/Hilang/Keterangan/Packing fields remained directly editable in the
UI with no explicit Edit action — confusing and unsafe operationally on
the phone-first Packing screen used live on the factory floor.

## What changed

- fg-packing.php's Packing detail view now genuinely LOCKS all fields
  (Sesuai/Tidak Sesuai, Actual Packing, Reject, Hilang, Keterangan) once
  a store shows Sudah Disubmit or Perlu Submit Ulang, replacing the
  disabled-but-still-focusable Submit Packing button with a plain
  "✓ Sudah Disubmit" status and a secondary "Edit Packing" action.
- "Edit Packing" always confirms first ("Packing toko ini sudah
  disubmit. Apakah Anda ingin melakukan koreksi?" / Batal / Ya, Edit
  Packing) — clicking it and cancelling never changes persisted state.
- Confirming shows a clear "MODE EDIT — Sedang Dikoreksi" indicator and
  unlocks the fields; "Batal Edit" discards local edits with no server
  call; "Simpan Perubahan" saves via the EXISTING generic PATCH
  /api/fg/{id} endpoint.
- No new endpoint and no new authorization rule were needed: the prior
  pass's own FgService::applyStoreRow() + patchDraft() real-change
  detection already flips a submitted store to 'stale' ONLY when a value
  genuinely changes (never on an identical resave), and already runs
  under the same Auth::requireRole() gate as every other FG write — this
  pass's own new tests (PACK-EDIT-07/08/10/11/13/16) exist specifically
  to prove that server-side behavior, unchanged, already satisfies this
  pass's "no UI-only locking" requirement.
- A stale ("Perlu Submit Ulang") store shows an active "Submit Ulang
  Packing <Store>" button; resubmitting uses the EXISTING POST
  /api/fg/{id}/packing-submit endpoint, then locks again.

## What did NOT change

FgService.php, FgRepository.php, FgController.php, App.php, and every
DO/Production/Special Order/shipment/reservation file are byte-for-byte
unchanged (enforced by this build script's own diff sanity checks).
Editing/resubmitting Packing per Store still never posts stock_ledger,
never decrements stock, never creates a shipment, and never touches
store_fg_balance's physical quantity — the separate, whole-document
"Submit FG (Semua Toko)" finalization action is completely untouched.

## Testing

Full existing regression suite re-run, 100% green. New PACK-EDIT-01..16
(a real headless-Chromium click-through at 390px mobile width covering
the full lock -> confirm -> Edit Packing -> MODE EDIT -> Batal Edit
no-op -> real change + dirty indicator -> Simpan Perubahan -> Perlu
Submit Ulang -> reload persistence -> Submit Ulang Packing -> locked
Sudah Disubmit again -> Store B unaffected -> no horizontal scroll flow,
plus server-level no-op-never-stale / real-change-always-stale /
concurrent-version-conflict / unauthorized-role-rejected proofs) all
pass. The pre-existing PACK-SUBMIT-01..10 suite was updated only to
target this pass's new #fg-resubmit-packing-store id (the resubmit
button on an already-locked/stale store) rather than the first-time-only
#fg-submit-packing-store id — a pure test-selector update to match the
new, intentional button-id scheme, not an application regression.
