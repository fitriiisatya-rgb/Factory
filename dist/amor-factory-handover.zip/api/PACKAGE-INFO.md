# Amor Factory System — Serah Terima Produksi -> FG (migrations up to 0025)

Migration 0025 is additive: two new tables (production_handover,
production_handover_item). No existing row or column changes.

- Divisions can fill production before the PO exists ("Mau produksi
  apa?" search adds own-division products); a PO upload adds its products
  to open sheets automatically.
- "Serah terima ke FG": hand over part of what is done, several times a
  day; correct/take back until FG checks it.
- FG: inbox "Serah terima dari produksi" (Cek: received qty, reject with
  reason). A new handover reopens a submitted FG document automatically.
- Ringkasan FG: "Posisi barang hari ini" (masih di produksi / menunggu
  cek / diterima FG / dipacking, reject saat serah terima).
- Includes everything up to 0024 (Runchise).

A server at 0016-0024 is brought to 0025 by api/_upgrade/.
