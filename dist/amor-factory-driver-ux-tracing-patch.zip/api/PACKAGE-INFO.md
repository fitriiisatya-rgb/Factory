# Amor Factory System — Driver Portal UX + Shipment Tracing Patch

FILES-ONLY INCREMENTAL patch for an existing Phase 5.5 + User Management +
FG Source Refresh deployment. NO DATABASE MIGRATION in this package.

Quick facts:
- "KONFIRMASI BERANGKAT" now shows exactly ONE centered confirmation
  dialog (never stacked/unstyled), disables its own button and shows
  "Memproses..." while the request is in flight, and the success screen
  shows the real Shipment ID, product/qty totals, and departure time.
- "Rute Saya" now shows the REAL shipped product/qty totals after
  departure (it used to show 0 produk / 0 pcs — a real bug, now fixed).
- "Riwayat" cards are now clickable and open a new read-only "Detail
  Pengiriman" page with the full shipment + receipt trace. A driver can
  only open a shipment THEY shipped — opening another driver's shipment
  is refused (403).
- Dates/times are now shown Indonesian-friendly in Asia/Jakarta (e.g.
  "21 Sep 2026 · 10:20") instead of the raw database format. Nothing
  stored changes — display only.
- A Logout button was added to the Driver Portal topbar.
- This package does NOT touch PO, Production semantics, Driver Claim/
  Release concurrency rules, Dispatch Pool, ShipmentService's own stock
  deduction, Store Receipt business rules, QR token logic, Invoice
  preview, Return/Reject logic, or User Management.
