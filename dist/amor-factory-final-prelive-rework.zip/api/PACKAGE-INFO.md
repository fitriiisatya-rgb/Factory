# Amor Factory System — Final Pre-Live Rework of migration 0012

Migration 0012 was STILL UNAPPLIED to any live database when this rework
started (confirmed) — this is the FINAL, corrected version of 0012, not a
new 0013. Purely additive on top of 0011.

What this rework connects (on top of the prior "Special/Non-Regular
Fulfillment Completion" pass, which already created a REAL shipment on
every dispatch):

- Normalized downstream source identity (Amor\Api\SpecialOrder\
  NormalizedSourceType): SPECIAL_STORE_ORDER / CS_ORDER / SALES_ORDER /
  DIRECT_CUSTOMER / GENERAL_ORDER, derived ONLY from the real, audited
  special_order.source_type/non_store_source ENUM values — never inferred
  from customer name text.
- Shipment-line read model (Amor\Api\Dispatch\ShipmentLineResolver):
  normalizes shipment_item (Regular) and special_order_do_shipment_item
  (special) behind one shape, for Driver History/Detail, Digital Surat
  Jalan, and the Bakery receipt screen — never a fabricated shipment_item
  row for a custom/catalog item.
- Driver History/Detail now include special-order-sourced shipments (real
  product/qty totals, not 0).
- Digital Surat Jalan renders for a special shipment too (Source, Drop
  Bakery, Delivery Method, Driver-or-Courier), reusing the SAME print
  template/QR architecture — a NEW shipment_receipt_token table gives it
  its own QR when there's no owning delivery_order_id.
- Automatic Bakery email now fires for BOTH DRIVER_INTERNAL departure and
  EXTERNAL_COURIER handover, addressed to the DROP BAKERY (never the
  customer/CS/Sales name) — outbox row created inside the same commit as
  the shipment, SMTP attempted strictly AFTER commit (a failure can never
  roll back the shipment/FG/DO write).
- The public receive portal (ReceiptService::getPublicView/confirmReceipt)
  now resolves EITHER a Regular DO token OR a special shipment token,
  trying the Regular path FIRST and completely unchanged — every existing
  Regular receipt link already sent by email keeps working byte-for-byte.
- shipment_receipt_item widened (shipment_item_id/product_id now
  nullable, + special_order_do_shipment_item_id/item_name_snapshot) so a
  custom/catalog item's receipt line references its REAL special line,
  never a fake shipment_item row.
- Admin Pengiriman + Admin Konfirmasi Toko show a clear Sumber badge
  (PO Reguler / Pesanan Khusus Toko / CS / Sales / Konsumen Langsung /
  Umum) and Delivery Method on every row.

Deferred by design, documented (not a silent gap): Phase 6 invoice
calculations (source_type + order reference are already retained on every
special DO/shipment for a future per-source invoice), and "Rute Saya"
multi-stop sequencing for special orders (a special_order_do has exactly
one destination by construction — DO-level claim, not a pooled per-store
route stop — so route sequencing is a Regular-PO-only concept by design).
