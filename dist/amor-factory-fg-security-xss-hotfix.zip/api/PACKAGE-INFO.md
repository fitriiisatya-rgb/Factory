# Amor Factory System — FG Security Hotfix (escape all dynamic FG UI output)

Code-only security hotfix on top of the already-deployed Mobile-First FG
Verifikasi + Packing per Toko package. Migration 0014 is already LIVE —
this package adds NO new migration, touches NO schema, calls NO new
backend endpoint, and changes NO business logic.

## What changed

api/app/ui/pages/fg-packing.php built several HTML strings by
concatenating untrusted dynamic values (store name, product name,
Keterangan/notes, an API-derived status label, API error messages via
e.message) directly into innerHTML, with only an incomplete ad hoc
`.replace(/"/g, '&quot;')` in a couple of spots. A store/product name or
a user-entered Keterangan containing HTML/script markup rendered as real
markup, not literal text — a stored-XSS surface.

A single `escHtml()` helper (escapes &, <, >, ", ') now guards every one
of those sites consistently: the Breakdown Toko renderer
(buildVerifikasiStoreBlock), the Packing store chips (renderChips), the
Packing store detail cards (renderDetail), and both steps' own
fetch-failure error banners (which previously inserted `e.message`
straight into innerHTML). Numeric-only values (ids, target/verified/
packed quantities) are never escaped.

Amor.toast() and Amor.confirmModal() in assets/js/app.js already
rendered their message/body via `el.textContent` (never innerHTML) —
confirmed safe, unchanged.

## What did NOT change

No business logic, no database schema, no migration, no Production/
Shipment/Stock/Reservation logic. The pre-existing "a product verified
only in Per Produk mode must first be Breakdown Toko'd before it can be
packed per store" rule is completely unchanged. Enforced by this build
script's own byte-for-byte diff sanity checks.

## Testing

Full existing regression suite re-run, 100% green. New FG-XSS-01..05 (a
real headless-Chromium check against a fixture whose store name is
`<script>alert(1)</script>`, product name is
`<img src=x onerror=alert(1)>`, and Keterangan is
`"><img src=x onerror=alert(1)>`) confirm every payload renders as inert
literal text in FG Verifikasi's Breakdown Toko and FG Packing's per-Toko
view (both as rendered text and as an input's exact `.value`), that no
live `<script>`/`<img onerror>` element is ever created, that no
alert()/confirm()/prompt() dialog ever fires, and that a forced API error
message containing markup renders as plain text too. A normal Indonesian
Keterangan containing "&" rides along in the same fixture and is
confirmed to render completely unchanged.
