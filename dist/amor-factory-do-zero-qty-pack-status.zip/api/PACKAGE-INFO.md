# Amor Factory System — DO Zero-Qty Cleanup + Packing Submit Status

Code-only live UAT hotfix on top of the already-deployed FG Security XSS
Hotfix package. Migration 0014 is already LIVE — this package adds NO
new migration and touches NO schema.

## Bug 1 — zero-qty DO items (screen + print)

Root cause: DoTargetService::storeDemandByProduct() (used by
createDraft()/refreshFromPo()) had no po_awal/po_revisi > 0 filter,
unlike its own sibling methods — every product in a day's PO template
got a real, persisted delivery_order_item row, whether or not a given
store actually ordered any of it that day. Fixed at the query layer so
a NEW DO never gets a zero-planned row inserted again, plus a display-
layer safety net in DoService::buildDoDto() (screen AND print share this
one DTO) that hides any item with plannedQty<=0 AND alreadyShippedQty<=0
— fixing an ALREADY-CREATED live DO immediately, no backfill needed. A
historical line with real shipped_qty is never hidden. Totals and
shipment logic are unaffected.

## Bug 2 — unambiguous Packing submit status

Packing-per-Toko's "Selesai" status was ambiguous between "the numbers
look complete" and "this was actually submitted". Audited: packed_qty
only ever changes via a successful "Submit Packing [Store]" PATCH, so
reaching a store's own target already IS real, submitted data — the
real gap was an unsaved edit made AFTER reaching that state still
showing the old "complete" label. Fixed with a purely client-side
"dirty" flag (no new persisted field, no new backend state machine): a
store now shows an unmistakable, disabled "✓ Sudah Disubmit" badge
and button exactly when packed_qty covers the full target AND nothing
is unsaved on top of it; touching any input reverts it to an active
"Submit Packing" button until the next successful submit (or fresh page
load) confirms it again. No per-store submitted-by/at metadata is shown
or invented — only the whole document's own batch-level submitted_by/
submitted_at exists in the schema.

## What did NOT change

Shipment allocation, stock ledger, store_fg_balance, the Regular
shipment guard, special reservation logic, DO business rules,
Production logic, and the pre-existing "Per Produk must be Breakdown
Toko'd before packing per store" rule are all byte-for-byte unchanged
(enforced by this build script's own diff sanity checks). No new API
endpoint.

## Testing

Full existing regression suite re-run, 100% green. New DO-UI-01..05
(a real DO reproducing DO/KRM/006/IX/2026's own shape — 1 real item + 6
legacy zero-planned rows — verified hidden on both the rendered screen
and the real print-do.php page, with a historical shipped-qty line
proven never hidden) and PACK-STATUS-01..08 (a real headless-Chromium
click through "Submit Packing", confirming the chip and action area
both switch to Sudah Disubmit, persist across a real page reload, never
affect another store, and a double-submit never doubles packed_qty or
posts stock) all pass.
