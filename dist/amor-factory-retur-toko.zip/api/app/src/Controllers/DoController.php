<?php

declare(strict_types=1);

namespace Amor\Api\Controllers;

use Amor\Api\AdminScope;
use Amor\Api\ApiException;
use Amor\Api\Auth;
use Amor\Api\Database;
use Amor\Api\Delivery\DoRepository;
use Amor\Api\Delivery\DoService;
use Amor\Api\Delivery\ShipmentService;
use Amor\Api\Idempotency;
use Amor\Api\Mail\ShipmentEmailService;
use Amor\Api\Request;
use Amor\Api\Response;
use PDO;

/**
 * JSON API for the Phase 5 Draft DO / staged Shipment module. Mirrors
 * ProductionController/FgController's shape (auth -> service call ->
 * Response::json for reads, Idempotency::handle wrapping a transaction for
 * writes).
 */
final class DoController
{
    private const EDITOR_ROLES = ['ADMIN', 'PPIC', 'PRODUCTION'];

    public static function preview(Request $request): void
    {
        Auth::requireAuth();
        $tanggal = self::requireDate($request->query('date'));
        $storeId = self::requireInt($request->query('storeId'), 'storeId');
        $service = new DoService(Database::pdo());
        Response::json($service->loadPreview($tanggal, $storeId));
    }

    public static function stores(Request $request): void
    {
        Auth::requireAuth();
        $tanggal = self::requireDate($request->query('date'));
        $factoryId = self::requireInt($request->query('factoryId'), 'factoryId');
        $service = new DoService(Database::pdo());
        Response::json($service->storesWithPo($tanggal, $factoryId));
    }

    public static function index(Request $request): void
    {
        Auth::requireAuth();
        $service = new DoService(Database::pdo());
        $tanggal = $request->query('date');
        $factoryId = $request->query('factoryId') !== null ? (int) $request->query('factoryId') : null;
        if ($tanggal !== null && $factoryId !== null) {
            Response::json($service->listDosForFactory($tanggal, $factoryId));
            return;
        }
        $list = $service->listDos(
            $tanggal,
            $request->query('storeId') !== null ? (int) $request->query('storeId') : null,
            $request->query('status')
        );
        if (Auth::isFactoryAdmin()) {
            $pdo = Database::pdo();
            $list = array_values(array_filter($list, static fn ($d) => array_intersect(AdminScope::doFactoryIds($pdo, (int) $d['doId']), Auth::adminFactoryScope()) !== []));
        }
        Response::json($list);
    }

    /** Admin Pabrik: the DO must hold some of their factory's goods (no-op for everyone else). */
    private static function guardDo(int $doId): void
    {
        AdminScope::requireAny(AdminScope::doFactoryIds(Database::pdo(), $doId));
    }

    public static function show(Request $request): void
    {
        Auth::requireAuth();
        $id = (int) $request->routeParams['id'];
        self::guardDo($id);
        $service = new DoService(Database::pdo());
        Response::json($service->getDo($id));
    }

    public static function shipments(Request $request): void
    {
        Auth::requireAuth();
        $id = (int) $request->routeParams['id'];
        $pdo = Database::pdo();
        $repo = new DoRepository();
        self::guardDo($id);
        $shipments = $repo->findShipmentsForDo($pdo, $id);
        $out = [];
        foreach ($shipments as $sh) {
            if (!AdminScope::visible(isset($sh['factory_id']) ? (int) $sh['factory_id'] : null)) {
                continue;
            }
            $sh['items'] = $repo->findShipmentItems($pdo, (int) $sh['shipment_id']);
            $out[] = $sh;
        }
        Response::json($out);
    }

    public static function history(Request $request): void
    {
        Auth::requireAuth();
        $pdo = Database::pdo();
        $limit = $request->query('limit') !== null ? (int) $request->query('limit') : 50;

        $sql = "SELECT h.* FROM audit_log h
                INNER JOIN delivery_order o ON CAST(h.record_key AS UNSIGNED) = o.delivery_order_id
                WHERE h.record_type = 'delivery_order'
                  AND " . (Auth::isFactoryAdmin() ? 'EXISTS (SELECT 1 FROM delivery_order_item oi INNER JOIN product p ON p.product_id = oi.product_id INNER JOIN division d ON d.division_id = p.division_id WHERE oi.delivery_order_id = o.delivery_order_id AND ' . Auth::adminFactorySql('d.factory_id') . ')' : '1=1');
        $params = [];
        if ($request->query('date') !== null) {
            $sql .= ' AND o.tanggal = ?';
            $params[] = $request->query('date');
        }
        if ($request->query('storeId') !== null) {
            $sql .= ' AND o.store_id = ?';
            $params[] = (int) $request->query('storeId');
        }
        $sql .= ' ORDER BY h.event_at DESC LIMIT ' . max(1, min(500, $limit));

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        Response::json($stmt->fetchAll());
    }

    public static function create(Request $request): void
    {
        $userId = Auth::requireRole(...self::EDITOR_ROLES);
        $tanggal = self::requireDate($request->input('tanggal'));
        $storeId = self::requireInt($request->input('storeId'), 'storeId');

        Idempotency::handle($request, 'POST /api/do', function (PDO $pdo) use ($userId, $tanggal, $storeId) {
            $service = new DoService($pdo);
            $dto = $service->createDraft($tanggal, $storeId, $userId);
            return [
                'status' => 200,
                'envelope' => ['ok' => true, 'data' => $dto],
                'recordType' => 'delivery_order',
                'recordKey' => (string) $dto['doId'],
            ];
        });
    }

    public static function generateBulk(Request $request): void
    {
        $userId = Auth::requireRole(...self::EDITOR_ROLES);
        $tanggal = self::requireDate($request->input('tanggal'));
        $factoryId = self::requireInt($request->input('factoryId'), 'factoryId');

        Idempotency::handle($request, 'POST /api/do/generate-bulk', function (PDO $pdo) use ($userId, $tanggal, $factoryId) {
            $service = new DoService($pdo);
            $dto = $service->generateBulk($tanggal, $factoryId, $userId);
            return [
                'status' => 200,
                'envelope' => ['ok' => true, 'data' => $dto],
                'recordType' => 'delivery_order_bulk',
                'recordKey' => $tanggal . '|' . $factoryId,
            ];
        });
    }

    public static function preprint(Request $request): void
    {
        $userId = Auth::requireRole(...self::EDITOR_ROLES);
        $id = (int) $request->routeParams['id'];
        self::guardDo($id);
        $expectedVersion = self::requireInt($request->input('expectedVersion'), 'expectedVersion');

        Idempotency::handle($request, 'POST /api/do/{id}/preprint', function (PDO $pdo) use ($request, $userId, $id, $expectedVersion) {
            $service = new DoService($pdo);
            $dto = $service->preprint($id, $expectedVersion, $userId, $request->header('Idempotency-Key'));
            return ['status' => 200, 'envelope' => ['ok' => true, 'data' => $dto], 'recordType' => 'delivery_order', 'recordKey' => (string) $id];
        });
    }

    public static function refreshPo(Request $request): void
    {
        $userId = Auth::requireRole(...self::EDITOR_ROLES);
        $id = (int) $request->routeParams['id'];
        self::guardDo($id);
        $expectedVersion = self::requireInt($request->input('expectedVersion'), 'expectedVersion');

        Idempotency::handle($request, 'POST /api/do/{id}/refresh-po', function (PDO $pdo) use ($request, $userId, $id, $expectedVersion) {
            $service = new DoService($pdo);
            $dto = $service->refreshFromPo($id, $expectedVersion, $userId, $request->header('Idempotency-Key'));
            return ['status' => 200, 'envelope' => ['ok' => true, 'data' => $dto], 'recordType' => 'delivery_order', 'recordKey' => (string) $id];
        });
    }

    public static function cancel(Request $request): void
    {
        $userId = Auth::requireRole(...self::EDITOR_ROLES);
        $id = (int) $request->routeParams['id'];
        AdminScope::requireAll(AdminScope::doFactoryIds(Database::pdo(), $id), 'DO ini berisi barang dari 2 pabrik — pembatalannya hanya oleh Leader Admin.');
        $expectedVersion = self::requireInt($request->input('expectedVersion'), 'expectedVersion');
        $reason = (string) $request->input('reason', '');

        Idempotency::handle($request, 'POST /api/do/{id}/cancel', function (PDO $pdo) use ($request, $userId, $id, $expectedVersion, $reason) {
            $service = new DoService($pdo);
            $dto = $service->cancel($id, $expectedVersion, $reason, $userId, $request->header('Idempotency-Key'));
            return ['status' => 200, 'envelope' => ['ok' => true, 'data' => $dto], 'recordType' => 'delivery_order', 'recordKey' => (string) $id];
        });
    }

    public static function shipmentPreview(Request $request): void
    {
        Auth::requireRole(...self::EDITOR_ROLES);
        $id = (int) $request->routeParams['id'];
        self::guardDo($id);
        $items = (array) $request->input('items', []);
        $service = new ShipmentService(Database::pdo());
        Response::json($service->preview($id, $items));
    }

    /**
     * Live-UAT lifecycle-consistency fix: this manual "Kirim" action creates
     * a real shipment exactly like Dispatch\DepartureService's driver-claim
     * flow does, but previously skipped that flow's own email-outbox step —
     * leaving a genuinely departed shipment permanently reading "Belum
     * Dikirim" (no shipment_email_delivery row ever existed for it at all).
     * Fixed by mirroring Controllers\DispatchController::departures()'s own
     * pattern exactly: create the outbox row INSIDE the same transaction as
     * ship() (a row insert can't fail the way SMTP can), then attempt the
     * real send AFTER commit, best-effort (never turns a successful ship
     * into an error the user sees). On an exact Idempotency-Key replay,
     * $createdShipment stays null (the closure never re-runs), so no
     * duplicate email attempt ever fires for a replayed request.
     */
    public static function ship(Request $request): void
    {
        $userId = Auth::requireRole(...self::EDITOR_ROLES);
        $id = (int) $request->routeParams['id'];
        self::guardDo($id);
        $expectedVersion = self::requireInt($request->input('expectedVersion'), 'expectedVersion');
        $shipmentGroup = (string) $request->input('shipmentGroup', 'MAIN');
        $items = (array) $request->input('items', []);

        $createdShipment = null;
        Idempotency::handle($request, 'POST /api/do/{id}/ship', function (PDO $pdo) use ($request, $userId, $id, $expectedVersion, $shipmentGroup, $items, &$createdShipment) {
            $service = new ShipmentService($pdo);
            $dto = $service->ship($id, $expectedVersion, $shipmentGroup, $items, $userId, $request->header('Idempotency-Key'));
            $outbox = (new ShipmentEmailService())->createOutboxForShipment($pdo, (int) $dto['shipmentId'], (int) $dto['storeId']);
            $dto['emailOutboxId'] = $outbox['outboxId'];
            $createdShipment = $dto;
            return ['status' => 200, 'envelope' => ['ok' => true, 'data' => $dto], 'recordType' => 'delivery_order', 'recordKey' => (string) $id];
        });

        if ($createdShipment !== null && isset($createdShipment['emailOutboxId'])) {
            try {
                (new ShipmentEmailService())->attemptSend((int) $createdShipment['emailOutboxId'], $userId, $request->header('Idempotency-Key'));
            } catch (\Throwable $e) {
                error_log('ShipmentEmailService::attemptSend failed for outboxId=' . $createdShipment['emailOutboxId'] . ': ' . $e->getMessage());
            }
        }
    }

    private static function requireDate(?string $s): string
    {
        $s = (string) $s;
        $d = \DateTime::createFromFormat('Y-m-d', $s);
        if ($d === false || $d->format('Y-m-d') !== $s) {
            throw new ApiException(400, 'INVALID_DATE', "date must be a valid 'YYYY-MM-DD' date");
        }
        return $s;
    }

    private static function requireInt(mixed $v, string $field): int
    {
        if ($v === null || $v === '' || !is_numeric($v)) {
            throw new ApiException(400, 'MISSING_FIELD', "{$field} is required");
        }
        return (int) $v;
    }
}
