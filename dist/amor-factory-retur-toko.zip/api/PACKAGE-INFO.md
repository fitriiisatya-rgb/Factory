# Amor Factory System — Retur, Reject & Mutasi toko (migration 0026)

Run /api/_upgrade/ once after uploading (applies 0026; additive only).

- Portal Bakery "Retur & Reject": one transaction, many items (Retur /
  Reject / Mutasi), 30 master reject reasons, edit while waiting,
  history, A4 + thermal 80 mm proof print.
- ATASAN role (Head Store) with supervised stores: approval queue +
  dashboard. Stores without an Atasan are approved automatically.
- Admin "Retur, Reject & Mutasi": physical validation per item, dashboard,
  CSV export, master reject reasons.
- FG Verifikasi: Selisih updates while typing.
- Includes everything up to the Hari Ini package.
