# Amor Factory System — Production Division + FG & Packing Rework

ONE new migration in this package: 0014 (fg_item.reject_qty/hilang_qty
only). Everything else this rework needed already existed in the schema,
unused, since the original 0001 baseline — see the migration file's own
docblock for the full audit.

## What changed

1. User <-> Production Division / FG Factory access (many-to-many),
   wired into api/app/src/Auth.php + ProductionService + FgService, with
   an admin assignment UI in api/_users-uat/. OPT-IN: a user with zero
   assignment rows keeps today's unrestricted role-based access — nobody
   is locked out by deploying this package.
2. Ceklis Produksi (produksi.php) now shows PO Reguler AND Pesanan
   Khusus/Non-Toko in ONE worksheet per division/date, with Sesuai/Tidak
   Sesuai buttons (server-enforced, never a trusted disabled input alone),
   a derived "Perlu Review Ulang" badge when a submitted document's live
   target has drifted from a later PO revision, and an enhanced admin
   division dashboard (Target/Actual/Reject/Sisa/Status/Last Updated/
   Submitted By, zero-target divisions excluded from the outstanding-work
   count).
3. FG & Packing (Reguler) gains Sesuai/Tidak Sesuai for both Verified and
   Packing, independent Reject and Hilang columns (migration 0014's new
   fg_item columns), and a read-only Breakdown Toko view (per-store PO
   target reference) that can never double-count against the single
   Per Produk row it is derived from.
4. FG Sumber Khusus/Non-Toko gains Sesuai/Tidak Sesuai for its own
   Verifikasi FG step (Packing has never existed for this source and is
   NOT added here — disclosed scope decision, see the delivery report).

## What did NOT change

- PO Awal + latest Revisi (PB ignored) target formula — reused everywhere,
  never redefined.
- Production/FG snapshot semantics, optimistic-lock version columns,
  submit/reopen lifecycle, audit trail.
- Immediate production->FG visibility (already worked architecturally;
  FgTargetService sums SUBMITTED divisions per product, no "wait for all"
  gate existed before or after this change).
- DO creation before FG completeness, and the shipment ready-FG guard —
  both already correct, untouched.
- All existing FG reservation-safety logic (special/non-regular
  allocation, cross-flow guards) — completely untouched; Breakdown Toko
  never writes to fg_item's store dimension, so stock_ledger/stock_balance
  posting is byte-identical to before this rework.

24 new tests (PDFG-01..24) in ProductionDivisionFgReworkTest.php cover the
new RBAC scoping (both directions), sesuai/sesuaiVerified/sesuaiPacking
enforcement, the three-state (absent/true/false) backward-compat rule,
reject/hilang independence, and the store-breakdown endpoint's read-only
guarantee.
