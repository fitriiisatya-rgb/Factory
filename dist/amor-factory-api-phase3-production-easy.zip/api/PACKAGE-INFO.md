# Amor Factory — Phase 3 Fast-Track Production/SPK Actual Package

INCREMENTAL update for an existing Phase 2 (PO fast-track) deployment. This
domain's document root is public_html/factory/ — extract this ZIP
positioned INSIDE public_html/factory/ so it merges into your existing
public_html/factory/api/. It overwrites code files but NEVER includes
app/config/config.php, so your database credentials are untouched.

**Start here**: dist/README-FIRST-CPANEL-PHASE3-PRODUCTION.md (delivered
alongside this ZIP) has the full step-by-step, non-technical guide. No SQL.
No CLI.

Quick facts:
- Log in as ADMIN: api/_admin-login/ (same as Phase 1/2)
- Apply migration 0004: api/_upgrade/ (adds created_by/submitted_by/
  reopened_by/source_po_batch_version columns to the ALREADY EXISTING
  production_run table — additive only, no table dropped, no Phase 0/1/2
  data touched)
- Use Production/SPK actual: api/_production-uat/ (requires ADMIN login;
  temporary — delete this folder once Phase 3 is reviewed and accepted)
- api/_import-po/ is refreshed in this package too — it now shows "Toko
  unik terpetakan" (distinct stores) separately from "Kemunculan/baris toko
  terpetakan" (row occurrences). Every existing Phase 2 number/semantic/
  total is unchanged — this is a display-clarity fix only.
- Production actual here NEVER changes PO target — target is always read
  live from the Phase 2 PO module.
- Still NOT implemented: FG verification, Packing, DO, Shipment, Stock
  ledger business flow, Invoice, Payment, Return, Reject, or any cutover of
  the live Apps Script/Sheets frontend to MySQL.
