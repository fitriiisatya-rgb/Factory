# Amor Factory System — FG Live UI Hotfix (target=0 rows + Breakdown Toko rendering)

Code-only hotfix on top of the already-deployed Store-Specific FG
Reservation Guard package. Migration 0014 is already LIVE — this package
adds NO new migration and touches NO schema.

## BUG 1 — FG showed "Target FG (Hasil Produksi) = 0" for many products

Root cause: a division's production_item rows are seeded from its own
PO-derived template for a date — a product with a PO target nobody
actually produced that day still gets a row with aktual=0. Fixed:
  - FgTargetService::productionActualByProduct() and FgService's
    division-scoped re-aggregation now add HAVING SUM(aktual) > 0 —
    filtered at the query layer, never CSS.
  - FgService::isVisibleItem() + buildBatchDto() give this the SAME
    filter as a display-layer safety net, so an ALREADY-EXISTING live
    batch (created before this hotfix, with zero-target rows already
    persisted) is correct immediately — no backfill/cleanup migration.
  - batchProductStores()/storeBreakdown() also hide a store row with
    target <= 0, UNLESS that store already has real entered data (never
    silently hides genuine already-packed/shipped work — same
    "PO revision must not silently reclaim stock" rule as before).

## BUG 2 — "Breakdown Toko" button only changed CSS, no store rows rendered

Root cause: the top "Tampilan Data: Per Produk / Breakdown Toko" toggle
never called any API — it only flipped the two buttons' classes and
revealed an (empty) panel div. The real writable per-product store data
(GET /api/fg/{id}/items/{productId}/stores) was only ever fetched by a
SEPARATE per-row "Breakdown Toko" button elsewhere in the row.

Fixed: the toggle is rewired to enterBreakdownMode()/exitBreakdownMode():
clicking "Breakdown Toko" now fetches EVERY visible product's store rows
in parallel and renders them (Store, Product, Target Toko, Verified
Result, Actual Verified, Packing Result, Actual Packing, Reject, Hilang,
Keterangan, Status) in place of the Per Produk table. No manual "explode"
step is required first — a product not yet exploded still shows its live
PO-target rows at 0 (same data source the old per-row quick view already
used). The per-row button now enters the SAME mode and scrolls to that
product. Saving one product's Breakdown Toko block still PATCHes only
that product (unchanged endpoint/business logic) — switching modes can
never duplicate or double-count data.

## What did NOT change

Shipment allocation logic, stock ledger logic, store_fg_balance locking,
the Regular shipment guard, special reservation logic, DO business rules,
and Production logic are all byte-for-byte unchanged — see this build
script's own diff sanity checks. Landing Page, Invoice, Reports,
Replacement Reject, and Mutation Antar Toko were not touched.

## Testing

FG-UI-01/02/05/06 (query/API layer) verified via
ProductionDivisionFgReworkTest.php against a real fixture reproducing the
exact live bug (2026-09-26, Karangtengah, BOLLEN LILIT COKLAT=25 / CHOCO
CUBE 12=14, plus zero-actual padding products and a zero-target store).
FG-UI-03/04/07/08/09/10/11/12 (real browser/JS behavior — the exact layer
BUG 2 shipped in despite passing backend tests) verified via a real
headless-Chromium smoke check (run-ui-smoke-fg-breakdown-toko.mjs) against
the SAME live server+DB+batch: a real login, a real click on "Breakdown
Toko", and DOM inspection of the resulting store rows. Full existing
regression suite re-run, all green.
