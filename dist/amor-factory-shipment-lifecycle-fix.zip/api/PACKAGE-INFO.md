# Amor Factory System — Shipment / Driver / Receipt Lifecycle Consistency Fix

Live-UAT blocker fix (Abdul Gani case): CODE ONLY, no new migration.

## Root cause

A `shipment` row is ALWAYS created atomically with real shipped_by/
shipped_at by Delivery\ShipmentService::ship() — there is no draft/staged
shipment concept in this schema, so a receipt could never actually be
confirmed before a real shipment row existed. The confusing symptoms had
two real, separate causes:

1. Controllers\DoController::ship() (the manual "Kirim" admin button, a
   second entry point into ShipmentService::ship() alongside the Driver
   claim/departure flow) never created a shipment_email_delivery outbox
   row — so a genuinely departed shipment read "Belum Dikirim" forever.
2. Dispatch\ReceiptService::confirmReceiptForDo() returned a bare
   NOT_FOUND instead of a stable, distinct SHIPMENT_NOT_DISPATCHED code
   when a DO had never had a real shipment depart.

A DO that still shows *other, still-unshipped* line items in Driver
"Tersedia" after a *partial* manual ship is correct, by-design behavior
(remaining qty is computed per product) — not a bug.

## What changed

1. Controllers\DoController::ship() now creates the email outbox row
   inside the same transaction as ship() and attempts the send after
   commit, mirroring Controllers\DispatchController::departures()'s own
   pattern exactly.
2. Dispatch\ReceiptService::confirmReceiptForDo() now throws the stable
   SHIPMENT_NOT_DISPATCHED code (never a bare 404) when the targeted DO
   has no active shipment at all yet — a direct token/API call cannot
   bypass this by guessing a shipmentId, since no such row exists to find.
3. receipt.js's pre-dispatch empty state now reads "Belum Dikirim —
   konfirmasi penerimaan belum tersedia."

## What did NOT change

- PO, Production, FG, Packing, DO quantity logic, stock_ledger posting,
  Regular store FG ownership, Special allocation, Replacement allocation,
  Invoice — none of these files were touched (enforced by this build
  script's own sanity guards).
- Driver "Tersedia" query logic — already correctly excludes any product
  already shipped; no change was needed there.
- Email-independent dispatch gate — email failure never blocked dispatch
  or receipt before this fix, and still does not.

## Tests

SHIP-STATE-01..12 added to Phase55DispatchReceiptTest.php. Full
regression green: Phase 5.5 (107/107 tests, including the new
SHIP-STATE-01..12, plus the full P55-24 Phase 0-5 + UI + Print + Invoice
stack), and the PDFG/Special Order/Replacement Reject/FG-Allocation
cascade (123+35+35 tests, 0 failures).
