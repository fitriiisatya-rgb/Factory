<?php

declare(strict_types=1);

use Amor\Api\Fg\FgService;

$service = new FgService($pdo);

$existing = $pdo->prepare('SELECT fg_batch_id FROM fg_batch WHERE tanggal = ? AND factory_id = ?');
$existing->execute([$uiTanggal, $uiFactoryId]);
$existingId = $existing->fetchColumn();

$batchView = null;
$targetView = null;
$viewError = null;
try {
    // Check factory access up front. Without this, a PRODUCTION login with
    // no FG factory assigned could see the Per Produk list, but Breakdown
    // Toko and every save failed. That looked like lost work.
    try {
        \Amor\Api\Auth::requireFactoryAccess($uiFactoryId);
    } catch (\Amor\Api\ApiException $e) {
        throw new \RuntimeException(
            'Akun ini belum punya akses ke pabrik FG & Packing ini, jadi data FG tidak bisa dibuka atau disimpan. '
            . 'Login dengan akun FG pabrik ini (misalnya fg_cibadak / fg_karangtengah), atau minta Admin mencentang pabriknya '
            . 'di Manajemen User. Data yang sudah disimpan sebelumnya tetap aman.'
        );
    }
    if ($existingId !== false) {
        $batchView = $service->getBatch((int) $existingId);
    } else {
        $targetView = $service->loadTarget($uiTanggal, $uiFactoryId, null);
    }
} catch (\Throwable $e) {
    $viewError = $e->getMessage();
}

// MOBILE-FIRST REWORK — "FG Verifikasi" (per product, default) and "FG
// Packing" (per Toko, default) are now separate steps/views (task's own
// explicit "Split FG into two clear operational stages" requirement),
// switched via a plain query param (a real page navigation, not a hidden
// client-side state machine — simplest, most robust, and each step is
// independently bookmarkable/shareable). Packing operates on the SAME
// canonical fg_item rows Verifikasi's own Breakdown Toko already writes
// (GET/PATCH /api/fg/{id}/items/{productId}/stores — completely
// unchanged backend, see FgService::batchProductStores()'s own docblock)
// — there is still only ONE stored number per store row, so splitting the
// UI into two steps can never double-count or duplicate data.
$fgStep = (($_GET['step'] ?? 'verifikasi') === 'packing') ? 'packing' : 'verifikasi';

$selesaiDipacking = 0;
if ($batchView !== null) {
    foreach ($batchView['items'] as $it) {
        if ($it['packingStatusCode'] === 'selesai_dipacking') {
            $selesaiDipacking++;
        }
    }
}

function fgStepUrl(string $step, string $tanggal, int $factoryId): string
{
    return '/api/_ui-preview/?page=fg-packing&tanggal=' . urlencode($tanggal) . '&factoryId=' . $factoryId . '&step=' . $step;
}
?>
<?= ui_fg_tabs('fg-packing', $uiTanggal, $uiFactoryId) ?>
<div class="filter-bar">
  <form method="get" style="display:flex;gap:var(--space-3);align-items:flex-end;flex-wrap:wrap;">
    <input type="hidden" name="page" value="fg-packing">
    <input type="hidden" name="step" value="<?= ui_esc($fgStep) ?>">
    <div class="field"><label>Tanggal</label><input type="date" name="tanggal" value="<?= ui_esc($uiTanggal) ?>"></div>
    <div class="field"><label>Pabrik</label>
      <select name="factoryId">
        <?php foreach ($factories as $f): ?>
        <option value="<?= (int) $f['factory_id'] ?>" <?= $uiFactoryId === (int) $f['factory_id'] ? 'selected' : '' ?>><?= ui_esc($f['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <button type="submit" class="btn btn-primary">Terapkan</button>
  </form>
</div>

<?php if ($viewError !== null): ?>
<div class="alert alert-danger"><?= ui_esc($viewError) ?></div>
<?php endif; ?>

<?php
$rejectTotal = 0.0;
$hilangTotal = 0.0;
foreach ($batchView !== null ? $batchView['items'] : [] as $it) {
    $rejectTotal += $it['reject'] ?? 0.0;
    $hilangTotal += $it['hilang'] ?? 0.0;
}
?>
<?php if ($batchView !== null): ?>
<div class="kpi-grid">
  <?= ui_kpi_card(['label' => 'Hasil Produksi', 'value' => ui_fmt_num($batchView['summary']['productionActualTotal']), 'icon' => 'factory', 'color' => 'primary']) ?>
  <?= ui_kpi_card(['label' => 'FG Terverifikasi', 'value' => ui_fmt_num($batchView['summary']['fgVerifiedTotal']), 'icon' => 'box', 'color' => 'primary']) ?>
  <?= ui_kpi_card(['label' => 'Sudah Dipacking', 'value' => ui_fmt_num($batchView['summary']['packedTotal']), 'icon' => 'box', 'color' => 'success']) ?>
  <?= ui_kpi_card(['label' => 'Reject FG', 'value' => ui_fmt_num($rejectTotal), 'icon' => 'file', 'color' => $rejectTotal > 0 ? 'danger' : 'neutral']) ?>
  <?= ui_kpi_card(['label' => 'Hilang', 'value' => ui_fmt_num($hilangTotal), 'icon' => 'file', 'color' => $hilangTotal > 0 ? 'danger' : 'neutral']) ?>
  <?= ui_kpi_card(['label' => 'Selisih Produksi ke FG', 'value' => ui_fmt_num($batchView['summary']['varianceTotal']), 'icon' => 'file', 'color' => $batchView['summary']['varianceTotal'] < 0 ? 'warning' : 'neutral']) ?>
  <?= ui_kpi_card(['label' => 'Belum Diverifikasi', 'value' => (string) $batchView['summary']['jumlahBelumDiverifikasi'], 'icon' => 'file', 'color' => 'neutral']) ?>
  <?= ui_kpi_card(['label' => 'Sebagian Terverifikasi', 'value' => (string) $batchView['summary']['jumlahSebagianTerverifikasi'], 'icon' => 'file', 'color' => 'warning']) ?>
  <?= ui_kpi_card(['label' => 'Sesuai Produksi', 'value' => (string) $batchView['summary']['jumlahSesuaiProduksi'], 'icon' => 'file', 'color' => 'success']) ?>
  <?= ui_kpi_card(['label' => 'Selesai Dipacking', 'value' => (string) $selesaiDipacking, 'icon' => 'box', 'color' => 'success']) ?>
</div>

<div class="filter-bar">
  <div class="btn-group">
    <a class="btn btn-sm <?= $fgStep === 'verifikasi' ? 'btn-primary' : 'btn-secondary' ?>" href="<?= ui_esc(fgStepUrl('verifikasi', $uiTanggal, $uiFactoryId)) ?>">FG Verifikasi</a>
    <a class="btn btn-sm <?= $fgStep === 'packing' ? 'btn-primary' : 'btn-secondary' ?>" href="<?= ui_esc(fgStepUrl('packing', $uiTanggal, $uiFactoryId)) ?>">FG Packing</a>
  </div>
</div>

<div class="card section">
  <div class="card-head">
    <h2 class="card-title">Draft FG #<?= (int) $batchView['fgBatchId'] ?></h2>
    <?= ui_badge(ui_doc_status_label($batchView['status'])) ?>
  </div>
  <?php $editable = in_array($batchView['status'], ['draft', 'reopened'], true); ?>
  <?php
  // Production a division submitted AFTER this FG document was created is
  // not part of it until it is refreshed; say so instead of letting those
  // goods silently never reach FG stock.
  $lateRunsStmt = $pdo->prepare(
      "SELECT d.name FROM production_run pr INNER JOIN division d ON d.division_id = pr.division_id
       WHERE pr.tanggal = ? AND d.factory_id = ? AND pr.status = 'submitted'
         AND pr.production_run_id NOT IN (SELECT production_run_id FROM fg_batch_source WHERE fg_batch_id = ?)
       ORDER BY d.name"
  );
  $lateRunsStmt->execute([$uiTanggal, $uiFactoryId, (int) $batchView['fgBatchId']]);
  $lateRuns = $lateRunsStmt->fetchAll(PDO::FETCH_COLUMN);
  ?>
  <?php if ($lateRuns !== []): ?>
  <div class="alert alert-warning">
    <strong>Ada produksi yang belum masuk dokumen FG ini:</strong> <?= ui_esc(implode(', ', $lateRuns)) ?> (disubmit setelah FG dibuat).
    <?= $editable ? 'Klik <strong>Refresh Produksi Terbaru</strong> agar barangnya ikut diverifikasi.' : (array_intersect(['ADMIN', 'PPIC'], $ui['roles']) !== [] ? 'Buka kembali (Reopen) FG ini lalu Refresh Produksi Terbaru.' : 'Minta Admin membuka kembali FG ini agar barangnya bisa masuk.') ?>
  </div>
  <?php endif; ?>

  <?php if ($fgStep === 'verifikasi'): ?>
  <?php if ($batchView['sourceInconsistency']): ?>
  <div class="alert alert-warning">
    <strong>Ketidaksesuaian Sumber Produksi</strong> — salah satu Produksi sumber sudah berubah versi/dibuka kembali sejak FG ini dibuat/disegarkan. Data FG yang sudah diisi (FG Terverifikasi/Packed) TIDAK dihapus atau diubah otomatis.
    <div class="table-scroll" style="margin-top:var(--space-2);"><table class="data-table">
      <thead><tr><th>Production Run</th><th>Versi Tercatat</th><th>Versi Sekarang</th><th>Status Sekarang</th></tr></thead>
      <tbody>
      <?php foreach ($batchView['sourceInconsistencyDetails'] as $s): ?>
      <tr><td>#<?= (int) $s['productionRunId'] ?></td><td><?= (int) $s['storedVersion'] ?></td><td><?= (int) $s['currentVersion'] ?></td><td><?= ui_esc($s['currentStatus']) ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <?php if ($editable): ?>
    <button type="button" class="btn btn-primary" style="margin-top:var(--space-2);" id="btn-refresh-fg-source">Refresh Produksi Terbaru</button>
    <?php else: ?>
    <p style="margin-top:var(--space-2);color:var(--text-muted);">Dokumen ini sudah <strong>submitted</strong> — <?= array_intersect(['ADMIN', 'PPIC'], $ui['roles']) !== [] ? 'klik "Buka Kembali / Reopen" dulu' : 'minta Admin membuka kembali dokumen ini' ?> sebelum bisa Refresh Produksi Terbaru.</p>
    <?php endif; ?>
  </div>
  <?php elseif ($editable): ?>
  <button type="button" class="btn btn-secondary" style="margin-bottom:var(--space-3);" id="btn-refresh-fg-source">Refresh Produksi Terbaru</button>
  <?php endif; ?>

  <?php if ($batchView['summary']['jumlahMelebihiProduksi'] > 0): ?>
  <div class="alert alert-danger"><strong>Diblokir untuk Submit</strong> — <?= $batchView['summary']['jumlahMelebihiProduksi'] ?> produk punya FG Terverifikasi melebihi Hasil Produksi terbaru (lihat status "Melebihi Produksi"). Turunkan FG Terverifikasi produk tersebut dulu sebelum submit — sistem tidak pernah menurunkannya secara otomatis.</div>
  <?php endif; ?>

  <div style="display:flex;gap:var(--space-2);align-items:center;margin-bottom:var(--space-3);">
    <span style="font-size:var(--text-sm);color:var(--text-muted);">Tampilan:</span>
    <div class="btn-group">
      <button type="button" class="btn btn-sm btn-primary" id="fg-mode-produk">Per Produk</button>
      <button type="button" class="btn btn-sm btn-secondary" id="fg-mode-toko">Breakdown Toko</button>
    </div>
  </div>

  <form id="fg-form" data-batch-id="<?= (int) $batchView['fgBatchId'] ?>" data-expected-version="<?= (int) $batchView['version'] ?>" data-tanggal="<?= ui_esc($uiTanggal) ?>" data-factory-id="<?= $uiFactoryId ?>">
  <div class="fg-card-list fg-card-list-2col" id="fg-perproduk-wrap">
    <?php foreach ($batchView['items'] as $it): ?>
    <?php
      $isBreakdown = ($it['mode'] ?? 'perProduk') === 'breakdownToko';
      // Per Produk cells become DERIVED/read-only the moment a product is
      // exploded into store rows (Option A — see FgService::patchDraft()'s
      // own docblock) — "no double counting" is satisfied by construction
      // only if there is never a second place to type a number for the
      // same product at the same time.
      $rowEditable = $editable && !$isBreakdown;
      $verifiedIsSesuai = $rowEditable && abs($it['fgVerified'] - $it['productionActualSnapshot']) < 0.01 && $it['fgVerified'] > 0;
    ?>
    <div class="fg-card" data-product-id="<?= (int) $it['productId'] ?>">
      <div class="fg-card-title"><?= ui_esc($it['productName']) ?></div>
      <div class="fg-card-sub">
        Target FG (Hasil Produksi): <b><?= ui_fmt_num($it['productionActualSnapshot']) ?></b>
        · Available: <?= ui_fmt_num($it['available']) ?>
        · <?= ui_badge($isBreakdown ? 'Breakdown Toko (' . (int) $it['storeCount'] . ' Toko)' : 'Per Produk') ?>
      </div>

      <div class="fg-card-row">
        <span class="fg-card-row-label">Verifikasi</span>
        <?php if ($rowEditable): ?>
        <div class="btn-group fg-verified-sesuai-group" data-product-id="<?= (int) $it['productId'] ?>" data-target="<?= ui_esc((string) $it['productionActualSnapshot']) ?>" data-sesuai="<?= $verifiedIsSesuai ? '1' : '0' ?>">
          <button type="button" class="btn btn-sm <?= $verifiedIsSesuai ? 'btn-primary' : 'btn-secondary' ?>" data-value="sesuai">Sesuai</button>
          <button type="button" class="btn btn-sm <?= !$verifiedIsSesuai ? 'btn-danger' : 'btn-secondary' ?>" data-value="tidak_sesuai">Tidak Sesuai</button>
        </div>
        <?php else: ?><span style="color:var(--text-faint);">-</span><?php endif; ?>
      </div>
      <div class="fg-card-row">
        <span class="fg-card-row-label">FG Terverifikasi</span>
        <?php if ($rowEditable): ?><input type="number" step="0.01" min="0" class="fg-card-input" data-product-id="<?= (int) $it['productId'] ?>" data-field="fgVerified" value="<?= ui_num_input($it['fgVerified']) ?>" <?= $verifiedIsSesuai ? 'disabled' : '' ?>>
        <?php else: ?><b><?= ui_fmt_num($it['fgVerified']) ?></b><?php endif; ?>
      </div>
      <div class="fg-card-row"><span class="fg-card-row-label">Selisih</span><span><?= ui_fmt_num($it['variance']) ?></span></div>
      <div class="fg-card-row">
        <span class="fg-card-row-label">Reject</span>
        <?php if ($rowEditable): ?><input type="number" step="0.01" min="0" class="fg-card-input" data-product-id="<?= (int) $it['productId'] ?>" data-field="reject" value="<?= ui_num_input($it['reject'] ?? 0) ?>">
        <?php else: ?><?= ui_fmt_num($it['reject'] ?? 0) ?><?php endif; ?>
      </div>
      <div class="fg-card-row">
        <span class="fg-card-row-label">Hilang</span>
        <?php if ($rowEditable): ?><input type="number" step="0.01" min="0" class="fg-card-input" data-product-id="<?= (int) $it['productId'] ?>" data-field="hilang" value="<?= ui_num_input($it['hilang'] ?? 0) ?>">
        <?php else: ?><?= ui_fmt_num($it['hilang'] ?? 0) ?><?php endif; ?>
      </div>
      <div class="fg-card-row">
        <span class="fg-card-row-label">Catatan</span>
        <?php if ($rowEditable): ?><input type="text" class="fg-card-input" data-product-id="<?= (int) $it['productId'] ?>" data-field="notes" value="<?= ui_esc((string) ($it['notes'] ?? '')) ?>">
        <?php else: ?><?= ui_esc((string) ($it['notes'] ?? '')) ?><?php endif; ?>
      </div>
      <div class="fg-card-row"><span class="fg-card-row-label">FG Status</span><?= ui_badge($it['fgStatusLabel']) ?></div>
      <!-- "packed" is a FG PACKING concern now (see the separate "FG Packing" step/tab)
           — hidden here so Verifikasi's own PATCH never needs to show it, but still
           ECHOED BACK unchanged (patchDraft()'s items[] line REPLACES packed_qty,
           defaulting to 0 if absent — see FgService::patchDraft()'s own docblock —
           so this hidden field is what stops a Verifikasi-only save from wiping out
           already-packed work). -->
      <input type="hidden" data-product-id="<?= (int) $it['productId'] ?>" data-field="packed" value="<?= ui_num_input($it['packed']) ?>">
      <div class="fg-card-actions">
        <button type="button" class="btn btn-secondary btn-sm fg-breakdown-btn" data-product-id="<?= (int) $it['productId'] ?>" data-product-name="<?= ui_esc($it['productName']) ?>">Breakdown Toko</button>
        <?php if ($editable && $isBreakdown): ?>
        <button type="button" class="btn btn-warning btn-sm fg-collapse-btn" data-product-id="<?= (int) $it['productId'] ?>" data-product-name="<?= ui_esc($it['productName']) ?>">Kembali ke Per Produk</button>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <div id="fg-breakdown-panel" class="fg-card-list" style="display:none;margin-top:var(--space-3);"></div>
  <?php if ($editable): ?>
  <label style="display:flex;align-items:center;gap:8px;margin-top:var(--space-3);font-size:var(--text-sm);color:var(--text-muted);">
    <input type="checkbox" id="fg-refresh-source"> Segarkan sumber dari Produksi SUBMITTED terbaru (tidak mengubah angka yang sudah diisi)
  </label>
  <div class="btn-group" style="margin-top:var(--space-3);">
    <button type="button" class="btn btn-primary" id="btn-save-fg">Simpan Draft</button>
    <button type="button" class="btn btn-success" id="btn-submit-fg">Lanjut ke Packing &rarr;</button>
  </div>
  <?php elseif ($batchView['status'] === 'submitted' && array_intersect(['ADMIN', 'PPIC'], $ui['roles']) !== []): ?>
  <div class="btn-group" style="margin-top:var(--space-3);">
    <button type="button" class="btn btn-warning" id="btn-reopen-fg">Buka Kembali / Reopen</button>
  </div>
  <?php endif; ?>
  </form>

  <?php else /* $fgStep === 'packing' */: ?>
  <div id="fg-packing-header" style="margin-bottom:var(--space-3);">
    <div style="color:var(--text-muted);font-size:var(--text-sm);">Memuat status packing per toko...</div>
  </div>
  <div class="fg-store-chip-row" id="fg-store-chip-row"></div>
  <div id="fg-packing-detail" style="margin-top:var(--space-3);"></div>
  <?php if ($editable): ?>
  <div class="btn-group" style="margin-top:var(--space-4);">
    <button type="button" class="btn btn-success" id="btn-submit-fg-packing">Submit FG (Semua Toko)</button>
  </div>
  <?php elseif ($batchView['status'] === 'submitted' && array_intersect(['ADMIN', 'PPIC'], $ui['roles']) !== []): ?>
  <div class="btn-group" style="margin-top:var(--space-4);">
    <button type="button" class="btn btn-warning" id="btn-reopen-fg-packing">Buka Kembali / Reopen</button>
  </div>
  <?php endif; ?>
  <?php endif; ?>
</div>

<script>
var UNALLOCATED_STORE_ID = <?= (int) (new \Amor\Api\Fg\FgRepository())->unallocatedStoreId($pdo) ?>;
(function () {
  var batchId = <?= (int) $batchView['fgBatchId'] ?>;
  var version = <?= (int) $batchView['version'] ?>;
  var editableHere = <?= $editable ? 'true' : 'false' ?>;
  var fgStep = <?= json_encode($fgStep) ?>;
  // Server-filtered list (target > 0 only — see FgService::buildBatchDto()'s
  // isVisibleItem() gate) — the single source of truth both steps fetch
  // per-store data for.
  var visibleProducts = <?= json_encode(array_map(static fn ($it) => ['productId' => $it['productId'], 'productName' => $it['productName']], $batchView['items'])) ?>;

  // SECURITY: every dynamic value below (store name, product name,
  // notes/keterangan, status label, API error messages) is untrusted
  // string data that gets concatenated into innerHTML — this single
  // helper is the ONLY place that decides how such a value is made safe,
  // used consistently everywhere one of those values is interpolated
  // into an HTML string (never a partial/inconsistent .replace()).
  // Numeric-only values (ids, target/verified/packed quantities) are
  // never passed through this — they cannot carry markup.
  // UTC "YYYY-MM-DD HH:MM:SS" from the API -> "11 Okt 2026 · 20:14" (WIB).
  function fmtWib(s) {
    if (!s) return '-';
    var d = new Date(String(s).replace(' ', 'T') + 'Z');
    if (isNaN(d.getTime())) return String(s);
    var w = new Date(d.getTime() + 7 * 3600 * 1000);
    var bln = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    var hh = ('0' + w.getUTCHours()).slice(-2), mm = ('0' + w.getUTCMinutes()).slice(-2);
    return w.getUTCDate() + ' ' + bln[w.getUTCMonth()] + ' ' + w.getUTCFullYear() + ' \u00b7 ' + hh + ':' + mm;
  }
  function escHtml(value) {
    return String(value === null || value === undefined ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  // Sesuai/Tidak Sesuai — same auto-fill/lock convenience and same "server
  // always re-derives, never trusts a disabled input" rule everywhere it's
  // used (FG Verifikasi's own fields, Breakdown Toko's Verified, and FG
  // Packing's Actual Packing — see FgService::patchDraft()'s own
  // sesuaiVerified/sesuaiPacking check).
  function wireSesuaiGroup(group, valueInput, targetProvider) {
    group.querySelectorAll('button').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var isSesuai = btn.getAttribute('data-value') === 'sesuai';
        group.querySelectorAll('button').forEach(function (b) {
          b.className = 'btn btn-sm ' + (b === btn ? (isSesuai ? 'btn-primary' : 'btn-danger') : 'btn-secondary');
        });
        group.setAttribute('data-sesuai', isSesuai ? '1' : '0');
        if (isSesuai) {
          valueInput.value = targetProvider();
          valueInput.disabled = true;
        } else {
          valueInput.disabled = false;
        }
      });
    });
  }

  async function fetchStoreData(pid) {
    return Amor.apiFetch('/api/fg/' + batchId + '/items/' + pid + '/stores');
  }
  // One request for every product (was one request per product, ~13 s
  // for ~200 products on the live server).
  async function fetchAllStoreRows() {
    if (visibleProducts.length === 0) return [];
    var ids = visibleProducts.map(function (p) { return p.productId; });
    var rows = await Amor.apiFetch('/api/fg/' + batchId + '/stores?productIds=' + ids.join(','));
    var byId = {};
    rows.forEach(function (r) { byId[r.productId] = r.data; });
    return visibleProducts.map(function (p) { return { productId: p.productId, productName: p.productName, data: byId[p.productId] }; });
  }

  if (fgStep === 'verifikasi') {
    document.querySelectorAll('.fg-verified-sesuai-group').forEach(function (group) {
      var pid = group.getAttribute('data-product-id');
      var input = document.querySelector('#fg-form [data-field="fgVerified"][data-product-id="' + pid + '"]');
      if (input) wireSesuaiGroup(group, input, function () { return group.getAttribute('data-target'); });
    });
    // app.js loads after this inline script — run once it is there.
    document.addEventListener('DOMContentLoaded', function () {
      Amor.compactList({ list: document.getElementById('fg-perproduk-wrap'), rowSel: '.fg-card', groupSel: '.fg-verified-sesuai-group', nameSel: '.fg-card-title', bulkLabel: 'Isi semua yang belum diisi = Sesuai hasil produksi' });
    });

    var modeProduk = document.getElementById('fg-mode-produk');
    var modeToko = document.getElementById('fg-mode-toko');
    var breakdownPanel = document.getElementById('fg-breakdown-panel');
    var perProdukWrap = document.getElementById('fg-perproduk-wrap');

    // Builds ONE product's store-breakdown card block — Verifikasi's
    // Breakdown Toko is Verified/Reject/Hilang/Keterangan ONLY (Packing
    // now lives in its own step/tab, see below); "packed" is echoed back
    // unchanged via a hidden field for the same reason as the Per Produk
    // card above.
    function buildVerifikasiStoreBlock(pid, pname, data) {
      var block = document.createElement('div');
      block.className = 'fg-card';
      block.setAttribute('data-product-id', pid);
      var head = '<div class="fg-card-title">' + escHtml(pname) + '</div>'
        + (data.exploded ? '' : '<div class="alert alert-warning" style="margin:var(--space-2) 0;">Produk ini masih mode Per Produk — mengisi baris di bawah dan Simpan akan memecahnya ke per-Toko.</div>');
      var rowsHtml = (data.stores || []).map(function (s) {
        var verifiedSesuai = editableHere && Math.abs(s.fgVerified - s.target) < 0.01 && s.fgVerified > 0;
        var reviewBadge = s.needsReview ? ' <span class="badge badge-danger">Perlu Review Ulang</span>' : '';
        var body = '<div class="fg-card-sub" style="margin-top:var(--space-3);margin-bottom:0;"><b>' + escHtml(s.storeName) + '</b>' + reviewBadge + ' &middot; Target Toko: ' + s.target.toLocaleString('id-ID') + '</div>';
        if (!editableHere) {
          return body
            + '<div class="fg-card-row"><span class="fg-card-row-label">Actual Verified</span><span>' + s.fgVerified.toLocaleString('id-ID') + '</span></div>'
            + '<div class="fg-card-row"><span class="fg-card-row-label">Reject</span><span>' + s.reject.toLocaleString('id-ID') + '</span></div>'
            + '<div class="fg-card-row"><span class="fg-card-row-label">Hilang</span><span>' + s.hilang.toLocaleString('id-ID') + '</span></div>'
            + '<div class="fg-card-row"><span class="fg-card-row-label">Keterangan</span><span>' + escHtml(s.notes || '') + '</span></div>'
            + '<div class="fg-card-row"><span class="fg-card-row-label">Status</span><span>' + escHtml(s.status || '') + '</span></div>';
        }
        return body
          + '<div class="fg-card-row" data-store-id="' + s.storeId + '"><span class="fg-card-row-label">Verified Result</span>'
          +   '<div class="btn-group bt-verified-sesuai" data-target="' + s.target + '" data-sesuai="' + (verifiedSesuai ? '1' : '0') + '">'
          +     '<button type="button" class="btn btn-sm ' + (verifiedSesuai ? 'btn-primary' : 'btn-secondary') + '" data-value="sesuai">Sesuai</button>'
          +     '<button type="button" class="btn btn-sm ' + (!verifiedSesuai ? 'btn-danger' : 'btn-secondary') + '" data-value="tidak_sesuai">Tidak Sesuai</button>'
          +   '</div></div>'
          + '<div class="fg-card-row" data-store-id="' + s.storeId + '"><span class="fg-card-row-label">Actual Verified</span><input type="number" step="0.01" min="0" class="fg-card-input" data-bt-field="fgVerified" value="' + s.fgVerified + '" ' + (verifiedSesuai ? 'disabled' : '') + '></div>'
          + '<div class="fg-card-row" data-store-id="' + s.storeId + '"><span class="fg-card-row-label">Reject</span><input type="number" step="0.01" min="0" class="fg-card-input" data-bt-field="reject" value="' + s.reject + '"></div>'
          + '<div class="fg-card-row" data-store-id="' + s.storeId + '"><span class="fg-card-row-label">Hilang</span><input type="number" step="0.01" min="0" class="fg-card-input" data-bt-field="hilang" value="' + s.hilang + '"></div>'
          + '<div class="fg-card-row" data-store-id="' + s.storeId + '"><span class="fg-card-row-label">Keterangan</span><input type="text" class="fg-card-input" data-bt-field="notes" value="' + escHtml(s.notes || '') + '"></div>'
          + '<input type="hidden" data-store-id="' + s.storeId + '" data-bt-field="packed" value="' + s.packed + '">'
          + '<div class="fg-card-row" data-store-id="' + s.storeId + '"><span class="fg-card-row-label">Status</span><span>' + escHtml(s.status || '') + '</span></div>';
      }).join('');
      var actions = editableHere ? '<div class="fg-card-actions"><button type="button" class="btn btn-primary btn-sm bt-save">Simpan Breakdown Toko</button></div>' : '';
      block.innerHTML = head
        + (data.stores.length === 0 ? '<p style="color:var(--text-muted);">Tidak ada Toko dengan target &gt; 0 untuk produk ini.</p>' : rowsHtml)
        + (data.stores.length === 0 ? '' : '<div class="fg-card-row"><span class="fg-card-row-label"><b>Total</b></span><span>Target ' + data.totalTarget.toLocaleString('id-ID') + ' &middot; Verified ' + data.totalVerified.toLocaleString('id-ID') + '</span></div>')
        + actions;

      block.querySelectorAll('.bt-verified-sesuai').forEach(function (group) {
        var storeId = group.closest('[data-store-id]').getAttribute('data-store-id');
        var input = block.querySelector('[data-store-id="' + storeId + '"] [data-bt-field="fgVerified"]');
        wireSesuaiGroup(group, input, function () { return group.getAttribute('data-target'); });
      });

      var saveBtn = block.querySelector('.bt-save');
      if (saveBtn) saveBtn.addEventListener('click', async function () {
        saveBtn.disabled = true;
        var rowsOut = [];
        var storeIds = [];
        block.querySelectorAll('[data-store-id]').forEach(function (el) {
          var sid = el.getAttribute('data-store-id');
          if (storeIds.indexOf(sid) === -1) storeIds.push(sid);
        });
        // A field lives either ON the matched [data-store-id] element itself
        // (the standalone hidden "packed" echo-back input) or nested INSIDE
        // one of the several [data-store-id] row divs for this store (every
        // visible input) — this selector covers both without guessing which.
        storeIds.forEach(function (sid) {
          var field = function (name) {
            return block.querySelector('[data-store-id="' + sid + '"][data-bt-field="' + name + '"], [data-store-id="' + sid + '"] [data-bt-field="' + name + '"]');
          };
          var vGroup = block.querySelector('[data-store-id="' + sid + '"] .bt-verified-sesuai');
          rowsOut.push({
            storeId: parseInt(sid, 10),
            fgVerified: parseFloat((field('fgVerified') || { value: '0' }).value || '0'),
            packed: parseFloat((field('packed') || { value: '0' }).value || '0'),
            reject: parseFloat((field('reject') || { value: '0' }).value || '0'),
            hilang: parseFloat((field('hilang') || { value: '0' }).value || '0'),
            notes: (field('notes') || { value: '' }).value,
            sesuaiVerified: vGroup ? vGroup.getAttribute('data-sesuai') === '1' : false,
          });
        });
        try {
          var saved = await Amor.apiFetch('/api/fg/' + batchId, { method: 'PATCH', body: { expectedVersion: version, storeItems: [{ productId: parseInt(pid, 10), rows: rowsOut }] } });
          version = saved.version;
          Amor.toast('Breakdown Toko disimpan.', 'success');
          setTimeout(function () { location.reload(); }, 600);
        } catch (e) { Amor.toast(e.message, 'danger'); saveBtn.disabled = false; }
      });
      return block;
    }

    async function enterBreakdownMode(focusProductId) {
      if (!breakdownPanel) return;
      modeToko.className = 'btn btn-sm btn-primary'; modeProduk.className = 'btn btn-sm btn-secondary';
      if (perProdukWrap) perProdukWrap.style.display = 'none';
      breakdownPanel.style.display = '';
      breakdownPanel.innerHTML = '<div style="color:var(--text-muted);">Memuat Breakdown Toko...</div>';
      if (visibleProducts.length === 0) {
        breakdownPanel.innerHTML = '<p style="color:var(--text-muted);">Tidak ada produk dengan target &gt; 0.</p>';
        return;
      }
      try {
        var results = await fetchAllStoreRows();
        breakdownPanel.innerHTML = '';
        results.forEach(function (r) {
          breakdownPanel.appendChild(buildVerifikasiStoreBlock(r.productId, r.productName, r.data));
        });
        if (focusProductId) {
          var target = breakdownPanel.querySelector('[data-product-id="' + focusProductId + '"]');
          if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      } catch (e) {
        breakdownPanel.innerHTML = '<div class="alert alert-danger">' + escHtml(e.message) + '</div>';
      }
    }
    function exitBreakdownMode() {
      modeProduk.className = 'btn btn-sm btn-primary'; modeToko.className = 'btn btn-sm btn-secondary';
      if (perProdukWrap) perProdukWrap.style.display = '';
      if (breakdownPanel) { breakdownPanel.style.display = 'none'; breakdownPanel.innerHTML = ''; }
    }
    if (modeProduk && modeToko) {
      modeProduk.addEventListener('click', exitBreakdownMode);
      modeToko.addEventListener('click', function () { enterBreakdownMode(null); });
    }
    document.querySelectorAll('.fg-breakdown-btn').forEach(function (btn) {
      btn.addEventListener('click', function () { enterBreakdownMode(btn.getAttribute('data-product-id')); });
    });
    document.querySelectorAll('.fg-collapse-btn').forEach(function (btn) {
      btn.addEventListener('click', async function () {
        var pid = btn.getAttribute('data-product-id');
        var pname = btn.getAttribute('data-product-name');
        var ok = await Amor.confirmModal({ title: 'Kembali ke Per Produk?', body: 'Baris per-Toko untuk ' + pname + ' akan digabung kembali menjadi satu baris Per Produk (total tidak berubah). Detail per-Toko akan hilang.', confirmLabel: 'Ya, Gabungkan' });
        if (!ok) return;
        btn.disabled = true;
        try {
          var data = await Amor.apiFetch('/api/fg/' + batchId, { method: 'PATCH', body: { expectedVersion: version, collapseProductIds: [parseInt(pid, 10)] } });
          version = data.version;
          Amor.toast('Digabung kembali ke Per Produk.', 'success');
          setTimeout(function () { location.reload(); }, 600);
        } catch (e) { Amor.toast(e.message, 'danger'); btn.disabled = false; }
      });
    });

    function collectItems() {
      var items = [];
      document.querySelectorAll('#fg-form [data-field="fgVerified"]').forEach(function (input) {
        var pid = input.getAttribute('data-product-id');
        var packedInput = document.querySelector('#fg-form [data-field="packed"][data-product-id="' + pid + '"]');
        var rejectInput = document.querySelector('#fg-form [data-field="reject"][data-product-id="' + pid + '"]');
        var hilangInput = document.querySelector('#fg-form [data-field="hilang"][data-product-id="' + pid + '"]');
        var notesInput = document.querySelector('#fg-form [data-field="notes"][data-product-id="' + pid + '"]');
        var verifiedGroup = document.querySelector('.fg-verified-sesuai-group[data-product-id="' + pid + '"]');
        items.push({
          productId: parseInt(pid, 10),
          fgVerified: parseFloat(input.value || '0'),
          packed: packedInput ? parseFloat(packedInput.value || '0') : 0,
          reject: rejectInput ? parseFloat(rejectInput.value || '0') : 0,
          hilang: hilangInput ? parseFloat(hilangInput.value || '0') : 0,
          notes: notesInput ? notesInput.value : '',
          sesuaiVerified: verifiedGroup ? verifiedGroup.getAttribute('data-sesuai') === '1' : false,
        });
      });
      return items;
    }
    var form = document.getElementById('fg-form');
    var refreshBox = document.getElementById('fg-refresh-source');

    // Packing and stock are per Toko (a store's ready FG can only ship to
    // that store), so a verified product with PO store targets must end up
    // split per Toko before it can be packed. Done automatically where the
    // split is unambiguous: Sesuai with production == SUM(store targets)
    // takes each store's own target; a product with exactly ONE target
    // store takes the whole verified qty. Anything else (verified differs
    // from the store targets across several stores) is never guessed —
    // the operator splits it in Breakdown Toko.
    async function buildVerifikasiPayload() {
      var items = [], storeItems = [], manual = [];
      var lines = collectItems();
      // One request for all verified products (was one request per
      // product, in sequence: 1-2 minutes on the live server).
      var verifiedIds = lines.filter(function (l) { return l.fgVerified > 0.0001; }).map(function (l) { return l.productId; });
      var storeDataById = {};
      if (verifiedIds.length > 0) {
        (await Amor.apiFetch('/api/fg/' + batchId + '/stores?productIds=' + verifiedIds.join(','))).forEach(function (r) { storeDataById[r.productId] = r.data; });
      }
      for (var i = 0; i < lines.length; i++) {
        var line = lines[i];
        if (line.fgVerified <= 0.0001) { items.push(line); continue; }
        var data = storeDataById[line.productId] || await fetchStoreData(line.productId);
        var stores = (data.stores || []).filter(function (st) { return Number(st.target) > 0.0001; });
        // Nobody ordered it: the whole verified result is Stok Sisa
        // (packed = verified so it is posted to stock with the batch).
        if (stores.length === 0) { line.packed = line.fgVerified; items.push(line); continue; }
        var sumTarget = stores.reduce(function (a, st) { return a + Number(st.target); }, 0);
        var rows = null, surplus = 0;
        if (stores.length === 1) {
          var storeQty = Math.min(line.fgVerified, Number(stores[0].target));
          surplus = line.fgVerified - storeQty;
          rows = [{ storeId: stores[0].storeId, fgVerified: storeQty, sesuaiVerified: Math.abs(storeQty - Number(stores[0].target)) < 0.01 }];
          // FG confirmed the production result (Sesuai) but production
          // itself is short of the PO: record why, so FG never has to
          // type a note for a gap that is Production's, not FG's.
          if (storeQty < Number(stores[0].target) - 0.01 && line.sesuaiVerified && !line.notes) {
            line.notes = 'Sesuai hasil produksi (' + line.fgVerified.toLocaleString('id-ID') + '); target PO toko ' + Number(stores[0].target).toLocaleString('id-ID');
          }
        } else if (line.fgVerified >= sumTarget - 0.01) {
          // Every store gets its PO; what is left over is Stok Sisa.
          rows = stores.map(function (st) { return { storeId: st.storeId, fgVerified: Number(st.target), sesuaiVerified: true }; });
          surplus = line.fgVerified - sumTarget;
        }
        if (rows === null) {
          var card = document.querySelector('.fg-card[data-product-id="' + line.productId + '"] .fg-card-title');
          manual.push({ productId: line.productId, name: card ? card.textContent : ('Produk ' + line.productId) });
          continue;
        }
        rows.forEach(function (r, idx) {
          r.packed = 0;
          r.reject = idx === 0 ? line.reject : 0;
          r.hilang = idx === 0 ? line.hilang : 0;
          r.notes = idx === 0 ? line.notes : '';
        });
        if (surplus > 0.0001) {
          rows.push({ storeId: UNALLOCATED_STORE_ID, fgVerified: surplus, packed: surplus, reject: 0, hilang: 0, notes: 'Stok Sisa produksi' });
        }
        storeItems.push({ productId: line.productId, rows: rows });
      }
      return { items: items, storeItems: storeItems, manual: manual };
    }

    async function saveVerifikasi() {
      var payload = await buildVerifikasiPayload();
      if (payload.manual.length > 0) {
        var names = payload.manual.map(function (m) { return m.name; }).join(', ');
        throw new Error('Jumlah FG ' + names + ' berbeda dari target per toko. Bagi jumlahnya per toko di "Breakdown Toko" dulu.');
      }
      var data = await Amor.apiFetch('/api/fg/' + batchId, { method: 'PATCH', body: { expectedVersion: version, items: payload.items, storeItems: payload.storeItems, refreshSource: refreshBox && refreshBox.checked } });
      version = data.version;
      form.setAttribute('data-expected-version', version);
      return data;
    }

    var saveBtn = document.getElementById('btn-save-fg');
    if (saveBtn) saveBtn.addEventListener('click', async function () {
      saveBtn.disabled = true;
      try {
        await saveVerifikasi();
        Amor.toast('Verifikasi FG disimpan.', 'success');
        setTimeout(function () { location.reload(); }, 600);
      } catch (e) { Amor.toast(e.message, 'danger'); saveBtn.disabled = false; }
    });

    // "Lanjut ke Packing": saves the verification, then moves to the
    // Packing step. Stock is only added by the final Submit FG there,
    // once every Toko is packed.
    var submitBtn = document.getElementById('btn-submit-fg');
    if (submitBtn) submitBtn.addEventListener('click', async function () {
      submitBtn.disabled = true;
      try {
        var saved = await saveVerifikasi();
        var needsPacking = (saved.items || []).some(function (it) { return Number(it.fgVerified) > 0.0001; });
        if (needsPacking) {
          Amor.toast('Verifikasi tersimpan. Lanjutkan packing per toko.', 'success');
          setTimeout(function () { location.href = <?= json_encode(fgStepUrl('packing', $uiTanggal, $uiFactoryId)) ?>; }, 500);
          return;
        }
        Amor.toast('Belum ada FG terverifikasi untuk dipacking.', 'warning');
        submitBtn.disabled = false;
      } catch (e) { Amor.toast(e.message, 'danger'); submitBtn.disabled = false; }
    });

    var refreshSourceBtn = document.getElementById('btn-refresh-fg-source');
    if (refreshSourceBtn) refreshSourceBtn.addEventListener('click', async function () {
      refreshSourceBtn.disabled = true;
      try {
        var data = await Amor.apiFetch('/api/fg/' + batchId + '/refresh-source', { method: 'POST', body: { expectedVersion: version } });
        version = data.version;
        var changed = (data.refreshChangedSnapshots || []).length;
        var blocking = (data.verifiedExceedsProductionBlocking || []).length;
        var msg = 'Sumber Produksi disegarkan. ' + changed + ' produk diperbarui angkanya.';
        if (blocking > 0) msg += ' PERINGATAN: ' + blocking + ' produk sekarang punya FG Terverifikasi melebihi Hasil Produksi terbaru.';
        Amor.toast(msg, blocking > 0 ? 'warning' : 'success');
        setTimeout(function () { location.reload(); }, 800);
      } catch (e) { Amor.toast(e.message, 'danger'); refreshSourceBtn.disabled = false; }
    });

    var reopenBtn = document.getElementById('btn-reopen-fg');
    if (reopenBtn) reopenBtn.addEventListener('click', async function () {
      var reason = prompt('Alasan membuka kembali FG ini (wajib):');
      if (!reason) return;
      reopenBtn.disabled = true;
      try {
        await Amor.apiFetch('/api/fg/' + batchId + '/reopen', { method: 'POST', body: { expectedVersion: version, reason: reason } });
        Amor.toast('FG dibuka kembali.', 'success');
        setTimeout(function () { location.reload(); }, 600);
      } catch (e) { Amor.toast(e.message, 'danger'); reopenBtn.disabled = false; }
    });
    return; // end Verifikasi step wiring
  }

  // ---------------------------------------------------------------------
  // FG PACKING — per Toko (default/only packing workflow — task's own
  // "Packing should default to PER TOKO" requirement). Reuses the EXACT
  // SAME store-row data Verifikasi's Breakdown Toko already reads/writes
  // (GET/PATCH /api/fg/{id}/items/{productId}/stores) — grouped by STORE
  // here instead of by product. A product still entirely in Per Produk
  // mode (never exploded during Verifikasi) has no store identity yet, so
  // it cannot appear here — see this task's own delivery report for why
  // that is a deliberate limitation, not an oversight.
  // ---------------------------------------------------------------------
  var storeGroups = [];
  var surplusTotal = 0;
  var currentStoreId = null;
  // LIVE UAT UX FIX — a store whose Packing already has a real
  // submission record (submitted OR stale) renders its fields LOCKED
  // (read-only) by default; packingEditMode is the ONLY thing that ever
  // unlocks them, and only for the currently open store, and only after
  // the operator explicitly confirms "Edit Packing". It is reset to
  // false every time fresh server data is loaded for a store (initial
  // render, chip switch, after a successful save/submit/resubmit) —
  // never carried over to a different store, never left on after a
  // completed action.
  var packingEditMode = false;

  function groupByStore(results) {
    var byStore = {};
    var order = [];
    results.forEach(function (r) {
      (r.data.stores || []).forEach(function (s) {
        if (!byStore[s.storeId]) {
          byStore[s.storeId] = {
            storeId: s.storeId, storeName: s.storeName, rows: [],
            // FINAL FIX — real, persisted Packing submission truth
            // (migration 0015's fg_store_packing_submission), scoped to
            // (batch, store) — the SAME value on every one of this
            // store's rows from batchProductStores(), captured once
            // here. null = never submitted at all; 'submitted' = the
            // real event completed and nothing has changed since;
            // 'stale' = it WAS submitted, then a later edit changed this
            // store's own data (Breakdown Toko's own Reject/Hilang/
            // Keterangan save, most commonly) — see FgService::
            // submitStorePacking()'s own docblock for why packed_qty vs
            // target can NEVER stand in for this (a store can legitimately
            // submit Tidak Sesuai with packed < target, or packed = 0
            // with a valid discrepancy note, and still be a real,
            // complete submission).
            packingSubmittedStatus: s.packingSubmittedStatus,
            packingSubmittedAt: s.packingSubmittedAt,
            packingSubmittedBy: s.packingSubmittedBy,
          };
          order.push(s.storeId);
        }
        byStore[s.storeId].rows.push({
          productId: r.productId, productName: r.productName,
          // A product with real Regular PO store-level demand shows up
          // here (batchProductStores() always renders live PO-target rows,
          // whether or not this product has ever been exploded — Phase 2
          // PO import is already store-split independently of Phase 4 FG's
          // own explode step) EVEN IF it is still being verified in
          // default Per Produk mode. r.data.exploded is per-PRODUCT (same
          // value on every one of that product's rows here) — a still-
          // unexploded product's fgVerified is always 0 at every store
          // (nothing has been assigned to any one store yet), so there is
          // nothing real to pack for it yet; it is shown read-only, never
          // included in a "Submit Packing" payload (see renderDetail()) —
          // attempting to would try to explodeToStores() a row that still
          // has a real (nonzero) Per Produk aggregate, which the backend
          // correctly refuses (MODE_SWITCH_REQUIRES_ZERO_PER_PRODUK) since
          // it cannot guess how to split that number across stores.
          exploded: r.data.exploded,
          target: s.target, fgVerified: s.fgVerified, packed: s.packed,
          reject: s.reject, hilang: s.hilang, notes: s.notes, status: s.status,
        });
      });
    });
    return order.map(function (id) { return byStore[id]; });
  }

  // Store status — "Sudah Disubmit"/"Perlu Submit Ulang" come STRAIGHT
  // from the server's own persisted submission record (see groupByStore()'s
  // own docblock) — NEVER inferred from packed_qty vs target, which
  // cannot tell "never submitted" apart from "submitted with a low/zero
  // number" (the exact bug this pass exists to fix). Quantity progress
  // ("Belum Mulai"/"Sebagian"/"Sedang Dikerjakan") is a SEPARATE concept
  // from the submission event and is still computed from packed_qty —
  // both can be shown together (e.g. "8/10 packed" alongside "Sudah
  // Disubmit") without contradiction.
  function storeStatus(group) {
    var targetTotal = 0, readyTotal = 0, packedTotal = 0;
    // A never-exploded row (see groupByStore()'s own docblock) can never
    // be packed at all yet — counting its target in this store's own
    // progress denominator would understate real completion. Only rows
    // this store can actually submit packing for count.
    group.rows.forEach(function (r) { if (r.exploded) { targetTotal += r.target; readyTotal += r.fgVerified; packedTotal += r.packed; } });
    var eps = 0.0001;
    var code, label;
    if (group.packingSubmittedStatus === 'submitted') { code = 'sudah_disubmit'; label = '✓ Sudah Disubmit'; }
    else if (group.packingSubmittedStatus === 'stale') { code = 'perlu_submit_ulang'; label = 'Perlu Submit Ulang'; }
    else if (packedTotal <= eps) { code = 'belum_mulai'; label = 'Belum Mulai'; }
    else if (packedTotal >= readyTotal - eps) { code = 'sebagian'; label = 'Sebagian'; }
    else { code = 'sedang_dikerjakan'; label = 'Sedang Dikerjakan'; }
    return { code: code, label: label, targetTotal: targetTotal, readyTotal: readyTotal, packedTotal: packedTotal };
  }

  function renderHeader() {
    var header = document.getElementById('fg-packing-header');
    var totalStores = storeGroups.length;
    var doneStores = 0, packedSum = 0, targetSum = 0;
    storeGroups.forEach(function (g) {
      var st = storeStatus(g);
      if (st.code === 'sudah_disubmit') doneStores++;
      packedSum += st.packedTotal; targetSum += st.targetTotal;
    });
    var pct = targetSum > 0 ? Math.min(100, Math.round((packedSum / targetSum) * 100)) : 0;
    header.innerHTML = '<div class="fg-card-row"><span class="fg-card-row-label">Toko Selesai</span><b>' + doneStores + ' / ' + totalStores + ' toko</b></div>'
      + '<div class="fg-card-row"><span class="fg-card-row-label">Packed pcs</span><b>' + packedSum.toLocaleString('id-ID') + ' / ' + targetSum.toLocaleString('id-ID') + ' pcs</b></div>'
      + '<div class="fg-progress-track"><div class="fg-progress-fill" style="width:' + pct + '%;"></div></div>'
      + (surplusTotal > 0.0001 ? '<div class="fg-card-row"><span class="fg-card-row-label">Stok Sisa (lebih dari PO)</span><b>' + surplusTotal.toLocaleString('id-ID') + ' pcs</b></div>'
        + '<div style="font-size:var(--text-xs);color:var(--text-muted);">Disisihkan di gudang. Admin bisa mengirimnya susulan ke toko atau menjualnya ke non-toko (menu Stok Sisa).</div>' : '');
  }

  function renderChips() {
    var row = document.getElementById('fg-store-chip-row');
    if (storeGroups.length === 0) {
      row.innerHTML = '<p style="color:var(--text-muted);">Belum ada Toko dengan target &gt; 0 untuk produk manapun (jalankan Breakdown Toko di FG Verifikasi dulu).</p>';
      return;
    }
    row.innerHTML = '';
    storeGroups.forEach(function (g) {
      var st = storeStatus(g);
      var chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'fg-store-chip' + (g.storeId === currentStoreId ? ' active' : '')
        + (st.code === 'sudah_disubmit' ? ' fg-store-chip-submitted' : '')
        + (st.code === 'perlu_submit_ulang' ? ' fg-store-chip-stale' : '');
      chip.setAttribute('data-store-id', g.storeId);
      chip.innerHTML = '<div class="fg-store-chip-name">' + escHtml(g.storeName) + '</div>'
        + '<div class="fg-store-chip-meta">' + g.rows.length + ' produk &bull; ' + st.targetTotal.toLocaleString('id-ID') + ' pcs</div>'
        + '<div class="fg-store-chip-meta">' + escHtml(st.label) + '</div>';
      chip.addEventListener('click', function () { currentStoreId = g.storeId; packingEditMode = false; renderChips(); renderDetail(); });
      row.appendChild(chip);
    });
  }

  function renderDetail() {
    var detail = document.getElementById('fg-packing-detail');
    var group = storeGroups.filter(function (g) { return g.storeId === currentStoreId; })[0];
    if (!group) { detail.innerHTML = ''; return; }
    var status = storeStatus(group);
    // LIVE UAT UX FIX — a store that already has a real submission
    // record (submitted OR stale) renders LOCKED (read-only) by default,
    // exactly like the !editableHere (submitted whole-document) case
    // below — the only way to unlock it is the explicit "Edit Packing"
    // confirmation flow (see packingActionsHtml()/wirePackingActions()).
    // A store that was never submitted (belum_mulai/sedang_dikerjakan/
    // sebagian) stays directly editable, unchanged from before this pass.
    var isSubmittedState = status.code === 'sudah_disubmit' || status.code === 'perlu_submit_ulang';
    var locked = editableHere && isSubmittedState && !packingEditMode;
    var editingCorrection = editableHere && isSubmittedState && packingEditMode;

    var cardsHtml = group.rows.map(function (r) {
      var packingSesuai = editableHere && Math.abs(r.packed - r.fgVerified) < 0.01 && r.packed > 0;
      var body = '<div class="fg-card fg-packing-row" data-product-id="' + r.productId + '" data-exploded="' + (r.exploded ? '1' : '0') + '">'
        + '<div class="fg-card-title">' + escHtml(r.productName) + '</div>'
        + '<div class="fg-card-sub">Target Toko: ' + r.target.toLocaleString('id-ID') + ' &middot; FG Terverifikasi: ' + r.fgVerified.toLocaleString('id-ID') + '</div>';
      if (!r.exploded) {
        // Still verified in default Per Produk mode — no real per-store
        // FG Verified exists yet, so there is nothing this store can
        // legitimately pack for this product (Ready Verified is always 0
        // here). Shown for visibility only; never part of a submit
        // payload (see the submit handler below) — attempting to would
        // try to split an existing nonzero Per Produk aggregate across
        // stores, which the backend correctly refuses to guess at.
        return body
          + '<div class="alert alert-warning" style="margin:var(--space-2) 0;">Belum di-Breakdown Toko — verifikasi per Toko dulu di FG Verifikasi sebelum bisa dipacking di sini.</div>'
          + '</div>';
      }
      if (!editableHere || locked) {
        body += '<div class="fg-card-row"><span class="fg-card-row-label">Jumlah Dipacking</span><span>' + r.packed.toLocaleString('id-ID') + '</span></div>'
          + '<div class="fg-card-row"><span class="fg-card-row-label">Reject</span><span>' + r.reject.toLocaleString('id-ID') + '</span></div>'
          + '<div class="fg-card-row"><span class="fg-card-row-label">Hilang</span><span>' + r.hilang.toLocaleString('id-ID') + '</span></div>'
          + '<div class="fg-card-row"><span class="fg-card-row-label">Keterangan</span><span>' + escHtml(r.notes || '') + '</span></div>'
          + '<div class="fg-card-row"><span class="fg-card-row-label">Status</span><span>' + escHtml(r.status || '') + '</span></div>'
          + '<input type="hidden" data-pk-field="fgVerified" value="' + r.fgVerified + '">'
          + '</div>';
        return body;
      }
      // CRITICAL PACKING RULE: Sesuai auto-fills to Ready Verified (r.fgVerified —
      // what THIS store actually has ready), never the raw Target — the
      // server's own PACKED_EXCEEDS_VERIFIED check (packed <= fgVerified,
      // unchanged, pre-existing rule) is what actually enforces this; the
      // auto-fill below simply mirrors it so a real over-target tap can never
      // even be typed by clicking "Sesuai".
      body += '<div class="fg-card-row"><span class="fg-card-row-label">Hasil Packing</span>'
        + '<div class="btn-group pk-sesuai" data-sesuai="' + (packingSesuai ? '1' : '0') + '">'
        +   '<button type="button" class="btn btn-sm ' + (packingSesuai ? 'btn-primary' : 'btn-secondary') + '" data-value="sesuai">Sesuai</button>'
        +   '<button type="button" class="btn btn-sm ' + (!packingSesuai ? 'btn-danger' : 'btn-secondary') + '" data-value="tidak_sesuai">Tidak Sesuai</button>'
        + '</div></div>'
        + '<div class="fg-card-row"><span class="fg-card-row-label">Jumlah Dipacking</span><input type="number" step="0.01" min="0" max="' + r.fgVerified + '" class="fg-card-input" data-pk-field="packed" value="' + r.packed + '" ' + (packingSesuai ? 'disabled' : '') + '></div>'
        + '<div class="fg-card-row"><span class="fg-card-row-label">Reject</span><input type="number" step="0.01" min="0" class="fg-card-input" data-pk-field="reject" value="' + r.reject + '"></div>'
        + '<div class="fg-card-row"><span class="fg-card-row-label">Hilang</span><input type="number" step="0.01" min="0" class="fg-card-input" data-pk-field="hilang" value="' + r.hilang + '"></div>'
        + '<div class="fg-card-row"><span class="fg-card-row-label">Keterangan</span><input type="text" class="fg-card-input" data-pk-field="notes" value="' + escHtml(r.notes || '') + '"></div>'
        + '<input type="hidden" data-pk-field="fgVerified" value="' + r.fgVerified + '">'
        + '</div>';
      return body;
    }).join('');
    var editBanner = editingCorrection
      ? '<div class="alert alert-warning" style="margin-bottom:var(--space-3);font-weight:700;">MODE EDIT — Sedang Dikoreksi</div>'
      : '';
    detail.innerHTML = '<h3 class="card-title" style="font-size:var(--text-md);margin-bottom:var(--space-2);">Packing — ' + escHtml(group.storeName) + '</h3>'
      + packingSubmissionMetaHtml(group, status)
      + editBanner
      + '<div class="fg-card-list">' + cardsHtml + '</div>'
      + '<div id="fg-packing-actions">' + packingActionsHtml(group, status, locked, editingCorrection) + '</div>';

    if (!locked) {
      detail.querySelectorAll('.pk-sesuai').forEach(function (group2) {
        var card = group2.closest('.fg-packing-row');
        var packedInput = card.querySelector('[data-pk-field="packed"]');
        var readyInput = card.querySelector('[data-pk-field="fgVerified"]');
        wireSesuaiGroup(group2, packedInput, function () { return readyInput.value || '0'; });
      });
      Amor.compactList({ list: detail.querySelector('.fg-card-list'), rowSel: '.fg-packing-row', groupSel: '.pk-sesuai', nameSel: '.fg-card-title', bulkLabel: 'Isi semua yang belum diisi = Sesuai (dipacking semua)' });
    }

    wirePackingActions(group, detail, status, locked, editingCorrection);
  }

  // Small "Disubmit oleh: X · Waktu Submit: T" line, shown only once this
  // store genuinely has a real persisted submission record (submitted OR
  // stale — even stale keeps the LAST real submission's own metadata
  // visible, per FgRepository::invalidatePackingSubmission()'s own
  // "never deletes the row" contract). Never shown, never invented, for
  // a store that has no submission row at all.
  function packingSubmissionMetaHtml(group, status) {
    if (!group.packingSubmittedAt || !group.packingSubmittedBy) return '';
    var prefix = status.code === 'perlu_submit_ulang' ? 'Terakhir disubmit' : 'Disubmit';
    return '<div class="fg-card-sub" style="margin-bottom:var(--space-3);">' + escHtml(prefix) + ' oleh: <b>' + escHtml(group.packingSubmittedBy) + '</b> &middot; Waktu Submit: ' + escHtml(fmtWib(group.packingSubmittedAt)) + '</div>';
  }

  // Builds the per-store action area from the server's OWN persisted
  // submission status (storeStatus(), never a client-side inference) AND
  // the local packingEditMode UI state:
  //   - LOCKED (submitted/stale, not editing): an unmistakable badge
  //     (green "Sudah Disubmit" / amber "Perlu Submit Ulang") plus an
  //     "Edit Packing" button (always available so a mistake can be
  //     corrected) and, for the stale case, an active "Submit Ulang
  //     Packing" button that resubmits the ALREADY-persisted values
  //     directly (no DOM read needed — nothing here is editable).
  //   - EDITING (explicit Edit Packing confirmed): "Batal Edit" +
  //     "Simpan Perubahan", plus a client-only "Perubahan belum
  //     disimpan" hint once something is actually touched.
  //   - Never submitted at all: the original, unchanged "Submit Packing
  //     [Store]" button.
  function packingActionsHtml(group, status, locked, editingCorrection) {
    if (!editableHere) return '';
    if (locked) {
      var badgeHtml = status.code === 'perlu_submit_ulang'
        ? '<span class="badge badge-warning">Perlu Submit Ulang</span>'
        : '<span class="badge badge-success">✓ Sudah Disubmit</span>';
      var resubmitBtn = status.code === 'perlu_submit_ulang'
        ? '<button type="button" class="btn btn-primary" id="fg-resubmit-packing-store">Submit Ulang Packing ' + escHtml(group.storeName) + '</button>'
        : '';
      return '<div class="fg-card-actions" style="margin-top:var(--space-3);flex-wrap:wrap;align-items:center;gap:var(--space-2);">'
        + badgeHtml + resubmitBtn
        + '<button type="button" class="btn btn-secondary" id="fg-edit-packing-store">Edit Packing</button>'
        + '</div>';
    }
    if (editingCorrection) {
      return '<div class="fg-card-actions" style="margin-top:var(--space-3);flex-wrap:wrap;align-items:center;gap:var(--space-2);">'
        + '<button type="button" class="btn btn-secondary" id="fg-cancel-edit-packing">Batal Edit</button>'
        + '<button type="button" class="btn btn-primary" id="fg-save-packing-correction">Simpan Perubahan</button>'
        + '<span id="fg-packing-dirty-indicator" style="display:none;color:var(--warning);font-size:var(--text-sm);">Perubahan belum disimpan</span>'
        + '</div>';
    }
    return '<div class="fg-card-actions" style="margin-top:var(--space-3);">'
      + '<button type="button" class="btn btn-primary" id="fg-submit-packing-store">Submit Packing ' + escHtml(group.storeName) + '</button>'
      + '</div>';
  }

  // Reads CURRENT DOM input values — used only when fields are actually
  // editable on screen (first-time submit, or Simpan Perubahan in Edit
  // mode), since the operator may have just typed something.
  function collectPackingRowsFromDom(detail) {
    var rows = [];
    // A still-unexploded product (data-exploded="0") is deliberately
    // left OUT of this store's own payload entirely — see the card's
    // own rendering above for why.
    detail.querySelectorAll('.fg-packing-row[data-exploded="1"]').forEach(function (card) {
      var pid = card.getAttribute('data-product-id');
      var field = function (name) { var el = card.querySelector('[data-pk-field="' + name + '"]'); return el ? el.value : ''; };
      var sesuaiGroup = card.querySelector('.pk-sesuai');
      rows.push({
        productId: parseInt(pid, 10),
        storeId: currentStoreId,
        fgVerified: parseFloat(field('fgVerified') || '0'),
        packed: parseFloat(field('packed') || '0'),
        reject: parseFloat(field('reject') || '0'),
        hilang: parseFloat(field('hilang') || '0'),
        notes: field('notes'),
        sesuaiPacking: sesuaiGroup ? sesuaiGroup.getAttribute('data-sesuai') === '1' : false,
      });
    });
    return rows;
  }

  // Reads the LAST-FETCHED, already-persisted values straight from the
  // JS data model — used for "Submit Ulang Packing" clicked directly
  // from the LOCKED (stale) view, where nothing is an editable DOM
  // input to read from; this simply reaffirms the numbers a prior
  // "Simpan Perubahan" already saved.
  function collectPackingRowsFromGroup(group) {
    return group.rows.filter(function (r) { return r.exploded; }).map(function (r) {
      var packingSesuai = editableHere && Math.abs(r.packed - r.fgVerified) < 0.01 && r.packed > 0;
      return {
        productId: r.productId, storeId: currentStoreId,
        fgVerified: r.fgVerified, packed: r.packed, reject: r.reject, hilang: r.hilang,
        notes: r.notes, sesuaiPacking: packingSesuai,
      };
    });
  }

  function wirePackingActions(group, detail, status, locked, editingCorrection) {
    // "Submit Packing [Store]" — first-time submit only (never-submitted
    // state, fields directly editable). Calls the DEDICATED packing-
    // submit endpoint: in ONE server-side transaction it both saves
    // these rows AND records this store's real, persisted submission
    // event (migration 0015's fg_store_packing_submission) — never
    // marked submitted unless every row validates AND the save itself
    // succeeds (FgService::submitStorePacking()'s own docblock). Never
    // posts stock — that stays the separate, once-per-document "Submit
    // FG (Semua Toko)" action below.
    var submitStoreBtn = document.getElementById('fg-submit-packing-store');
    if (submitStoreBtn) submitStoreBtn.addEventListener('click', async function () {
      submitStoreBtn.disabled = true;
      try {
        var saved = await Amor.apiFetch('/api/fg/' + batchId + '/packing-submit', { method: 'POST', body: { expectedVersion: version, storeId: currentStoreId, rows: collectPackingRowsFromDom(detail) } });
        version = saved.version;
        Amor.toast('Packing ' + group.storeName + ' disubmit.', 'success');
        packingEditMode = false;
        await reloadStoreGroups();
        renderHeader(); renderChips(); renderDetail();
      } catch (e) { Amor.toast(e.message, 'danger'); submitStoreBtn.disabled = false; }
    });

    // "Submit Ulang Packing [Store]" — resubmits from the LOCKED
    // (Perlu Submit Ulang) view, reaffirming the already-persisted
    // values a prior "Simpan Perubahan" saved. Same endpoint, same
    // atomic write+submission-record guarantee as above.
    var resubmitBtn = document.getElementById('fg-resubmit-packing-store');
    if (resubmitBtn) resubmitBtn.addEventListener('click', async function () {
      resubmitBtn.disabled = true;
      try {
        var saved = await Amor.apiFetch('/api/fg/' + batchId + '/packing-submit', { method: 'POST', body: { expectedVersion: version, storeId: currentStoreId, rows: collectPackingRowsFromGroup(group) } });
        version = saved.version;
        Amor.toast('Packing ' + group.storeName + ' disubmit ulang.', 'success');
        packingEditMode = false;
        await reloadStoreGroups();
        renderHeader(); renderChips(); renderDetail();
      } catch (e) { Amor.toast(e.message, 'danger'); resubmitBtn.disabled = false; }
    });

    // "Edit Packing" — from the LOCKED view only. An explicit
    // confirmation is required before anything unlocks; merely clicking
    // this (even confirming it) NEVER touches persisted submission
    // state by itself — only a REAL saved change does (see "Simpan
    // Perubahan" below and FgService::applyStoreRow()'s own change-
    // detection). Cancelling the confirmation leaves everything exactly
    // as it was.
    var editBtn = document.getElementById('fg-edit-packing-store');
    if (editBtn) editBtn.addEventListener('click', async function () {
      var ok = await Amor.confirmModal({
        title: 'Edit Packing?',
        body: 'Packing toko ini sudah disubmit. Apakah Anda ingin melakukan koreksi?',
        confirmLabel: 'Ya, Edit Packing',
      });
      if (!ok) return;
      packingEditMode = true;
      renderDetail();
    });

    // "Batal Edit" — discards nothing (nothing was ever saved to the
    // server just by entering Edit mode), simply re-renders LOCKED from
    // the same, still-current, still-"Sudah Disubmit" group.rows.
    var cancelEditBtn = document.getElementById('fg-cancel-edit-packing');
    if (cancelEditBtn) cancelEditBtn.addEventListener('click', function () {
      packingEditMode = false;
      renderDetail();
    });

    // "Simpan Perubahan" — the deliberate correction save. Reuses the
    // SAME generic storeItems PATCH Breakdown Toko's own save in FG
    // Verifikasi already uses — its own change-detection (FgService::
    // applyStoreRow(), shared by both paths) only flips this store's
    // submission to 'stale' when a value ACTUALLY differs from what is
    // currently persisted, so saving unchanged values here correctly
    // leaves "Sudah Disubmit" as-is (task's own "do not create a false
    // stale state" rule) — never a second, looser copy of that rule.
    // This is what makes the server-side protection real rather than
    // UI-only: a submitted store's data can ONLY ever change through
    // this exact same, single, audited write+invalidate path, no matter
    // which button or caller triggers it.
    var saveCorrectionBtn = document.getElementById('fg-save-packing-correction');
    if (saveCorrectionBtn) saveCorrectionBtn.addEventListener('click', async function () {
      saveCorrectionBtn.disabled = true;
      var rows = collectPackingRowsFromDom(detail);
      var storeItems = rows.map(function (r) {
        return { productId: r.productId, rows: [{ storeId: r.storeId, fgVerified: r.fgVerified, packed: r.packed, reject: r.reject, hilang: r.hilang, notes: r.notes, sesuaiPacking: r.sesuaiPacking }] };
      });
      try {
        var saved = await Amor.apiFetch('/api/fg/' + batchId, { method: 'PATCH', body: { expectedVersion: version, storeItems: storeItems } });
        version = saved.version;
        Amor.toast('Perubahan Packing ' + group.storeName + ' disimpan.', 'success');
        packingEditMode = false;
        await reloadStoreGroups();
        renderHeader(); renderChips(); renderDetail();
      } catch (e) { Amor.toast(e.message, 'danger'); saveCorrectionBtn.disabled = false; }
    });

    // Client-only "Perubahan belum disimpan" hint while in Edit mode —
    // purely cosmetic, never touches persisted state itself (that only
    // ever happens inside "Simpan Perubahan" above, and only when the
    // server confirms a real change).
    if (editingCorrection) {
      var dirtyEl = document.getElementById('fg-packing-dirty-indicator');
      detail.querySelectorAll('.fg-packing-row[data-exploded="1"] input, .fg-packing-row[data-exploded="1"] .pk-sesuai button').forEach(function (el) {
        el.addEventListener(el.tagName === 'BUTTON' ? 'click' : 'input', function () {
          if (dirtyEl) dirtyEl.style.display = '';
        });
      });
    }
  }

  async function reloadStoreGroups() {
    var results = await fetchAllStoreRows();
    storeGroups = groupByStore(results);
    surplusTotal = results.reduce(function (a, r) { return a + (Number(r.data.surplus) || 0); }, 0);
    if (currentStoreId === null && storeGroups.length > 0) currentStoreId = storeGroups[0].storeId;
  }

  async function initPacking() {
    try {
      await reloadStoreGroups();
      renderHeader();
      renderChips();
      renderDetail();
    } catch (e) {
      document.getElementById('fg-packing-header').innerHTML = '<div class="alert alert-danger">' + escHtml(e.message) + '</div>';
    }
  }
  // window.Amor is defined by assets/js/app.js, whose <script> tag is
  // rendered by ui_page_foot() AFTER this page's own inline <script> in
  // the HTML — a plain non-deferred <script src> still blocks the parser
  // until it loads, but only for what comes AFTER it, so calling
  // Amor.apiFetch immediately here (a plain top-level call, unlike
  // Verifikasi's own Amor calls, which only ever run inside a LATER click
  // handler) would run before app.js has ever been requested. The Packing
  // step's very first fetch is deferred to 'load' (fires once every
  // resource, including that later script, has finished) for exactly
  // this reason.
  window.addEventListener('load', initPacking);

  var submitAllBtn = document.getElementById('btn-submit-fg-packing');
  if (submitAllBtn) submitAllBtn.addEventListener('click', async function () {
    // Every verified piece must be packed and every Toko submitted first —
    // otherwise Submit FG would add less stock than was verified and the
    // missing pieces could never be shipped.
    function pendingStores() {
      return storeGroups.filter(function (g) {
        var st = storeStatus(g);
        var ready = 0, packed = 0;
        g.rows.forEach(function (r) { if (r.exploded) { ready += r.fgVerified; packed += r.packed; } });
        return ready > 0.0001 && (st.code !== 'sudah_disubmit' || packed + 0.0001 < ready);
      }).map(function (g) { return g.storeName; });
    }
    var pending = pendingStores();
    if (pending.length > 0) {
      // The list may still be refreshing after the last "Submit Packing"
      // (one request per product) — re-check against the server before
      // telling the operator a store is unfinished.
      submitAllBtn.disabled = true;
      try { await reloadStoreGroups(); renderHeader(); renderChips(); } catch (e) { /* keep the old list */ }
      submitAllBtn.disabled = false;
      pending = pendingStores();
    }
    if (pending.length > 0) {
      Amor.toast('Packing belum selesai untuk: ' + pending.join(', ') + '. Selesaikan dan Submit Packing per toko dulu.', 'danger');
      return;
    }
    var ok = await Amor.confirmModal({ title: 'Submit FG?', body: 'Semua toko sudah dipacking. Stok FG siap kirim akan bertambah sesuai jumlah Packed.', confirmLabel: 'Ya, Submit' });
    if (!ok) return;
    submitAllBtn.disabled = true;
    try {
      await Amor.apiFetch('/api/fg/' + batchId + '/submit', { method: 'POST', body: { expectedVersion: version } });
      Amor.toast('FG berhasil disubmit.', 'success');
      setTimeout(function () { location.reload(); }, 600);
    } catch (e) { Amor.toast(e.message, 'danger'); submitAllBtn.disabled = false; }
  });

  var reopenBtn2 = document.getElementById('btn-reopen-fg-packing');
  if (reopenBtn2) reopenBtn2.addEventListener('click', async function () {
    var reason = prompt('Alasan membuka kembali FG ini (wajib):');
    if (!reason) return;
    reopenBtn2.disabled = true;
    try {
      await Amor.apiFetch('/api/fg/' + batchId + '/reopen', { method: 'POST', body: { expectedVersion: version, reason: reason } });
      Amor.toast('FG dibuka kembali.', 'success');
      setTimeout(function () { location.reload(); }, 600);
    } catch (e) { Amor.toast(e.message, 'danger'); reopenBtn2.disabled = false; }
  });
})();
</script>

<?php elseif ($targetView !== null): ?>
<div class="card section">
  <div class="card-head"><h2 class="card-title">Hasil Produksi Siap Diverifikasi</h2></div>
  <?php if ($targetView['items'] === []): ?>
    <?= ui_empty_state('Belum ada produksi yang disubmit', 'Tunggu divisi produksi submit hasilnya untuk tanggal & pabrik ini.') ?>
  <?php else: ?>
  <div class="table-scroll"><table class="data-table">
    <thead><tr><th>Produk</th><th class="num">Hasil Produksi</th></tr></thead>
    <tbody>
    <?php foreach ($targetView['items'] as $it): ?>
    <tr><td><?= ui_esc($it['productName']) ?></td><td class="num"><?= ui_fmt_num($it['actual']) ?></td></tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <button type="button" class="btn btn-primary" style="margin-top:var(--space-4);" id="btn-create-fg">Buat/Buka Draft FG</button>
  <script>
  document.getElementById('btn-create-fg').addEventListener('click', async function () {
    this.disabled = true;
    try {
      await Amor.apiFetch('/api/fg', { method: 'POST', body: { tanggal: <?= json_encode($uiTanggal) ?>, factoryId: <?= $uiFactoryId ?> } });
      Amor.toast('Draft FG dibuat.', 'success');
      setTimeout(function () { location.reload(); }, 500);
    } catch (e) { Amor.toast(e.message, 'danger'); this.disabled = false; }
  });
  </script>
  <?php endif; ?>
</div>
<?php endif; ?>
