# Amor Factory System — File Stok Masuk Runchise (migrations up to 0024)

Migration 0024 is additive: store.runchise_location, product.runchise_*,
shipment.runchise_downloaded_*, and the runchise_catalog table. Its
initial fill only touches still-empty mapping columns.

- Store Portal / QR page: after confirmation, "Unduh file stok masuk
  Runchise" (one CSV per surat jalan, received-good qty only).
- Pengaturan → Mapping Runchise: catalog upload, store/product mapping,
  per-shipment preview & download.
- finhub feed: runchiseDownloadedAt + runchiseLocation per shipment.
- Includes everything up to 0023 and the perbaikan-celah fixes.

A server still at 0016-0023 is brought to 0024 by api/_upgrade/.
