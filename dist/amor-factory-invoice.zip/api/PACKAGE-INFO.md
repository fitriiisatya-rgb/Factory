# Amor Factory System — Invoice (migration 0018)

Purely additive on top of 0001-0017 — ONE brand-new table
(invoice_mutasi). The pre-existing Phase 1 placeholder tables
(invoice, invoice_item, invoice_shipment, payment — schema-v1.sql,
migration 0001, previously unused by any live code) are now wired up
for real, as-is, with zero ALTER.

Invoice is auto-calculated (never manually typed) from real
Shipment/Mutasi data:
  - Billable qty per product = confirmed-received qty across every
    eligible Shipment in the chosen store+date-range window
    (received_good_qty already excludes a verified Reject by
    construction — no separate Reject-subtraction logic needed), net
    of completed Mutasi movement (a completed Mutasi moves its
    qty_received fully from the SOURCE store's billable pool to the
    DESTINATION store's, never double-billed on either side).
  - Only a CONFIRMED receipt (confirmed_ok or Admin-verified) and only
    a COMPLETED Mutasi are ever eligible — a still-open discrepancy is
    excluded until Admin resolves it.
  - ONE Invoice can bundle MANY Shipments for one store across a
    chosen date range.
  - Void is a hard delete (cascades to invoice_item/invoice_shipment/
    invoice_mutasi), releasing every shipment/mutasi it had consumed
    back into the eligible pool — safe because the `payment` table
    remains completely out of this phase's scope.
  - rate_pct/rate_source/override_reason exist on the underlying Phase 1
    tables but are explicitly NOT used by this phase (confirmed with
    the user) — every row carries rate_pct=100.00 (full price, no
    adjustment), a placeholder for a future consignment/discount
    feature.

Admin UI: Invoice (sidebar) — generate/preview per store+period, list,
detail, print (reuses the existing print-invoice-template.php design
unchanged — the pre-existing mock preview at
api/_ui-preview/invoice-preview.php is kept, untouched, for its own
regression suite), void.

Laporan gained two new period-based sections: Omset/Penjualan per
Toko & Periode (from real Invoice totals) and Retur & Reject per
Periode (from retur_request and shipment_receipt_item) — each with its
own date-range filter, independent of the page's existing single-day
operational-funnel filter. Laporan stays 100% read-only.
