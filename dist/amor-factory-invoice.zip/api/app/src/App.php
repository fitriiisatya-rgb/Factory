<?php

declare(strict_types=1);

namespace Amor\Api;

use Amor\Api\Controllers\Admin\MigrationController;
use Amor\Api\Controllers\AuthController;
use Amor\Api\Controllers\DashboardController;
use Amor\Api\Controllers\DispatchController;
use Amor\Api\Controllers\DivisionController;
use Amor\Api\Controllers\DoController;
use Amor\Api\Controllers\InvoiceController;
use Amor\Api\Controllers\FactoryController;
use Amor\Api\Controllers\FgController;
use Amor\Api\Controllers\HealthController;
use Amor\Api\Controllers\PoController;
use Amor\Api\Controllers\ProductController;
use Amor\Api\Controllers\ProductionController;
use Amor\Api\Controllers\ReceiptController;
use Amor\Api\Controllers\ShipmentEmailController;
use Amor\Api\Controllers\ProductionTaskController;
use Amor\Api\Controllers\ReplacementController;
use Amor\Api\Controllers\SpecialOrderController;
use Amor\Api\Controllers\SpecialOrderDoController;
use Amor\Api\Controllers\StoreController;
use Amor\Api\Controllers\StorePortalAdminController;
use Amor\Api\Controllers\StorePortalController;
use Amor\Api\Controllers\UserController;

/**
 * Wires routes + cross-cutting guards. Shared by the real front controller
 * (public/index.php) and the test harness, so both exercise identical
 * routing/middleware behavior.
 */
final class App
{
    private const CSRF_EXEMPT = [
        'POST /api/auth/login', // no session exists yet to hold a CSRF token
    ];

    public static function run(Request $request): void
    {
        date_default_timezone_set((string) Config::get('APP_TIMEZONE', 'UTC'));
        Auth::bootSession();

        $router = new Router();

        $router->get('/api/health', [HealthController::class, 'index']);

        $router->post('/api/auth/login', [AuthController::class, 'login']);
        $router->post('/api/auth/logout', [AuthController::class, 'logout']);
        $router->get('/api/auth/me', [AuthController::class, 'me']);

        $router->get('/api/factories', [FactoryController::class, 'index']);
        $router->get('/api/divisions', [DivisionController::class, 'index']);

        $router->get('/api/products', [ProductController::class, 'index']);
        $router->get('/api/products/{id}', [ProductController::class, 'show']);
        $router->post('/api/products', [ProductController::class, 'create']);
        $router->put('/api/products/{id}', [ProductController::class, 'update']);
        $router->post('/api/products/{id}/aliases', [ProductController::class, 'addAlias']);

        $router->get('/api/stores', [StoreController::class, 'index']);
        $router->get('/api/stores/{id}', [StoreController::class, 'show']);
        $router->post('/api/stores', [StoreController::class, 'create']);
        $router->put('/api/stores/{id}', [StoreController::class, 'update']);
        $router->post('/api/stores/{id}/aliases', [StoreController::class, 'addAlias']);

        $router->get('/api/po', [PoController::class, 'index']);
        $router->get('/api/po/current', [PoController::class, 'current']);
        $router->get('/api/po/history', [PoController::class, 'history']);
        $router->post('/api/po/preview', [PoController::class, 'preview']);
        $router->post('/api/po/import', [PoController::class, 'import']);
        $router->get('/api/po/{batchId}', [PoController::class, 'show']);

        $router->get('/api/production/target', [ProductionController::class, 'target']);
        $router->get('/api/production/history', [ProductionController::class, 'history']);
        $router->get('/api/production', [ProductionController::class, 'index']);
        $router->post('/api/production', [ProductionController::class, 'create']);
        $router->get('/api/production/{id}', [ProductionController::class, 'show']);
        $router->patch('/api/production/{id}', [ProductionController::class, 'update']);
        $router->post('/api/production/{id}/submit', [ProductionController::class, 'submit']);
        $router->post('/api/production/{id}/reopen', [ProductionController::class, 'reopen']);

        $router->get('/api/fg/target', [FgController::class, 'target']);
        $router->get('/api/fg/availability', [FgController::class, 'availability']);
        $router->get('/api/fg/store-breakdown', [FgController::class, 'storeBreakdown']);
        $router->get('/api/fg/{id}/items/{productId}/stores', [FgController::class, 'productStores']);
        $router->get('/api/fg/history', [FgController::class, 'history']);
        $router->get('/api/fg', [FgController::class, 'index']);
        $router->post('/api/fg', [FgController::class, 'create']);
        $router->get('/api/fg/{id}', [FgController::class, 'show']);
        $router->patch('/api/fg/{id}', [FgController::class, 'update']);
        $router->post('/api/fg/{id}/packing-submit', [FgController::class, 'packingSubmitStore']);
        $router->post('/api/fg/{id}/refresh-source', [FgController::class, 'refreshSource']);
        $router->post('/api/fg/{id}/submit', [FgController::class, 'submit']);
        $router->post('/api/fg/{id}/reopen', [FgController::class, 'reopen']);

        $router->get('/api/do/preview', [DoController::class, 'preview']);
        $router->get('/api/do/stores', [DoController::class, 'stores']);
        $router->get('/api/do/history', [DoController::class, 'history']);
        $router->get('/api/do', [DoController::class, 'index']);
        $router->post('/api/do', [DoController::class, 'create']);
        $router->post('/api/do/generate-bulk', [DoController::class, 'generateBulk']);
        $router->get('/api/do/{id}', [DoController::class, 'show']);
        $router->post('/api/do/{id}/preprint', [DoController::class, 'preprint']);
        $router->post('/api/do/{id}/refresh-po', [DoController::class, 'refreshPo']);
        $router->post('/api/do/{id}/cancel', [DoController::class, 'cancel']);
        $router->get('/api/do/{id}/shipments', [DoController::class, 'shipments']);
        $router->post('/api/do/{id}/shipment-preview', [DoController::class, 'shipmentPreview']);
        $router->post('/api/do/{id}/ship', [DoController::class, 'ship']);

        $router->get('/api/invoices/preview', [InvoiceController::class, 'preview']);
        $router->get('/api/invoices', [InvoiceController::class, 'index']);
        $router->post('/api/invoices', [InvoiceController::class, 'generate']);
        $router->get('/api/invoices/{id}', [InvoiceController::class, 'show']);
        $router->post('/api/invoices/{id}/void', [InvoiceController::class, 'void']);

        $router->get('/api/dashboard/summary', [DashboardController::class, 'summary']);

        $router->get('/api/admin/migration/products', [MigrationController::class, 'indexProducts']);
        $router->post('/api/admin/migration/products/{id}/resolve', [MigrationController::class, 'resolveProduct']);
        $router->post('/api/admin/migration/products/{id}/flag-conflict', [MigrationController::class, 'flagConflictProduct']);
        $router->get('/api/admin/migration/stores', [MigrationController::class, 'indexStores']);
        $router->post('/api/admin/migration/stores/{id}/resolve', [MigrationController::class, 'resolveStore']);
        $router->post('/api/admin/migration/stores/{id}/flag-conflict', [MigrationController::class, 'flagConflictStore']);

        // Phase 5.5 — Driver portal (session auth + role DRIVER/ADMIN, CSRF required like every other mutating route).
        $router->get('/api/dispatch/available', [DispatchController::class, 'available']);
        $router->post('/api/dispatch/claim', [DispatchController::class, 'claim']);
        $router->post('/api/dispatch/claims/{id}/release', [DispatchController::class, 'release']);
        $router->get('/api/dispatch/mine', [DispatchController::class, 'mine']);
        $router->get('/api/dispatch/route', [DispatchController::class, 'route']);
        $router->post('/api/dispatch/route/reorder', [DispatchController::class, 'reorderRoute']);
        $router->get('/api/dispatch/route/stops/{storeId}', [DispatchController::class, 'stopDetail']);
        $router->get('/api/dispatch/route/stops/{storeId}/shipments', [DispatchController::class, 'stopShipments']);
        $router->post('/api/dispatch/departures', [DispatchController::class, 'departures']);
        $router->get('/api/dispatch/history', [DispatchController::class, 'history']);
        $router->get('/api/dispatch/shipments/{id}', [DispatchController::class, 'shipmentDetail']);

        // Phase 5.5 — Store Receipt portal. PUBLIC (no session): the
        // high-entropy {token} path segment IS the access control, never a
        // raw delivery_order_id — see ReceiptController's own docblock.
        $router->get('/api/receive/{token}', [ReceiptController::class, 'publicView']);
        $router->post('/api/receive/{token}/shipments/{shipmentId}/confirm', [ReceiptController::class, 'confirm']);

        // Phase 5.5 — Admin discrepancy verification (ADMIN-only, normal session/CSRF).
        // Evidence is STORE evidence, uploaded only via the public confirm()
        // route above — Admin is view/verify-only, so there is deliberately
        // NO admin-side evidence upload route (real-UAT role correction; see
        // ReceiptController::adminEvidence()'s own docblock).
        $router->get('/api/admin/receipts', [ReceiptController::class, 'adminList']);
        $router->post('/api/admin/receipts/{id}/verify', [ReceiptController::class, 'adminVerify']);
        $router->get('/api/admin/receipts/evidence/{id}', [ReceiptController::class, 'adminEvidence']);

        // Phase 5.5 finalization — automatic Bakery email / Digital Surat
        // Jalan / Admin resend (ADMIN-only, normal session/CSRF).
        $router->post('/api/admin/shipments/{shipmentId}/email/resend', [ShipmentEmailController::class, 'resend']);

        // Migration 0010 — Pesanan Khusus Toko / Pesanan Non-Toko + Production
        // routing. ADMIN/PPIC create+mutate; any authenticated role (incl.
        // PRODUCTION) can read the list/detail/production-inbox views.
        // Never touches po_batch/po_item/po_store_item (PO Reguler Toko).
        $router->get('/api/special-orders/catalog', [SpecialOrderController::class, 'catalog']);
        $router->get('/api/special-orders/production-inbox', [SpecialOrderController::class, 'productionInbox']);
        $router->get('/api/special-orders/fg-eligible', [SpecialOrderController::class, 'fgEligible']);
        $router->post('/api/special-orders/items/{itemId}/verify-fg', [SpecialOrderController::class, 'verifyItemFg']);
        $router->post('/api/special-orders/items/{itemId}/allocate-fg', [SpecialOrderController::class, 'allocateFg']);
        $router->post('/api/special-order-fg-allocations/{id}/release', [SpecialOrderController::class, 'releaseFgAllocation']);
        $router->get('/api/special-orders', [SpecialOrderController::class, 'index']);
        $router->post('/api/special-orders', [SpecialOrderController::class, 'create']);
        $router->get('/api/special-orders/{id}', [SpecialOrderController::class, 'show']);
        $router->get('/api/admin/special-orders/attachments/{id}', [SpecialOrderController::class, 'attachment']);
        $router->post('/api/special-orders/{id}/confirm', [SpecialOrderController::class, 'confirm']);
        $router->post('/api/special-orders/{id}/send-to-production', [SpecialOrderController::class, 'sendToProduction']);
        $router->post('/api/special-orders/{id}/status', [SpecialOrderController::class, 'updateStatus']);
        $router->post('/api/special-orders/{id}/actual', [SpecialOrderController::class, 'updateItemsActual']);
        $router->post('/api/special-orders/{id}/cancel', [SpecialOrderController::class, 'cancel']);

        $router->get('/api/special-order-do/driver-pool', [SpecialOrderDoController::class, 'driverPool']);
        $router->get('/api/special-order-do', [SpecialOrderDoController::class, 'index']);
        $router->post('/api/special-order-do', [SpecialOrderDoController::class, 'create']);
        $router->get('/api/special-order-do/{id}', [SpecialOrderDoController::class, 'show']);
        $router->post('/api/special-order-do/{id}/claim', [SpecialOrderDoController::class, 'claim']);
        $router->post('/api/special-order-do/{id}/release', [SpecialOrderDoController::class, 'release']);
        $router->post('/api/special-order-do/{id}/cancel', [SpecialOrderDoController::class, 'cancel']);
        $router->post('/api/special-order-do/{id}/delivery-method', [SpecialOrderDoController::class, 'changeDeliveryMethod']);
        $router->post('/api/special-order-do/{id}/depart', [SpecialOrderDoController::class, 'depart']);
        $router->post('/api/special-order-do/{id}/courier-handover', [SpecialOrderDoController::class, 'courierHandover']);
        $router->get('/api/production-tasks/factory', [ProductionTaskController::class, 'forFactory']);
        $router->get('/api/production-tasks', [ProductionTaskController::class, 'forDivision']);

        // Migration 0016 — Replacement Reject. Disposition (ADMIN/PPIC)
        // is the one and only place a verified Reject's fate is decided;
        // everything downstream (production actual/FG verify, DO,
        // shipment) reuses the same role tiers as the equivalent Regular/
        // Special actions — see ReplacementController's own docblock.
        $router->get('/api/replacement/pending-disposition', [ReplacementController::class, 'pendingDisposition']);
        $router->post('/api/replacement/receipt-items/{id}/disposition', [ReplacementController::class, 'disposeReject']);
        $router->get('/api/replacement-demands', [ReplacementController::class, 'index']);
        $router->get('/api/replacement-demands/{id}', [ReplacementController::class, 'show']);
        $router->post('/api/replacement-demands/{id}/production-actual', [ReplacementController::class, 'updateProductionActual']);
        $router->post('/api/replacement-demands/{id}/verify-fg', [ReplacementController::class, 'verifyFg']);
        $router->post('/api/replacement-demands/{id}/do', [ReplacementController::class, 'createDo']);
        $router->get('/api/replacement-do/{id}', [ReplacementController::class, 'showDo']);
        $router->post('/api/replacement-do/{id}/ship', [ReplacementController::class, 'ship']);

        // Migration 0017 — Permanent Bakery Portal. PUBLIC (no session): the
        // permanent {token} path segment IS the access control, resolved
        // ONLY via StorePortalService::resolvePortalIdentity() — never a
        // raw store_id — same discipline as /api/receive/{token} above.
        // Menu 1 (Konfirmasi Penerimaan, Reject included) only for now;
        // Pesanan Khusus/Retur/Mutasi/Riwayat routes are added alongside
        // their own controllers' tasks.
        $router->get('/api/store/{token}', [StorePortalController::class, 'bootstrap']);
        $router->get('/api/store/{token}/receipts', [StorePortalController::class, 'receiptList']);
        $router->get('/api/store/{token}/receipts/{shipmentId}', [StorePortalController::class, 'receiptDetail']);
        $router->post('/api/store/{token}/receipts/{shipmentId}/confirm', [StorePortalController::class, 'receiptConfirm']);
        $router->get('/api/store/{token}/special-orders', [StorePortalController::class, 'specialOrderList']);
        $router->post('/api/store/{token}/special-orders', [StorePortalController::class, 'specialOrderCreate']);
        $router->get('/api/store/{token}/special-orders/{orderId}', [StorePortalController::class, 'specialOrderDetail']);
        $router->get('/api/store/{token}/special-orders/{orderId}/attachments/{attachmentId}', [StorePortalController::class, 'specialOrderAttachment']);
        $router->get('/api/store/{token}/retur', [StorePortalController::class, 'returList']);
        $router->post('/api/store/{token}/retur', [StorePortalController::class, 'returCreate']);
        $router->get('/api/store/{token}/retur/{returId}', [StorePortalController::class, 'returDetail']);
        $router->get('/api/store/{token}/mutasi/incoming', [StorePortalController::class, 'mutasiIncomingPending']);
        $router->get('/api/store/{token}/mutasi/outgoing', [StorePortalController::class, 'mutasiOutgoing']);
        $router->get('/api/store/{token}/mutasi/incoming-history', [StorePortalController::class, 'mutasiIncomingHistory']);
        $router->post('/api/store/{token}/mutasi', [StorePortalController::class, 'mutasiCreate']);
        $router->get('/api/store/{token}/mutasi/{mutasiId}', [StorePortalController::class, 'mutasiDetail']);
        $router->post('/api/store/{token}/mutasi/{mutasiId}/confirm', [StorePortalController::class, 'mutasiConfirm']);

        // Permanent Bakery Portal — ADMIN-only side (ADMIN role, normal
        // session/CSRF/Idempotency-Key, nothing special-cased). Pesanan
        // Khusus review has NO new route here — the existing
        // /api/special-orders/{id}/confirm|cancel already serve a
        // portal-submitted toko_khusus order exactly like any other.
        $router->get('/api/admin/store-portal/{storeId}/status', [StorePortalAdminController::class, 'tokenStatus']);
        $router->get('/api/admin/store-portal/{storeId}/history', [StorePortalAdminController::class, 'tokenHistory']);
        $router->post('/api/admin/store-portal/{storeId}/issue', [StorePortalAdminController::class, 'tokenIssue']);
        $router->post('/api/admin/store-portal/{storeId}/revoke', [StorePortalAdminController::class, 'tokenRevoke']);
        $router->get('/api/admin/retur', [StorePortalAdminController::class, 'returList']);
        $router->get('/api/admin/retur/evidence/{id}', [StorePortalAdminController::class, 'returEvidence']);
        $router->get('/api/admin/retur/{id}', [StorePortalAdminController::class, 'returShow']);
        $router->post('/api/admin/retur/{id}/verify', [StorePortalAdminController::class, 'returVerify']);
        $router->post('/api/admin/retur/{id}/reject', [StorePortalAdminController::class, 'returReject']);
        $router->get('/api/admin/mutasi', [StorePortalAdminController::class, 'mutasiList']);
        $router->get('/api/admin/mutasi/evidence/{id}', [StorePortalAdminController::class, 'mutasiEvidence']);
        $router->get('/api/admin/mutasi/{id}', [StorePortalAdminController::class, 'mutasiShow']);
        $router->post('/api/admin/mutasi/{id}/review', [StorePortalAdminController::class, 'mutasiReview']);

        // User / Driver Account Management (ADMIN-only, normal session/CSRF/Idempotency-Key —
        // same guards as every other mutating route, nothing special-cased).
        $router->get('/api/users', [UserController::class, 'index']);
        $router->post('/api/users', [UserController::class, 'create']);
        $router->put('/api/users/{id}', [UserController::class, 'update']);
        $router->put('/api/users/{id}/roles', [UserController::class, 'updateRoles']);
        $router->put('/api/users/{id}/divisions', [UserController::class, 'updateDivisionAccess']);
        $router->put('/api/users/{id}/factories', [UserController::class, 'updateFactoryAccess']);
        $router->post('/api/users/{id}/reset-password', [UserController::class, 'resetPassword']);
        $router->post('/api/users/{id}/activate', [UserController::class, 'activate']);
        $router->post('/api/users/{id}/deactivate', [UserController::class, 'deactivate']);

        $routeKey = $request->method . ' ' . $request->path;
        // The public receipt-confirm route has no session, so it has no CSRF
        // token to check — same "no session exists yet" reasoning as the
        // login exemption above, scoped by prefix since {token}/{shipmentId}
        // are dynamic segments a literal CSRF_EXEMPT string can't match.
        $isPublicReceiptConfirm = $request->method === 'POST' && str_starts_with($request->path, '/api/receive/');
        // Permanent Bakery Portal (migration 0017) — same "no session, so
        // no CSRF token to check" reasoning, scoped by prefix for the same
        // dynamic-{token}-segment reason as the receive/ exemption above.
        $isPublicStorePortal = $request->method === 'POST' && str_starts_with($request->path, '/api/store/');
        if ($request->method !== 'GET' && !in_array($routeKey, self::CSRF_EXEMPT, true) && !$isPublicReceiptConfirm && !$isPublicStorePortal) {
            // CSRF is checked centrally, before the handler runs, per
            // docs/php-api-contract-v1.md §1 rule 3 — no handler can forget it.
            Csrf::verify($request);
        }

        $router->dispatch($request);
    }
}
