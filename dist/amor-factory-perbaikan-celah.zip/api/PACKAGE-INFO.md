# Amor Factory System — Pesanan Khusus & deep-check fixes (migrations up to 0023)

Migration 0023 only changes invoice_item (nullable product_id, four new
columns, unique key now per order line). No data is deleted or changed.

- Pesanan Khusus Toko invoiced at the order price (+ biaya/kemasan once).
- Pesanan Non-Toko never invoiced to the drop bakery; omset = shipped qty.
- Status Selesai automatic once fully shipped (pickup: once FG-ready).
- DO khusus capped at ordered qty; cancelling an order cancels open DOs.
- Number inputs fixed for values >= 1000 and decimals.
- Role scoping fixes for divisi/FG, driver and mutasi edge cases.
- Includes everything from the Integrasi finhub release (0022).

A server still at 0016-0022 is brought to 0023 by api/_upgrade/.
