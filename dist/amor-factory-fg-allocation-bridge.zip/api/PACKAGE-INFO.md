# Amor Factory System — Existing FG Allocation Bridge

Migration 0012 was STILL UNAPPLIED to any live database when this pass
started (confirmed via schema_migrations) — this EXTENDS 0012 in place
(adds special_order_fg_allocation + widens stock_ledger.source_type),
never a new 0013.

What this pass fixes: a real cPanel UAT found that a special/non-regular
order's existing-product line could NOT proceed toward DO/fulfillment
unless special_order_item.aktual_produksi > 0, even when EXISTING general
FG (stock_balance, the SAME pool Regular PO ships from) already had
enough stock to satisfy the order — a dead end. This pass lets such an
order draw from existing general FG first, and only requires NEW
production for the shortfall.

Architecture (see SpecialOrder/SpecialOrderFgAllocationService.php's own
docblock for the full detail):
- special_order_fg_allocation is an EARMARK, never a physical stock
  movement — allocate()/release() NEVER write stock_ledger.
- "True free FG" = physical stock_balance MINUS every other order's
  still-active allocation for the same product+factory — computed under
  the SAME stock_balance row lock Regular PO's own ShipmentService::
  ship() uses, so two concurrent allocation attempts against the same
  stock can never both succeed beyond what's physically free.
- Applies ONLY to item_type=existing_product lines — a custom/
  special_catalog item can never consume general FG.
- A real dispatch (confirmDeparture/courierHandover) may fulfill a single
  line from BOTH General FG allocation and special production FG in the
  SAME shipment — General FG is consumed FIRST, then special-production
  FG, and the split is tracked without ever double-deducting.
- Order cancellation releases any still-active, unconsumed allocation
  back to the free pool; already-consumed (physically shipped) qty is
  never reversed by a cancel.
- Task per Divisi's production target nets out whatever General FG is
  already allocated — an order fully covered by existing FG shows ZERO
  production target, never the raw order qty.
- Source identity (SPECIAL_STORE_ORDER/CS_ORDER/SALES_ORDER/
  DIRECT_CUSTOMER/GENERAL_ORDER) is preserved throughout every new/
  touched screen — no regression of the prior pass's own fix.
- Regular PO (po_batch/po_item/po_store_item/delivery_order/shipment/
  shipment_item) is completely unchanged by this pass.

New UI: Produksi -> Order Masuk / Demand Tambahan shows FG Tersedia,
Sudah Dialokasikan, Kebutuhan Produksi, and an explicit "Alokasikan dari
FG" action (never silent/automatic) with a confirmation modal; FG Khusus/
Non-Toko now shows "1. Dari FG Existing" / "2. Dari Produksi Khusus" /
"Total Siap untuk Order" as two clearly separate fulfillment origins.
