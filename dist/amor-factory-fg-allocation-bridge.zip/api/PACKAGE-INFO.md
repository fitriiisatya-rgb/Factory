# Amor Factory System — Existing FG Allocation Bridge

Migration 0012 was STILL UNAPPLIED to any live database when this pass
started (confirmed via schema_migrations) — this EXTENDS 0012 in place
(adds special_order_fg_allocation + widens stock_ledger.source_type),
never a new 0013.

What this pass fixes: a real cPanel UAT found that a special/non-regular
order's existing-product line could NOT proceed toward DO/fulfillment
unless special_order_item.aktual_produksi > 0, even when EXISTING general
FG (stock_balance, the SAME pool Regular PO ships from) already had
enough stock to satisfy the order — a dead end. This pass lets such an
order draw from existing general FG first, and only requires NEW
production for the shortfall.

GLOBAL RESERVATION (cross-flow deep-check fix, added after the first real
cPanel UAT of this feature found Regular PO could still ship stock a
special order had already reserved): "True free FG" is a SINGLE
authoritative formula — physical stock_balance MINUS every ACTIVE
special-order reservation for that product+factory — consulted
consistently by EVERY flow that consumes General FG, not only special-
order allocation:
- SpecialOrder\SpecialOrderFgAllocationService::allocate() (a NEW
  allocation can never exceed true free FG).
- Delivery\ShipmentService::preview()/ship() (Regular PO can no longer
  preview or ship stock a special order has reserved).
- Delivery\DoService::getDo() (the real Kirim/ship-form page's own FG
  Available column — so the UI never shows a number the server would
  then reject).
- Dispatch\DispatchService's driver-facing "Konfirmasi Berangkat" actual-
  qty screen (same consistency, for the same reason).
Every one of these locks the stock_balance row FIRST (the SAME
lockBalance() Regular PO's own ShipmentService::ship() always used), for
the WHOLE read-decide-write sequence — this is what makes a concurrent
Regular ship() and a concurrent special allocate()/dispatch for the same
product+location serialize correctly instead of both reading a stale
"free" number. The active-allocation SUM itself is a REQUIRED locking
read (`FOR UPDATE`), not a plain SELECT — under MariaDB/InnoDB
REPEATABLE READ, a plain read can still see a stale snapshot from before
a concurrent commit even while sitting inside a transaction that already
holds the fresher stock_balance lock; this was caught by a real two-
process concurrency test that intermittently failed before the fix.

Architecture (see SpecialOrder/SpecialOrderFgAllocationService.php's own
docblock for the full detail):
- special_order_fg_allocation is an EARMARK, never a physical stock
  movement — allocate()/release() NEVER write stock_ledger. A real
  dispatch consuming General FG allocation ALSO re-locks and re-verifies
  the real physical stock_balance immediately before writing its ledger
  deduction — an allocation existing is never treated as proof physical
  stock is still there.
- Applies ONLY to item_type=existing_product lines — a custom/
  special_catalog item can never consume general FG.
- A real dispatch (confirmDeparture/courierHandover) may fulfill a single
  line from BOTH General FG allocation and special production FG in the
  SAME shipment — General FG is consumed FIRST, then special-production
  FG, and the split is tracked without ever double-deducting.
- Order cancellation releases any still-active, unconsumed allocation
  back to the free pool; already-consumed (physically shipped) qty is
  never reversed by a cancel.
- Task per Divisi's production target nets out whatever General FG is
  already allocated — an order fully covered by existing FG shows ZERO
  production target, never the raw order qty.
- Source identity (SPECIAL_STORE_ORDER/CS_ORDER/SALES_ORDER/
  DIRECT_CUSTOMER/GENERAL_ORDER) is preserved throughout every new/
  touched screen — no regression of the prior pass's own fix.
- FG Verified guard (SpecialOrderService::verifyItemFg()) now floors
  against shippedFromSpecial ONLY, never the total shipped qty — an
  order fulfilled entirely from General FG allocation can keep
  fgVerifiedQty at 0 even after full shipment; a mixed order (general 35
  + special 5) only ever requires fgVerifiedQty >= 5, never >= 40.
- Regular PO's own demand model (po_batch/po_item/po_store_item/
  delivery_order/shipment/shipment_item) is untouched, and its shipment
  BEHAVIOR is unchanged whenever no special-order reservation exists for
  a product+factory (verified: Regular PO ships its full physical stock
  exactly as before when nothing is reserved) — the cross-flow fix only
  ever REDUCES the FG a Regular shipment can see when a special order has
  actually reserved some of it.

New UI: Produksi -> Order Masuk / Demand Tambahan shows FG Tersedia,
Sudah Dialokasikan, Kebutuhan Produksi, and an explicit "Alokasikan dari
FG" action (never silent/automatic) with a confirmation modal; FG Khusus/
Non-Toko now shows "1. Dari FG Existing" / "2. Dari Produksi Khusus" /
"Total Siap untuk Order" as two clearly separate fulfillment origins.
