# Amor Factory System — Replacement Reject Discovery Hardening (Legacy Verified Rejects)

Live-UAT blocker fix (SHP-6 report): CODE ONLY, no new migration.

## Root cause

Proven via a raw-SQL row insert that bypasses all application code
entirely (REJECT-MISSING-02): ReplacementRepository::
findPendingDispositionItems()'s three real gates were already correct
for any receipt item created by ANY code path, past or present —
disposition is schema-defined NOT NULL DEFAULT 'pending' (migration
0016), so the database itself refuses a NULL write (confirmed directly
in that same test). No query bug was found.

A zero-cost defensive "disposition IS NULL OR disposition = 'pending'"
widening was still added, as belt-and-suspenders (prefer query
compatibility over any migration).

The reported live case (SHP-6) most plausibly traces to one of two
already-intentional, non-buggy states:
  1. Admin has not yet clicked "Verifikasi" for THAT specific shipment's
     own receipt (every shipment has its own separate receipt row/
     action).
  2. That receipt has a reported reject but ZERO store evidence photos,
     and is therefore correctly, permanently blocked from verification
     by Dispatch\ReceiptService::adminVerify()'s own existing
     EVIDENCE_REQUIRED_FOR_VERIFY rule (never silently bypassed).

## New diagnostic tool (dist/diagnostics/reject-missing-shp-check.sql)

A READ-ONLY SQL script (plain SELECTs only, no writes) to run against
the real database via phpMyAdmin. Given a real shipment_id, it reports
in plain language exactly which of the three discovery conditions that
shipment's reject currently satisfies or fails — including telling
"not yet verified" apart from "blocked on missing evidence" apart from
"already decided." This is NOT part of the deployed application — it is
a standalone diagnostic file, run manually and never automatically.

## What changed

1. ReplacementRepository::findPendingDispositionItems()'s WHERE clause
   now reads "(disposition IS NULL OR disposition = 'pending')" instead
   of the exact-match "disposition = 'pending'" — same result for every
   real row, structurally impossible to differ given the NOT NULL
   constraint, pure defense in depth.
2. dist/diagnostics/reject-missing-shp-check.sql (new, not part of the
   deployed app) — the read-only self-diagnostic tool above.

## What did NOT change

- reject_qty, receipt confirmation/verification logic, the mandatory-
  evidence-for-discrepancy-verify rule, stock_ledger, FG, Production, DO
  planned qty, invoice logic, and the Replacement allocation formula —
  none of these files were touched (enforced by this build script's own
  sanity guards).

## Tests

REJECT-MISSING-01..10 added to ProductionDivisionFgReworkTest.php,
including a raw-SQL "bypasses the app entirely" legacy-row simulation
and the exact SHP-6-equivalent reproduction (sent 10/good 8/reject 2)
confirming it appears correctly pending once genuinely verified. Full
regression green: the PDFG/Special Order/Replacement Reject/
FG-Allocation cascade (145+35 tests) and Phase 5.5 (107/107 + full
P55-24 stack), 0 failures.
