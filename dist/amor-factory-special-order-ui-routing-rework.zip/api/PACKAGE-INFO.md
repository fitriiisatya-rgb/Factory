# Amor Factory System — Pesanan Khusus Toko / Pesanan Non-Toko UI/UX Rework + Automatic Factory Routing

FILES ONLY — NO new migration. Ships on top of the already-applied
migration 0010 (special_order/special_order_item/special_order_catalog).

Quick facts:
- The create-form item table (bare, unstyled inputs squeezed into <td>
  cells) is replaced by readable .order-item-card cards — every field is
  labeled, uses the app's real dark controls, and Catatan Khusus is a
  full-width textarea.
- Root cause of the "native white control" bug: only `.field input,
  .field select` had dark styling — any bare/unwrapped control (and every
  textarea, even wrapped ones) fell back to the browser's native light
  rendering. Fixed with a real global baseline PLUS `color-scheme: dark`
  so native date/time pickers render dark too.
- Factory is no longer a manual dropdown — it is derived automatically,
  per item, from the item's production division via
  ProductionRoutingService (division.factory_id, an authoritative
  master-data column since migration 0002: Bolu -> Cibadak, every other
  division -> Karangtengah). A client-supplied factoryId is silently
  ignored; the server always computes its own.
- One order can span multiple divisions AND multiple factories — routing
  is resolved and shown PER ITEM, never forced to one factory for the
  whole order. The detail page's "Informasi Produksi" panel groups
  divisions under the factory each one really routes to.
- Fixed a real correctness bug along the way: Production's FG-shortage
  check used to read the order HEADER's factory_id, which is wrong (or
  null) for a multi-factory order — it now checks stock at each ITEM's
  own routed factory.
- Reuses the EXISTING dark navy Admin UI exactly — new CSS rules are
  token-only (var(--...)), no new hardcoded color, no new font-family.
