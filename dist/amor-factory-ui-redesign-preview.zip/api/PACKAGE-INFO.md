# Amor Factory System — UI/UX Redesign Preview Package

INCREMENTAL update for an existing Phase 5 (Draft DO / Shipment)
deployment. This domain's document root is public_html/factory/ —
extract this ZIP positioned INSIDE public_html/factory/ so it merges into
your existing public_html/factory/api/. It overwrites code files but
NEVER includes app/config/config.php, so your database credentials are
untouched.

**Start here**: dist/README-FIRST-CPANEL-UI-REDESIGN.md (delivered
alongside this ZIP) has the full step-by-step, non-technical guide. No
SQL. No CLI. No migration to apply — this package changes no schema.

Quick facts:
- Log in as ADMIN: api/_admin-login/ (unchanged)
- New UI: api/_ui-preview/ (requires login; every old UAT wizard is
  UNCHANGED and still reachable as a fallback: api/_import-po/,
  api/_production-uat/, api/_fg-uat/, api/_do-uat/)
- The new UI calls the SAME JSON API the old UAT wizards already call —
  no PO/Production/FG/DO/Shipment business logic was changed, weakened,
  or duplicated by this package.
- No new migration — this package adds one read-only endpoint (GET
  /api/dashboard/summary) and changes no table.
- The live JSON API's own front controller (api/index.php) is refreshed
  but NOT repointed anywhere — every existing integration keeps working.
