# Amor Factory System — Draft DO vs Actual Shipment Surat Jalan Separation Patch

FILES-ONLY INCREMENTAL patch for an existing Phase 5.5 + User Management +
FG Source Refresh + Driver UX/Navigation deployment. NO DATABASE MIGRATION
in this package.

Quick facts:
- Draft DO print (planning/picking, shows ALL planned DO items) is now
  titled unambiguously and never claims to be "Surat Jalan" any more.
- A brand-new SEPARATE document — Surat Jalan — prints ONLY ONE real
  shipment's actual items (shipment_item), reached via "Cetak Surat
  Jalan" on the Driver's Detail Pengiriman page, or the same route from
  Admin. A Driver can only print a shipment they themselves shipped
  (403 otherwise) — the exact rule the Detail Pengiriman page already
  enforced, reused unchanged.
- Surat Jalan reuses the SAME DO-level receipt QR every other shipment
  under that DO already shares — never a new token per shipment.
- Surat Jalan print styling is dot-matrix/3-ply friendly (no gradients,
  darker label text, configurable QR physical size for a print test:
  ?qr=35, ?qr=40 [default], or ?qr=50).
- This package does NOT touch stock deduction, Dispatch Claim/Release
  concurrency, Store Receipt confirm/verify math, QR token issuance,
  PO/Production/FG business logic, User Management, or Invoice preview.
