# Amor Factory — Phase 1 EASY V2 Package

INCREMENTAL update for an existing real deployment. This domain's document
root is public_html/factory/ — extract this ZIP positioned INSIDE
public_html/factory/ so it merges into your existing
public_html/factory/api/. It overwrites code files but NEVER includes
app/config/config.php, so your database credentials are untouched.

**Start here**: dist/README-FIRST-CPANEL-PHASE1-V2.md (delivered alongside
this ZIP) has the full step-by-step, non-technical guide. No SQL. No CLI.

Quick facts:
- Log in as ADMIN: api/_admin-login/ (temporary — delete after Phase 1)
- Apply the new migration: api/_upgrade/ (requires ADMIN login; uses a
  SEPARATE migration DB connection — MIGRATION_DB_* config keys, never the
  day-to-day DB_USER/DB_PASS; safe to leave in place permanently)
- Import master/identity data + review store candidates: api/_import-master/
  (requires ADMIN login; delete this folder once Phase 1 is reviewed)
- Still NOT imported: PO, production, FG, DO, shipment, stock, invoice,
  payment, returns, sales. Still NOT connected to the live frontend.
- Store master is NOT guaranteed complete just because this ZIP was
  installed — see the "Toko — Kandidat Review" section of
  api/_import-master/ for the 24 operator-provided candidate names that
  still need an explicit CONFIRM/SKIP per row.
