# Amor Factory System — Invoice UI / Print Template Preview Package

INCREMENTAL update for an existing Phase 5 (Draft DO / Shipment)
deployment. This domain's document root is public_html/factory/ —
extract this ZIP positioned INSIDE public_html/factory/ so it merges into
your existing public_html/factory/api/. It overwrites code files but
NEVER includes app/config/config.php, so your database credentials are
untouched.

**Start here**: dist/README-FIRST-CPANEL-INVOICE-UI.md (delivered
alongside this ZIP) has the full step-by-step, non-technical guide. No
SQL. No CLI. No migration to apply — this package changes no schema.

Quick facts:
- Log in as ADMIN: api/_admin-login/ (unchanged)
- New page: api/_ui-preview/invoice-preview.php — a READ-ONLY preview of
  the redesigned Invoice print template, using built-in MOCK/sample data
  (clearly labeled on screen). It does not read or write any real
  transaction, and it does not depend on any real toko/PO/DO/Shipment
  existing yet.
- Phase 6 (real Invoice creation, payment, receivable tracking) is NOT
  part of this package and has NOT been built. This page exists purely so
  the printed Invoice DESIGN can be reviewed ahead of that work.
- No PO/Production/FG/DO/Shipment business logic was changed, weakened,
  or duplicated by this package. The DO print header now shows the real
  Amor Group logo image (previously a plain letter mark) — everything
  else about DO printing is unchanged from the prior print redesign pass.
