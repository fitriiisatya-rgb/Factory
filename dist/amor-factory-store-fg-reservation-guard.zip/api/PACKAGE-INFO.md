# Amor Factory System — Store-Specific FG Reservation Guard (FINAL CORE BLOCKER fix)

Extends the "Production Division + FG & Packing rework" package with the
final closing piece of the Production -> FG -> DO -> Shipment core path:
Regular store shipment can no longer ship one store's Product X using FG
that was physically packed for a DIFFERENT store.

Migration 0014 is EXTENDED (still 0014, no 0015):
  - fg_item.posted_packed_qty — a frozen per-row snapshot of packed_qty as
    of that row's own last submit(), read by the store-ready guard instead
    of the live (possibly mid-edit) packed_qty.
  - store_fg_balance — a pure lock-anchor table (store_id, product_id,
    location_id), no cached quantity at all. "Packed" and "shipped" are
    always live-summed from fg_item/shipment_item — the same canonical
    tables the writable Breakdown Toko rework already introduced.

## What changed

1. Delivery\ShipmentService::ship()/preview() now ALSO check "store
   ready" (packed for this store, minus already shipped to this store)
   for Regular (source_type='delivery_order') shipments only.
   INSUFFICIENT_STORE_READY_FG / EXCEEDS_STORE_READY are the new codes.
2. This guard is GATED on DoRepository::hasAnyStoreAllocation() — a
   product still entirely in Per Produk mode (Breakdown Toko is
   optional) is completely unrestricted by store, exactly as before this
   fix.
3. Fg\FgService::submit() gains STORE_PACKED_BELOW_SHIPPED: a store's
   packed FG can never be corrected down below what has already been
   shipped to that store.
4. Collapsing a Breakdown Toko product back to Per Produk is refused
   (CANNOT_COLLAPSE_STORE_ALREADY_SHIPPED) once any of its stores has
   shipped history — collapsing would otherwise erase the per-store
   ownership data the guard depends on.
5. A PO revision that drops a store's target below its already-shipped/
   packed quantity surfaces a non-blocking "Perlu Review Ulang" flag
   (never silently reclaims stock).
6. A REPEATABLE READ concurrency bug (found by this task's own real
   two-process REGSTORE-07 test) is fixed: the store-ready SUM queries
   now take a locking read (FOR UPDATE) at every real-decision call site,
   never a plain SELECT that could see stale data even after correctly
   waiting on the new store_fg_balance lock.

## What did NOT change

- Special/CS/Sales/Direct/General order shipment (SpecialOrderDoService)
  — a structurally separate code path this guard never touches.
- Physical stock_ledger/stock_balance posting — still exactly once per
  shipment, same as before.
- DO can still be created before FG completion (planned demand only).
- Receipt — still never touches stock or store allocation.
- No shipment reversal/cancel-after-ship path exists in this codebase
  (DoService::cancel() already refuses once anything has shipped) — this
  fix does not add one; if a reversal capability is wanted, it is a
  separate, larger undertaking, reported rather than silently added.

15 new REGSTORE tests (REGSTORE-01..15), including two real concurrent-
process races, plus the full existing regression suite (PDFG-01..24,
FG-STORE-01..12, ALLOC-GLOBAL-01..20, ALLOC-01..15, FINAL-01..40, and
every earlier Phase 0-5.5 suite), all green.

## Known architecture limit (reported, not solved by this fix)

Nothing in this system currently allows a genuine RESERVATION of FG for
a store ahead of packing (only after packing is store ownership
established). This is intentional and matches the approved business
model ("Once FG Packing assigns ready quantity to Store A, that quantity
belongs to Store A") — it is not a gap, just worth stating explicitly.
