# Amor Factory System — Migration 0013: LIVE SCHEMA REPAIR

LIVE cPanel has 0012_production_flow_completion.php recorded as applied in
schema_migrations, but a direct authenticated diagnostic confirmed
special_order_fg_allocation does not exist there. This means 0012 was
applied live from an EARLIER revision of its own SQL file than the one
that shipped in the previous "Existing FG Allocation Bridge" package —
the migration runner tracks applied state by FILENAME only, so it never
re-executes 0012's current contents once that row exists.

This package adds ONE new migration, 0013_repair_production_flow_
completion.php. It does NOT delete, rename, or re-run the 0012 registry
row — 0012 stays exactly as already recorded. Every statement in 0013's
own SQL is additive and idempotent (safe against ANY of the plausible
live drift states, and a safe no-op if the live database already has
everything current final 0012 provides):
  - CREATE TABLE IF NOT EXISTS for every table 0012 introduces
    (special_order_do / special_order_do_item / special_order_do_
    shipment_item / shipment_receipt_token / special_order_fg_allocation).
  - ADD COLUMN IF NOT EXISTS for every column 0012 adds to an existing
    table (special_order_item.extra_packaging/fg_verified_qty, shipment's
    special_order_do_id/delivery_method/courier_*/handover_note,
    shipment_receipt_item's special_order_do_shipment_item_id/
    item_name_snapshot).
  - MODIFY COLUMN re-declarations for nullability changes and ENUM
    widening (shipment.source_type, stock_ledger.source_type) — always
    safe to reissue, and NEVER narrows an existing ENUM value (the full
    historical value set is preserved explicitly, including 'fg_item',
    which an earlier draft of this project once accidentally dropped —
    this migration is written so that mistake cannot repeat).
  - DROP FOREIGN KEY IF EXISTS followed by an unconditional ADD
    CONSTRAINT for the two foreign keys 0012 adds (fk_shipment_special_
    order_do, fk_sri_special_line) — MariaDB has no native "ADD
    CONSTRAINT IF NOT EXISTS ... FOREIGN KEY" (confirmed: a hard SQL
    syntax error on 10.11), but DROP FOREIGN KEY IF EXISTS is supported
    and safe to run whether or not the constraint already exists, so the
    pair always converges on exactly the same FK being present.

Tested against every plausible live drift state (see api/tests/
test-0013-live-schema-repair.sh in the source repository, not shipped in
this package): a fresh install, the historical "81133f0" and "7c30712"
revisions of 0012 applied live-style then repaired, and an already-fully-
current schema (0013 is a safe no-op there too, including when its own
raw SQL is reissued a second time). Schema equivalence to a clean
0001-0011 + current-final-0012 build was verified table-by-table. A
data-preservation test seeded one real row into every major business
table family (Regular PO, Production, FG, DO, Shipment, Special Order —
Users/Stores/Products already present) and confirmed byte-for-byte
identical content before and after 0013.

This is a SCHEMA-ONLY repair. No allocation logic, production formula,
DO rule, receipt rule, Driver flow, Regular PO behavior, stock ledger
semantics, Invoice, or Replacement/Reject logic changed — the
application code in this package is identical to what already shipped
in amor-factory-fg-allocation-bridge.zip. This package only makes the
LIVE DATABASE SCHEMA match that already-deployed code.

Once 0013 is applied, Produksi -> Order Masuk / Demand Tambahan (which
was rendering blank because it reaches SpecialOrderFgAllocationRepository,
whose query fails against a live database missing special_order_fg_
allocation entirely) works again, and existing orders such as
NPR-20260923-001 can allocate from General FG without requiring fake
production.
