# Amor Factory System — User / Driver Account Management Package

FILES-ONLY INCREMENTAL update for an existing Phase 5.5 deployment. NO
DATABASE MIGRATION in this package — the existing users/roles/user_roles
tables already supported everything required. This domain's document root
is public_html/factory/ — extract this ZIP positioned INSIDE
public_html/factory/ so it merges into your existing
public_html/factory/api/. It overwrites code files but NEVER includes
app/config/config.php, so your database credentials are untouched.

**Start here**: dist/README-FIRST-CPANEL-USER-MANAGEMENT.md (delivered
alongside this ZIP) has the full step-by-step, non-technical guide.

Quick facts:
- Log in as ADMIN: api/_admin-login/ (unchanged)
- New: User Management page (ADMIN-only): api/_users-uat/
- Create Driver A / Driver B here, assign the DRIVER role, then test their
  login at api/_driver-uat/login.php to resume Phase 5.5 UAT.
- The system will never let you end up with zero active ADMIN accounts —
  deactivating or de-roling the last active admin is blocked automatically.
- This package does NOT touch Dispatch Pool, Driver Claim, ShipmentService,
  Store Receipt, QR logic, Invoice, or any Phase 1-5.5 business rule.
