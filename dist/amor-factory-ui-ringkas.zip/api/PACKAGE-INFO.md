# Amor Factory System — UI ringkas + Omset Non-Toko + Mobile + Riwayat (includes migration 0017-0019)

Purely additive on top of 0001-0018 — three NULLable VARCHAR(150)
columns on production_run (created_by_operator_name,
submitted_by_operator_name, last_updated_by_operator_name).

- api/_admin-login/ now admits ADMIN, PPIC and PRODUCTION accounts and
  honours ?return= (only /api/_ui-preview/... targets).
- A PRODUCTION shared division account is asked "Siapa Anda?" after
  login; the name is stamped on every production create/edit/submit and
  shown on the Produksi page. ADMIN/PPIC are never asked.
- A PRODUCTION-only account can open only Produksi (+ Demand / Task per
  Divisi), FG & Packing, DO Replacement detail and Pengaturan.
- ADMIN sidebar gains "Kelola User" (the existing api/_users-uat/ tool).

This package also contains everything from 0017 (Bakery Portal) and 0018
(Invoice); a server still at 0016 is brought to 0019 by api/_upgrade/.
