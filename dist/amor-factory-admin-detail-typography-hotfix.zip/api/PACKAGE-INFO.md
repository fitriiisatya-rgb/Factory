# Amor Factory System — Admin Detail Typography Hotfix

FILES-ONLY hotfix. No new migration (0009 stays as the last one applied —
same schema as the previous Admin Receipt Evidence Thumbnail hotfix left
it).

Quick facts:
- Admin -> Konfirmasi Toko -> Detail's info-card values (Email
  Pengiriman's Status/Tujuan/Percobaan; the shipment summary's No. DO/
  Driver/Factory Asal/Waktu Berangkat; Konfirmasi Toko's Nama Penerima/
  Waktu Konfirmasi/Status) now render at 18px/weight 700 instead of the
  28px/weight 800 Dashboard-KPI headline size.
- A long email address now wraps inside its card instead of overflowing.
- The 3 card rows now collapse to fewer columns on iPad/mobile (an old
  inline style was silently blocking the existing responsive behavior).
- Every OTHER page's real KPI numbers (Dashboard, Delivery Order,
  FG & Packing, Pengiriman, Pesanan Toko, Produksi) are COMPLETELY
  UNCHANGED -- they never opted into this new modifier.
- The Admin UI's cache-busting version (ADMIN_ASSET_VERSION, added in
  the previous hotfix) was bumped, so a stale cached app.css can no
  longer mask this fix.
- NO business rule change: receipt quantities/status, evidence
  ownership, verification rules, email logic, and every server-side
  validation are all byte-for-byte unchanged (verified -- see the diff
  sanity checks in this build script).
- This package does NOT touch stock deduction, Dispatch Claim/Release
  concurrency, receipt confirm math validation, the DO receipt QR token
  mechanism, email logic, PO/Production/FG business logic, User
  Management, Invoice preview, Surat Jalan print, the evidence-thumbnail
  hotfix's own lightbox/grid, or the Store-side receipt page.
