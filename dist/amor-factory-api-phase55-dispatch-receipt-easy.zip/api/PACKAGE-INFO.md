# Amor Factory System — Phase 5.5 Dispatch Pool / Driver Claim / Store Receipt Package

INCREMENTAL update for an existing Phase 5 (Draft DO / Shipment) + UI/print/
invoice preview deployment. This domain's document root is
public_html/factory/ — extract this ZIP positioned INSIDE
public_html/factory/ so it merges into your existing
public_html/factory/api/. It overwrites code files but NEVER includes
app/config/config.php, so your database credentials are untouched.

**Start here**: dist/README-FIRST-CPANEL-PHASE55-DISPATCH-RECEIPT.md
(delivered alongside this ZIP) has the full step-by-step, non-technical
guide.

Quick facts:
- Log in as ADMIN: api/_admin-login/ (unchanged)
- Apply migration 0007 (ADDITIVE ONLY — 6 new tables + 1 new role, no
  existing table touched): api/_upgrade/
- New Driver portal (requires a user with the DRIVER role — create one the
  same way you create any user today, then assign the DRIVER role):
  api/_driver-uat/
- New PUBLIC Store Receipt portal (no login — reachable only via the QR
  now printed on each Draft/Preprint/Preprinted/Shipped DO):
  api/_receive/?token=...
- New Admin page "Konfirmasi Toko" inside the existing UI
  (api/_ui-preview/?page=konfirmasi-toko) — review store confirmations and
  verify discrepancies.
- Claiming a delivery task, viewing a route, or opening/scanning the
  receipt QR NEVER writes to stock or changes any DO/shipment — only a
  real "Konfirmasi Berangkat" (Confirm Departure) action creates a real
  Phase 5 shipment and deducts stock, exactly once, via the SAME
  ShipmentService Phase 5 already used for manual shipping.
- This package does NOT implement Invoice, Payment, Receivable aging, or
  the Phase 7 physical Retur/Reject return lifecycle.
