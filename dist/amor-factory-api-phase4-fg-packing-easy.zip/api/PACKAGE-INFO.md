# Amor Factory — Phase 4 Fast-Track FG/Packing Package

INCREMENTAL update for an existing Phase 3 (Production/SPK actual)
deployment. This domain's document root is public_html/factory/ — extract
this ZIP positioned INSIDE public_html/factory/ so it merges into your
existing public_html/factory/api/. It overwrites code files but NEVER
includes app/config/config.php, so your database credentials are
untouched.

**Start here**: dist/README-FIRST-CPANEL-PHASE4-FG-PACKING.md (delivered
alongside this ZIP) has the full step-by-step, non-technical guide. No SQL.
No CLI.

Quick facts:
- Log in as ADMIN: api/_admin-login/ (same as Phase 1/2/3)
- Apply migration 0005: api/_upgrade/ (adds factory_id to the ALREADY
  EXISTING location table, lifecycle columns to the ALREADY EXISTING
  fg_batch table, packed_qty/production_actual_snapshot to the ALREADY
  EXISTING fg_item table, and one new stock_ledger.source_type value —
  additive only, no table dropped, no Phase 0/1/2/3 data touched)
- Use FG/Packing: api/_fg-uat/ (requires ADMIN login; temporary — delete
  this folder once Phase 4 is reviewed and accepted)
- Only Production with status SUBMITTED is eligible as an FG source —
  draft/reopened Production contributes nothing until resubmitted.
- FG/Packing NEVER changes PO or Production data — both are always read
  live/snapshotted, never written to by this phase.
- Stock only decreases/increases via stock_ledger, written exactly once
  per FG submission (or once per correction's delta on a resubmit) —
  draft/reopened FG never touches stock.
- Still NOT implemented: Draft/Preprint DO, Shipment, delivery, Invoice,
  Payment, Return, Reject, or any cutover of the live Apps Script/Sheets
  frontend to MySQL. See docs/mysql-do-shipment-phase5-reservation-v1.md
  for the reserved Phase 5 design — nothing in it was touched by Phase 4.
