# Amor Factory System — Production Live PO Target Visibility (Bugfix)

NO DATABASE MIGRATION in this package — schema stays at 0013.

## Root cause

Real UAT (2026-09-26, Karangtengah): a Regular PO import succeeded
(Batch #3, target total = 39 — BOLLEN LILIT COKLAT 25 + CHOCO CUBE 12
14) but Produksi -> Ceklis Produksi -> 26 Sep 2026 -> Karangtengah showed
Target Produksi = 0 and every division row showed Target/Actual/Sisa = "-"
and status "Belum Dimulai" — including Roti & Bollen, which genuinely had
25 units of live PO demand.

produksi.php's own top KPI cards and division summary table derived
Target/Actual ONLY from a raw SQL join across production_run +
production_item — a division with no Production Draft yet contributed
NOTHING to either. Production Draft is the execution/realisasi document;
PO is the demand source. The correct live-target formula (po_awal +
po_revisi, PB excluded) already existed in
Production\ProductionTargetService and was already used correctly
elsewhere in this codebase (ProductionService::loadTarget()/
buildRunDto(), ProductionTaskService) — produksi.php's own overview was
the one place still bypassing it with its own separate, draft-dependent
query.

## Fix

produksi.php now calls the SAME ProductionTargetService::targetsByProduct()
every other authoritative target read in this codebase already uses,
grouped by division, for BOTH the top KPI cards and the division summary
table — this is always shown, whether or not a production_run exists for
that division/date. Actual/Sisa/Status still come from production_run/
production_item exactly as before (execution state only — never a second
target source; PO target and production_item target are never summed
together). ProductionService::classifyDisplayStatus() was made public so
produksi.php reuses the exact same not_produced/below_target/on_target/
overproduction classification the run-detail view already uses, instead
of duplicating it.

Division rows and the top KPI cards now always show a real number for
Target/Actual/Sisa — never a bare "-" — even when no draft exists yet.
Creating a draft (Buat/Buka Draft) initializes it from this exact same
live target (already true before this fix, via ProductionService::
createDraft()), so there is never a mismatch between what the overview
showed and what the new draft shows. A PO revision updates the overview's
live target immediately, with no page-reopen or draft-refresh action
needed — the same "never freeze target just because the page was opened"
principle production_item's own live-vs-snapshot model already enforced
for an existing draft.

10 new tests (LIVE-01..10) in Phase3ProductionTest.php cover: no PO ->
target 0, PO with no draft -> target visible, draft creation matches the
overview target exactly, PO revision reflected live, PB still ignored,
submitted production's actual/remaining still correct, Cibadak/Bolu same
behavior as Karangtengah, division filter shows only that division's
target, and no double counting across divisions when creating one
division's draft.
