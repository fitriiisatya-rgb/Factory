# Amor Factory — PHP/MySQL Preproduction Package

This is the Phase 0.5 easy-install package: infrastructure only (no
business modules, no legacy data import, no frontend cutover).

**Start here**: `dist/README-FIRST-CPANEL.md` (delivered alongside the ZIP
you extracted this from) has the full step-by-step, non-technical guide.

Quick facts:
- Setup wizard: `_setup/index.php` (delete this whole folder once done)
- Private config: `app/config/config.php` (you create this — see the guide)
- This file, `_setup/`, and `app/` are NOT the live application by
  themselves — they only install and verify the database. No frontend
  code lives here and none is touched by anything in this package.
