# Amor Factory System — Order Entry + Import PO UI/UX Rework

NO DATABASE MIGRATION in this package — schema stays at 0013.

## Part A — Pesanan Khusus Toko / Pesanan Non-Toko item entry

Replaces the old one-full-width-card-per-item layout with a compact,
scrollable spreadsheet-like table (Amor.createOrderItemGrid(), assets/js/
app.js): No / Item / Tipe / Divisi / Factory / Qty / Harga / Charge /
Extra Packaging / Subtotal / Catatan / Aksi. Bounded height (~520px) with
its own scroll, sticky header, and a sticky No/Item "frozen corner" so a
real 50+ item order stays usable and never turns into a giant vertical
page. Division/Factory stay read-only, auto-derived badges — routing is
never a manual selector.

product_id safety is unchanged: an existing-product row still goes
through the same createAutocomplete() as before (never free text) — the
autocomplete menu is now portaled to <body> with viewport-fixed
positioning so it is never clipped by the table's own scroll container,
and its selection is invalidated the instant the row's text is edited
again. Catatan is a compact button that opens a small popover/editor for
a long note; the payload field (specialNote) is unchanged.

## Part B — Import / Revisi PO Toko

api/_import-po/index.php now renders inside the SAME Amor Factory dark
navy shell every /api/_ui-preview/ page uses (sidebar, topbar, cards,
data-table, badges) instead of its own bare white "Phase 2 Fast-Track"
page — title renamed to "Import / Revisi PO Toko". The entry point
(Pesanan Toko -> PO Toko -> "Import / Revisi PO") and its URL are
unchanged. Every business rule is unchanged: Karangtengah (NO/KATEGORI/
KODE/NAMA PRODUK + per-store columns + TOTAL + revision/PB blocks) and
Cibadak (Kategori/Nama Produk + per-store columns + TOTAL PO) parsing,
PO Awal-only commit on initial upload, revision-as-full-snapshot (never
cumulative double counting), PB always ignored (display/reference only),
factory auto-detected from file content (never a manual selector), and
this page's own ADMIN + CSRF + session auth gate (never the shared
bootstrap.php's login-redirect variant, so its friendly "Login
diperlukan"/"Akses ditolak" messages are preserved). Three purely
additive, display-only fields (committedPoAwal/committedPoRevisi/
storesMapped) were added to PoImporter::import()'s already-existing
return array for a richer post-commit "PO berhasil disimpan" success
card — no existing key removed/renamed, no computation altered, safe for
every existing consumer of that return value (including the real
POST /api/po/import JSON endpoint, which now also returns these three
extra fields additively).
