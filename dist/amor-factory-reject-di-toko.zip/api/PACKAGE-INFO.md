# Amor Factory System — Reject di Toko + Stok Sisa + UI ringkas + Omset Non-Toko + Mobile + Riwayat (migrations up to 0020)

Migration 0020 is purely additive on top of 0001-0019: six columns on
retur_request (jenis, kondisi, exp_date, tindak_lanjut,
pengganti_order_id, invoice_id). Existing rows become jenis='retur'.

- Portal toko: menu "Lapor Barang" — REJECT (merah, rusak/jamur sebelum
  expired, tanggungan pabrik) vs RETUR (abu-abu, tidak laku, hanya dicatat).
- Admin: menu "Reject di Toko" — Potong invoice / Ganti barang.
- Invoice: Reject di Toko yang disetujui dipotong dari invoice toko berikutnya.

A server still at 0016-0019 is brought to 0020 by api/_upgrade/.
