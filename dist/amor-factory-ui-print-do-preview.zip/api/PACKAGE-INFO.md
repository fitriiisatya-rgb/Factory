# Amor Factory System — Print DO / Surat Jalan Redesign Preview Package

INCREMENTAL update for an existing Phase 5 (Draft DO / Shipment)
deployment. This domain's document root is public_html/factory/ —
extract this ZIP positioned INSIDE public_html/factory/ so it merges into
your existing public_html/factory/api/. It overwrites code files but
NEVER includes app/config/config.php, so your database credentials are
untouched.

**Start here**: dist/README-FIRST-CPANEL-PRINT-DO-REDESIGN.md (delivered
alongside this ZIP) has the full step-by-step, non-technical guide. No
SQL. No CLI. No migration to apply — this package changes no schema.

Quick facts:
- Log in as ADMIN: api/_admin-login/ (unchanged)
- New/redesigned print pages: api/_ui-preview/print-do.php (single DO)
  and api/_ui-preview/print-do-bulk.php (all DOs for a date+factory).
- The OLD print route, api/_do-uat/print.php, is untouched and still
  works as a fallback.
- Opening or printing a DO is READ-ONLY — it never changes DO status,
  version, or stock. Only the real Preprint/Ship actions (unchanged from
  Phase 5) do that.
- No PO/Production/FG/DO/Shipment business logic was changed, weakened,
  or duplicated by this package.
