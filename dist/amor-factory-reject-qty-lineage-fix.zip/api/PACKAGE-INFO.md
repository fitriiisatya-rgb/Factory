# Amor Factory System — Reject Quantity Lineage Fix (Replacement Reject Worklist)

Live-UAT blocker fix: CODE ONLY, no new migration.

## Root cause

Audited end to end (ReplacementRepository::findPendingDispositionItems()
-> ReplacementService::pendingDisposition() -> replacement-reject.php)
and proven with a live two-partial-shipment reproduction test
(REJECT-QTY-01..12): the reject quantity pipeline already carried the
real per-row value correctly — one row per shipment_receipt_item_id,
unique-keyed by shipment_item_id (two separate shipments can never
collide), no COUNT(*), no boolean cast, no hardcoded default anywhere.

The genuine gap: the "Tindak Lanjut Reject" worklist never showed WHICH
shipment/DO each pending row came from — so two rows for the same
store+product (e.g. a DO shipped in two separate partial batches) were
hard to tell apart at a glance.

## What changed

1. ReplacementRepository::findPendingDispositionItems() now also
   resolves each row's real doc_no across all three shipment sources
   (Regular DO, Replacement DO, Special Order DO) — display-only
   enrichment, the WHERE clause and one-row-per-receipt-item shape are
   unchanged.
2. ReplacementService::pendingDisposition()'s DTO now includes docNo
   alongside the existing shipmentId.
3. replacement-reject.php's worklist table now shows "No. DO" and
   "Shipment #" columns so Admin can immediately distinguish which
   shipment each reject qty belongs to.

## What did NOT change

- reject_qty itself, shipment/receipt confirmation, stock_ledger,
  FG, Production, DO planned qty, invoice logic, the Replacement
  allocation formula, and shipment allocation safety — none of these
  files were touched (enforced by this build script's own sanity
  guards).
- The decision-quantity input still defaults to and is capped at the
  FULL reported reject quantity — no partial-approval behavior was
  invented.

## Tests

REJECT-QTY-01..12 added to ProductionDivisionFgReworkTest.php,
including a live reproduction of the reported scenario (Shipment A:
sent 13/good 12/reject 1, Shipment B: sent 10/good 8/reject 2, both
against ONE DO) proving reject=2 reads, decides, and creates a
Replacement Demand as exactly 2 — never 1. Full regression green:
the PDFG/Special Order/Replacement Reject/FG-Allocation cascade
(135+35 tests) and Phase 5.5 (107/107 + full P55-24 stack), 0
failures.
