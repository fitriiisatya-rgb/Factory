# Amor Factory System — Production Flow Completion (migration 0012)

ONE NEW MIGRATION (0012) — additive only:
- special_order_item gains extra_packaging + fg_verified_qty (2 columns).
- special_order_do / special_order_do_item — a NEW, SEPARATE pair of
  tables for Pesanan Khusus Toko / Pesanan Non-Toko's own DO. Regular
  PO's delivery_order/delivery_order_item are completely untouched.
- shipment.source_type gains one new ENUM value + a nullable FK column
  (schema-ready extension point, not yet wired to a write path this
  phase — special_order_do's own status column is self-contained).

Quick facts:
- Ceklis Produksi bugfix: the item Target/Catatan columns and the notes
  save path now use the authoritative DTO/wire keys (liveTarget/notes),
  fixing both a display bug and a previously-silent notes-save bug.
- Existing-product search on Pesanan Khusus Toko / Pesanan Non-Toko is
  now a real searchable dropdown (Amor.createAutocomplete) — no native
  <datalist>, product_id is always authoritative, a selection is
  invalidated the moment the text is edited again.
- Money fields display "Rp46.000" style; storage stays plain numeric.
- Extra Packaging: a new per-item manual Rupiah field, added ONCE to the
  item subtotal (never multiplied by qty).
- Special/non-regular Production -> FG: special_order_item.aktual_produksi
  (migration 0011) stays the one authoritative Actual Produksi value;
  fg_verified_qty tracks how much of it has been confirmed FG-ready.
  Snapshot semantics (same convention as Actual/Reject) — never additive.
- Special-order FG stays ORDER-SPECIFIC in this phase — it does not post
  to the shared stock_ledger/fg_batch tables, so it can never silently
  become general warehouse stock or mix with Regular PO's FG.
- DO is separated by demand source: Pesanan Khusus Toko / Pesanan
  Non-Toko get their own DOK-{date}-{seq} documents from
  special_order_do — Regular PO's own DO/KRM/{seq}/{month}/{year}
  numbering and (tanggal,store_id) identity are entirely unaffected.
- Reuses the EXISTING dark navy Admin UI; new pages are added as tabs
  next to the existing Produksi/FG/DO pages, never a redesign.
