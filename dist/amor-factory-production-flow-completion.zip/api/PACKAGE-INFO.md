# Amor Factory System — Production Flow Completion (migration 0012, reworked)

This REPLACES an earlier draft of migration 0012 that was never applied
to any live database — corrected before deployment, not patched with a
0013 (per the task's own instruction). ONE migration (0012) — additive
only:
- special_order_item gains extra_packaging + fg_verified_qty (2 columns).
  allocated/shipped are NEVER a stored column — always the live SUM of
  the real child tables below, so nothing can drift out of sync.
- special_order_do / special_order_do_item / special_order_do_shipment_item
  — a NEW, SEPARATE set of tables for Pesanan Khusus Toko / Pesanan
  Non-Toko's own DO + real per-dispatch shipment lines. Regular PO's
  delivery_order/delivery_order_item/shipment_item are completely
  untouched.
- shipment gains special_order_do_id (nullable FK) + delivery_method/
  courier_provider/courier_name/external_order_reference/handover_note —
  and, unlike the earlier draft, this is now ACTUALLY WRITTEN TO on every
  real dispatch (no enum/FK left unwired).

CRITICAL DISPATCH RULE: DO creation, courier booking, and driver claim
NEVER reduce FG. FG is reduced ONLY when goods physically leave the
factory — Driver Internal's "Konfirmasi Berangkat" or External Courier's
"Barang Diserahkan ke Kurir" — and BOTH actions create a REAL shipment
row (never a fake parallel "shipped" status).

Quick facts:
- Ceklis Produksi bugfix, product autocomplete, Rp money formatting, and
  Extra Packaging are unchanged from the prior pass — see this package's
  own README for the full list.
- Delivery Method per DO: Driver Internal (default) or External Courier
  (Grab/GoSend/Lalamove/Other) — External Courier pickup is always FROM
  FACTORY; locked once any real shipment exists for that DO.
- An order may have MULTIPLE DOs over time — partial fulfillment (ship 5
  of 10 today, the remaining 5 tomorrow via a second DO) is fully
  supported; the first DO never permanently blocks the rest.
- FG double-consumption is actively prevented: DO creation checks live
  availability (fg_verified - already allocated), actual dispatch
  re-checks under a fresh row lock (fg_verified - already shipped), and
  FG Verified can never be reduced below what has already been shipped.
- DO status (Open/Partial/Shipped) is always DERIVED from real shipped
  quantities — never hand-set by a button click.
- The Driver Portal gets its own new "Khusus/Non-Toko" tab, completely
  separate from the existing pooled Regular-PO claim system — an
  External Courier DO can never appear there or be claimed by a driver.
- Special-order FG still stays ORDER-SPECIFIC — it never posts to the
  shared stock_ledger/fg_batch tables Regular PO's FG uses.
- Reuses the EXISTING dark navy Admin UI; new pages/tabs only, never a
  redesign.

Deferred by design this phase (documented, not a gap): per-line
shipment_receipt_item breakdown for a special-order shipment (blocked by
custom/catalog items having no real product_id — the shipment_receipt
HEADER confirmation is schema-compatible and can be wired in a focused
follow-up), the token-based Bakery receipt-confirmation ENTRY POINT
(currently Regular-DO-only), and Phase 6 invoice calculations.
