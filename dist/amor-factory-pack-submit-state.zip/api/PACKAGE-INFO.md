# Amor Factory System — Real Persisted Packing Submission State

Adds migration 0015 (ONE new, purely additive table:
fg_store_packing_submission) on top of the already-deployed DO Zero-Qty
+ Packing Submit Status package. See README-FIRST-CPANEL-0015-PACK-
SUBMIT-STATE.md for the cPanel deployment steps — THIS PASS REQUIRES
RUNNING A MIGRATION, unlike every prior hotfix in this series.

## Why

The prior pass's "Sudah Disubmit" inference (packed_qty >= target) was
logically wrong: a store's Packing can be legitimately, completely
submitted with packed BELOW target (Tidak Sesuai + a valid discrepancy
note) or even packed = 0. Quantities alone can never distinguish "never
submitted" from "submitted with a low/zero number".

## What changed

- New table fg_store_packing_submission (fg_batch_id, store_id, status
  submitted/stale, submitted_at, submitted_by, invalidated_at,
  updated_at) — the ONE authoritative "has this store's Packing been
  submitted" event, never a duplicate of any product quantity.
- New endpoint POST /api/fg/{id}/packing-submit (FgService::
  submitStorePacking()) — writes a store's rows AND records its
  submission atomically, in one transaction, never marked submitted
  before every row validates. submitted_by always comes from the
  authenticated session, never the request payload.
- Editing an already-submitted store's data via ANY path (most commonly
  Breakdown Toko's own save in FG Verifikasi) flips its record to
  'stale' — the UI then shows "Perlu Submit Ulang" until resubmitted.
- fg-packing.php's Packing UI now trusts this real, persisted state
  directly; the prior pass's entire client-side "packed_qty >= target" /
  "dirty flag" inference is removed.
- DoTargetService's zero-demand filter is corrected from
  "po_awal > 0 OR po_revisi > 0" to "(po_awal + po_revisi) > 0" — the
  OR-of-components version could wrongly keep a store whose PO Revisi
  was negative enough to drive its TRUE final demand to exactly 0 (a
  real, reachable state given how PO revisions and PoFileParser work).

## What did NOT change

Shipment allocation, stock ledger, store_fg_balance, the Regular
shipment guard, special reservation logic, DO business rules, Production
logic, and the pre-existing "Per Produk must be Breakdown Toko'd before
packing per store" rule are all byte-for-byte unchanged (enforced by
this build script's own diff sanity checks). The separate, whole-
document "Submit FG (Semua Toko)" action and its stock-posting logic are
completely untouched — per-store Packing submission never posts stock.

## Testing

Full existing regression suite re-run, 100% green (including a fix to
Phase0Test.php's own hardcoded total-table-count assertion: 63 -> 64,
to account for this pass's one new table). New PACK-SUBMIT-01..10 (a
real headless-Chromium click through Submit Packing with packed = target,
packed < target, and packed = 0 — all correctly showing Sudah Disubmit;
edited-then-resubmitted showing Perlu Submit Ulang then Sudah Disubmit
again; a second independent session seeing the same state; a failed
validation creating no submission row; a retried submit never doubling
packed_qty or posting stock) and DO-UI-06 (a po_awal=8/po_revisi=-8 line,
final demand exactly 0, correctly never surfaced or even persisted) all
pass.
