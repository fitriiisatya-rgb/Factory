<?php

declare(strict_types=1);

namespace Amor\Api\Controllers;

use Amor\Api\ApiException;
use Amor\Api\Auth;
use Amor\Api\Database;
use Amor\Api\Dispatch\EvidenceUploader;
use Amor\Api\Idempotency;
use Amor\Api\Request;
use Amor\Api\Response;
use Amor\Api\SpecialOrder\SpecialOrderFgAllocationService;
use Amor\Api\SpecialOrder\SpecialOrderRepository;
use Amor\Api\SpecialOrder\SpecialOrderService;
use PDO;

/**
 * JSON API for Pesanan Khusus Toko / Pesanan Non-Toko + Production
 * routing (migration 0010). Mirrors DoController/FgController's shape.
 */
final class SpecialOrderController
{
    private const EDITOR_ROLES = ['ADMIN', 'PPIC'];
    private const STATUS_UPDATE_ROLES = ['ADMIN', 'PPIC', 'PRODUCTION'];

    public static function catalog(Request $request): void
    {
        Auth::requireAuth();
        $service = new SpecialOrderService(Database::pdo());
        Response::json($service->listCatalog());
    }

    public static function index(Request $request): void
    {
        Auth::requireAuth();
        $service = new SpecialOrderService(Database::pdo());
        $filters = array_filter([
            'sourceType' => $request->query('sourceType'),
            'status' => $request->query('status'),
            'tanggal' => $request->query('tanggal'),
            'storeId' => $request->query('storeId') !== null ? (int) $request->query('storeId') : null,
        ], fn ($v) => $v !== null);
        Response::json($service->listOrders($filters));
    }

    public static function show(Request $request): void
    {
        Auth::requireAuth();
        $id = (int) $request->routeParams['id'];
        $service = new SpecialOrderService(Database::pdo());
        Response::json($service->getOrder($id));
    }

    /**
     * GET /api/admin/special-orders/attachments/{id} — streams ONE
     * Pesanan Khusus reference photo's bytes (migration 0017). Any
     * authenticated user may view it (same "every item/order-detail
     * reader" audience as show() above) — these are optional bakery-
     * submitted reference images, not a restricted-access evidence
     * record, so this is deliberately Auth::requireAuth() rather than
     * the stricter ADMIN-only gate ReceiptController::adminEvidence()
     * uses for store receipt evidence. The real filesystem path is never
     * exposed to the client — same streaming discipline as that method.
     */
    public static function attachment(Request $request): void
    {
        Auth::requireAuth();
        $attachmentId = (int) $request->routeParams['id'];
        $repo = new SpecialOrderRepository();
        $attachment = $repo->findAttachmentById(Database::pdo(), $attachmentId);
        if ($attachment === null) {
            throw new ApiException(404, 'NOT_FOUND', 'Lampiran tidak ditemukan');
        }
        $path = EvidenceUploader::absolutePath($attachment['file_path'], 'special-order-attachment');
        if (!is_file($path)) {
            throw new ApiException(404, 'NOT_FOUND', 'Berkas lampiran tidak ditemukan di server');
        }
        header('Content-Type: ' . $attachment['mime_type']);
        header('Content-Length: ' . (string) filesize($path));
        header('Cache-Control: private, max-age=3600');
        header('X-Content-Type-Options: nosniff');
        readfile($path);
    }

    public static function create(Request $request): void
    {
        $userId = Auth::requireRole(...self::EDITOR_ROLES);
        $input = $request->all();

        Idempotency::handle($request, 'POST /api/special-orders', function (PDO $pdo) use ($userId, $input, $request) {
            $service = new SpecialOrderService($pdo);
            $dto = $service->createOrder($input, $userId, $request->header('Idempotency-Key'));
            return [
                'status' => 200,
                'envelope' => ['ok' => true, 'data' => $dto],
                'recordType' => 'special_order',
                'recordKey' => (string) $dto['orderId'],
            ];
        });
    }

    public static function confirm(Request $request): void
    {
        $userId = Auth::requireRole(...self::EDITOR_ROLES);
        $id = (int) $request->routeParams['id'];
        $expectedVersion = self::requireInt($request->input('expectedVersion'), 'expectedVersion');

        Idempotency::handle($request, 'POST /api/special-orders/{id}/confirm', function (PDO $pdo) use ($request, $userId, $id, $expectedVersion) {
            $service = new SpecialOrderService($pdo);
            $dto = $service->confirmOrder($id, $expectedVersion, $userId, $request->header('Idempotency-Key'));
            return ['status' => 200, 'envelope' => ['ok' => true, 'data' => $dto], 'recordType' => 'special_order', 'recordKey' => (string) $id];
        });
    }

    public static function sendToProduction(Request $request): void
    {
        $userId = Auth::requireRole(...self::EDITOR_ROLES);
        $id = (int) $request->routeParams['id'];
        $expectedVersion = self::requireInt($request->input('expectedVersion'), 'expectedVersion');

        Idempotency::handle($request, 'POST /api/special-orders/{id}/send-to-production', function (PDO $pdo) use ($request, $userId, $id, $expectedVersion) {
            $service = new SpecialOrderService($pdo);
            $dto = $service->sendToProduction($id, $expectedVersion, $userId, $request->header('Idempotency-Key'));
            return ['status' => 200, 'envelope' => ['ok' => true, 'data' => $dto], 'recordType' => 'special_order', 'recordKey' => (string) $id];
        });
    }

    public static function updateStatus(Request $request): void
    {
        $userId = Auth::requireRole(...self::STATUS_UPDATE_ROLES);
        $id = (int) $request->routeParams['id'];
        $expectedVersion = self::requireInt($request->input('expectedVersion'), 'expectedVersion');
        $newStatus = (string) ($request->input('status') ?? '');

        Idempotency::handle($request, 'POST /api/special-orders/{id}/status', function (PDO $pdo) use ($request, $userId, $id, $expectedVersion, $newStatus) {
            $service = new SpecialOrderService($pdo);
            $dto = $service->updateStatus($id, $expectedVersion, $newStatus, $userId, $request->header('Idempotency-Key'));
            return ['status' => 200, 'envelope' => ['ok' => true, 'data' => $dto], 'recordType' => 'special_order', 'recordKey' => (string) $id];
        });
    }

    /**
     * POST /api/special-orders/{id}/actual — Task per Divisi's Actual/
     * Reject Produksi entry for special-order items. Uses
     * STATUS_UPDATE_ROLES (includes PRODUCTION), matching updateStatus()'s
     * own role set — this is the same production-floor action class.
     */
    public static function updateItemsActual(Request $request): void
    {
        $userId = Auth::requireRole(...self::STATUS_UPDATE_ROLES);
        $id = (int) $request->routeParams['id'];
        $expectedVersion = self::requireInt($request->input('expectedVersion'), 'expectedVersion');
        $items = (array) $request->input('items', []);

        $operatorName = Auth::currentOperatorName();

        Idempotency::handle($request, 'POST /api/special-orders/{id}/actual', function (PDO $pdo) use ($request, $userId, $id, $expectedVersion, $items, $operatorName) {
            $service = new SpecialOrderService($pdo);
            $dto = $service->updateItemsActual($id, $expectedVersion, $items, $userId, $request->header('Idempotency-Key'), $operatorName);
            return ['status' => 200, 'envelope' => ['ok' => true, 'data' => $dto], 'recordType' => 'special_order', 'recordKey' => (string) $id];
        });
    }

    public static function cancel(Request $request): void
    {
        $userId = Auth::requireRole(...self::EDITOR_ROLES);
        $id = (int) $request->routeParams['id'];
        $expectedVersion = self::requireInt($request->input('expectedVersion'), 'expectedVersion');
        $reason = (string) ($request->input('reason') ?? '');

        Idempotency::handle($request, 'POST /api/special-orders/{id}/cancel', function (PDO $pdo) use ($request, $userId, $id, $expectedVersion, $reason) {
            $service = new SpecialOrderService($pdo);
            $dto = $service->cancelOrder($id, $expectedVersion, $reason, $userId, $request->header('Idempotency-Key'));
            return ['status' => 200, 'envelope' => ['ok' => true, 'data' => $dto], 'recordType' => 'special_order', 'recordKey' => (string) $id];
        });
    }

    /** GET /api/special-orders/production-inbox — Production's "Order Masuk / Demand Tambahan" view. */
    public static function productionInbox(Request $request): void
    {
        Auth::requireAuth();
        $service = new SpecialOrderService(Database::pdo());
        $filters = array_filter([
            'factoryId' => $request->query('factoryId') !== null ? (int) $request->query('factoryId') : null,
            'divisionId' => $request->query('divisionId') !== null ? (int) $request->query('divisionId') : null,
            'tanggal' => $request->query('tanggal'),
            'status' => $request->query('status'),
            'sourceType' => $request->query('sourceType'),
        ], fn ($v) => $v !== null);
        Response::json($service->productionInbox($filters));
    }

    /** GET /api/special-orders/fg-eligible — FG source-verification inbox for special/non-regular orders. */
    public static function fgEligible(Request $request): void
    {
        Auth::requireAuth();
        $service = new SpecialOrderService(Database::pdo());
        $filters = array_filter([
            'factoryId' => $request->query('factoryId') !== null ? (int) $request->query('factoryId') : null,
            'divisionId' => $request->query('divisionId') !== null ? (int) $request->query('divisionId') : null,
            'tanggal' => $request->query('tanggal'),
            'sourceType' => $request->query('sourceType'),
        ], fn ($v) => $v !== null);
        Response::json($service->fgEligibleItems($filters));
    }

    /** POST /api/special-orders/items/{itemId}/verify-fg — Production → FG bridge for special/non-regular orders. */
    public static function verifyItemFg(Request $request): void
    {
        $userId = Auth::requireRole(...self::STATUS_UPDATE_ROLES);
        $itemId = (int) $request->routeParams['itemId'];
        $qty = (float) ($request->input('fgVerifiedQty') ?? 0);

        Idempotency::handle($request, 'POST /api/special-orders/items/{itemId}/verify-fg', function (PDO $pdo) use ($request, $userId, $itemId, $qty) {
            $service = new SpecialOrderService($pdo);
            $dto = $service->verifyItemFg($itemId, $qty, $userId, $request->header('Idempotency-Key'));
            return ['status' => 200, 'envelope' => ['ok' => true, 'data' => $dto], 'recordType' => 'special_order_item', 'recordKey' => (string) $itemId];
        });
    }

    /** POST /api/special-orders/items/{itemId}/allocate-fg — the "Alokasikan dari FG" operator action (Existing FG Allocation Bridge). ADMIN/PPIC only — allocation mutates availability for every other order, never a public/read-only role. */
    public static function allocateFg(Request $request): void
    {
        $userId = Auth::requireRole(...self::EDITOR_ROLES);
        $itemId = (int) $request->routeParams['itemId'];
        $qty = (float) ($request->input('qty') ?? 0);

        Idempotency::handle($request, 'POST /api/special-orders/items/{itemId}/allocate-fg', function (PDO $pdo) use ($request, $userId, $itemId, $qty) {
            $service = new SpecialOrderFgAllocationService($pdo);
            $dto = $service->allocate($itemId, $qty, $userId, $request->header('Idempotency-Key'));
            return ['status' => 200, 'envelope' => ['ok' => true, 'data' => $dto], 'recordType' => 'special_order_item', 'recordKey' => (string) $itemId];
        });
    }

    /** POST /api/special-order-fg-allocations/{id}/release — manual release of an unconsumed FG allocation. */
    public static function releaseFgAllocation(Request $request): void
    {
        $userId = Auth::requireRole(...self::EDITOR_ROLES);
        $id = (int) $request->routeParams['id'];

        Idempotency::handle($request, 'POST /api/special-order-fg-allocations/{id}/release', function (PDO $pdo) use ($request, $userId, $id) {
            $service = new SpecialOrderFgAllocationService($pdo);
            $dto = $service->release($id, $userId, $request->header('Idempotency-Key'));
            return ['status' => 200, 'envelope' => ['ok' => true, 'data' => $dto], 'recordType' => 'special_order_fg_allocation', 'recordKey' => (string) $id];
        });
    }

    private static function requireInt(mixed $v, string $field): int
    {
        if ($v === null || $v === '' || !is_numeric($v)) {
            throw new ApiException(400, 'INVALID_INPUT', "{$field} is required and must be numeric");
        }
        return (int) $v;
    }
}
