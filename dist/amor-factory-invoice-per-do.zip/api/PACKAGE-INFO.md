# Amor Factory System — Invoice per DO + Nota Potongan (migrations up to 0021)

Migration 0021 is purely additive: invoice.source_kind/source_ref_id and the
new nota_potongan / nota_potongan_item tables.

- Invoice: "Terbitkan semua" — one invoice per confirmed DO / DO Khusus /
  Mutasi masuk.
- Nota Potongan: approved Reject di Toko and Mutasi keluar credit the DO
  invoice the goods came from; the invoice itself never changes.
- Laporan Omset per toko = invoice − nota potongan.

A server still at 0016-0020 is brought to 0021 by api/_upgrade/.
