# Amor Factory System — Store Receipt Photo Evidence + Admin Verification Patch

Adds ONE additive migration (0008 — shipment_receipt_evidence). Everything
else in the schema is unchanged.

Quick facts:
- A discrepancy (Reject/Kurang > 0) confirmation from the store REQUIRES
  at least one photo before it can be submitted at all — server-side.
- Admin cannot verify a discrepancy receipt (old or new) until at least
  one evidence photo exists for it.
- The Admin Konfirmasi Toko list is now clickable into a full Detail page
  (items, receiver/note/time, evidence thumbnails, Verifikasi Selisih).
- A discrepancy receipt confirmed BEFORE this patch (no evidence) can
  have evidence attached by Admin, which then unblocks its own verify —
  its quantities are never touched.
- Uploaded photos are validated by real file content (never trusted
  client MIME/extension), capped at 5 MB / 3 files, stored with a random
  filename under a deny-all directory (api/uploads/receipt-evidence/),
  and only ever served through an ADMIN-authenticated route — never a
  direct URL.
- The Store Receipt page is now usable on a narrow phone screen (the
  Kurang column used to clip off-screen).
- This package does NOT touch stock deduction, Dispatch Claim/Release
  concurrency, receipt confirm math validation, the DO receipt QR token
  mechanism, PO/Production/FG business logic, User Management, Invoice
  preview, or Surat Jalan print.
