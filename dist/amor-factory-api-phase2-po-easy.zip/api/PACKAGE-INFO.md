# Amor Factory — Phase 2 Fast-Track PO Package

INCREMENTAL update for an existing Phase 1 (EASY V2) deployment. This
domain's document root is public_html/factory/ — extract this ZIP
positioned INSIDE public_html/factory/ so it merges into your existing
public_html/factory/api/. It overwrites code files but NEVER includes
app/config/config.php, so your database credentials are untouched.

**Start here**: dist/README-FIRST-CPANEL-PHASE2-PO.md (delivered alongside
this ZIP) has the full step-by-step, non-technical guide. No SQL. No CLI.

Quick facts:
- Log in as ADMIN: api/_admin-login/ (same as Phase 1 — reinstalled here
  only for a clean overwrite if you kept it; delete after Phase 2 if you
  no longer need it for anything else)
- Apply migration 0003: api/_upgrade/ (adds po_batch upload-provenance
  columns + a new po_import audit-history table — additive only)
- Upload/preview/import PO files: api/_import-po/ (requires ADMIN login;
  temporary — delete this folder once Phase 2 is reviewed and accepted)
- This package does NOT reinstall api/_import-master/ — if you deleted it
  after Phase 1, it stays deleted.
- Still NOT implemented: Production actual, FG, Packing, DO, Shipment,
  Stock ledger business flow, Invoice, Payment, Return, Reject, or any
  cutover of the live Apps Script/Sheets frontend to MySQL.
