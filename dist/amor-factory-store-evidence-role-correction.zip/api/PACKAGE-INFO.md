# Amor Factory System — Store Photo Evidence Role Correction

FILES-ONLY correction. No new migration (0008 stays as the last one
applied — same schema as the previous receipt-evidence-verification
patch left it).

Quick facts:
- Photo evidence is STORE evidence. Only the public Store Receipt
  portal (api/_receive/) ever uploads it.
- Admin's role is now strictly VIEW + VERIFY: the Admin Konfirmasi Toko
  Detail page shows whatever the store uploaded (or "Tidak tersedia" for
  a legacy pre-patch receipt) and never offers an upload control.
- The old POST /api/admin/receipts/{id}/evidence route is REMOVED
  entirely (404s like any unknown route), not just hidden from the UI.
- A legacy discrepancy receipt with no store evidence (e.g. a real-UAT
  row confirmed before this rule existed) stays PERMANENTLY blocked from
  verification — it is never repaired and Admin can never fabricate
  evidence on the store's behalf.
- The Store-side flow itself (mandatory photo on Reject/Kurang > 0,
  image validation, mobile camera/gallery upload, idempotency) is
  UNCHANGED by this package.
- This package does NOT touch stock deduction, Dispatch Claim/Release
  concurrency, receipt confirm math validation, the DO receipt QR token
  mechanism, PO/Production/FG business logic, User Management, Invoice
  preview, or Surat Jalan print.
