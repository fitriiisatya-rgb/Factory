# Amor Factory System — Hari Ini, Backup, Catatan Error (migrations up to 0025)

No new migration (0025 stays the latest).

- Hari Ini: Admin checklist (PO, divisi, FG, DO, kirim, toko, sistem).
- Pengaturan -> Sistem: daily automatic database backup (14 kept,
  download), cron script api/app/cli/backup.php, error log (+ optional
  e-mail via ERROR_ALERT_EMAIL).
- Field input: - / + buttons, one-tap reject reasons, "Biasa dibuat"
  products, tap your name at "Siapa Anda?".
- Includes everything up to the serah terima package.
