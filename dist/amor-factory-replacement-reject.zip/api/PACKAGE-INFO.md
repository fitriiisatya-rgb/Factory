# Amor Factory System — Replacement Reject End-to-End

Adds migration 0016 (additive: 4 new tables — replacement_demand,
replacement_demand_fg_allocation, replacement_do, replacement_do_
shipment_item — plus ADD COLUMN/widen-only ALTERs on shipment_receipt_
item, shipment, and stock_ledger) on top of the already-deployed Lock
Packing After Submit package. See README-FIRST-CPANEL-REPLACEMENT-
REJECT.md for the cPanel deployment steps — THIS PASS REQUIRES RUNNING A
MIGRATION.

## Why

When a store reports a shipment Reject, Admin previously had no way to
record an approved (possibly adjusted) reject quantity, no explicit final
disposition, and no tracked "make-good" demand if goods needed to be sent
again. Reject Final and Kirim Ulang / Ganti Produk are now explicit,
permanent, one-time Admin decisions.

## What changed

- Admin verifies a Reject, then must choose ONE disposition:
  - Reject Final / Tidak Diganti: factory absorbs the loss. No FG is
    restored, no PO/DO is touched, no Replacement Demand is ever created.
  - Kirim Ulang / Ganti Produk: creates a Replacement Demand for the
    Admin-approved qty (which may be less than what the store reported).
- "Check FG First": the new demand's own protected FG allocation
  (replacement_demand_fg_allocation) reserves whatever is TRULY free
  right now — physical stock minus every other active reservation
  (Special Order's own allocation, AND every Regular store's own
  still-unshipped Breakdown Toko commitment) — capped at the approved
  qty. Any shortfall becomes a real Production Need, entering Production
  under its own distinct Replacement Reject source, never merged into PO
  Reguler's own target.
- Once fully covered (FG allocation + verified production), a SEPARATE,
  no-price Replacement DO can be created and shipped (partial shipment
  supported), consuming ONLY that demand's own reservation/production
  headroom — never another store's or another order's FG.
- The Replacement's own delivery reuses the EXISTING store Receipt flow
  end to end (public token, Good/Reject/Shortage confirmation, Admin
  verify). A full Good receipt completes the demand; a Reject on the
  Replacement's OWN receipt never auto-creates another Replacement — it
  simply awaits another explicit Admin disposition, correctly chained
  back to the very first original reject for full traceability.
- The existing "true free FG" formula (already shared by Regular PO and
  Special Order) is widened so all three sources — Regular, Special, and
  Replacement — mutually protect each other's reservations; no existing
  call site needed any further change for this.

## What did NOT change

Original PO targets, original DO planned quantities, original shipment/
receipt history, and Final FG Submit's own stock-posting/finalization
logic are all byte-for-byte/behaviorally unchanged (enforced by this
build script's own diff sanity checks and by REPL-22/23/24's own tests).
Editing/resubmitting Replacement Packing/DO/shipment never posts stock
outside of the ONE real dispatch deduction per shipment, exactly like
every other source already in this system.

## Testing

Full existing regression suite re-run, 100% green. New REPL-01..25 (a
real end-to-end lifecycle: Reject Final creates nothing and restores
nothing; Check FG First covers a demand fully from free FG, partially,
or not at all, matching the task's own worked examples exactly;
Replacement allocation cannot steal an active Special Order allocation
nor another Regular store's own committed FG; two demands competing for
the same limited free FG pool never combine to oversubscribe it;
Production Need appears correctly under its own Replacement Reject
source; a separate no-price DO supports partial shipment consuming only
its own headroom, with physical stock decremented exactly once per real
dispatch; a full-Good receipt completes the demand; a Reject on the
replacement's own receipt never auto-chains; a second explicit Admin
disposition correctly chains to the original root; original PO/DO/
invoice data stays completely untouched throughout) all pass, alongside
an unauthorized-role check confirming server-side authorization is
authoritative regardless of what the Admin UI shows.
