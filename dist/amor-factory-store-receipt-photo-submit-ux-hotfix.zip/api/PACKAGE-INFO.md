# Amor Factory System — Store Receipt Photo Preview / Submit Button UX Hotfix

FILES-ONLY hotfix. No new migration (0009 stays as the last one applied —
same schema as the previous Store Evidence Role Correction patch left it).

Quick facts:
- Fixes the confirmed bug: removing the only/last evidence photo did not
  re-disable "Simpan Konfirmasi" for a still-invalid (discrepancy, zero
  evidence) receipt, because renderPreviews() never re-ran validate() after
  a removal. It now does, on every re-render.
- Removes capture="environment" from the evidence file input (kept
  accept="image/*" multiple) — a documented iOS Safari + multiple
  compatibility hazard; the native picker still offers the camera.
- Hardens the evidence photo preview CSS into an explicit bounded grid
  (fixed compact thumbnails, object-fit: cover, no overflow) plus a
  tap-to-enlarge lightbox, and adds cache-busting (?v=) to receipt.css/
  receipt.js so a stale cached copy on the real host can never mask this
  fix.
- NO business rule change: Diterima Baik + Reject + Kurang = Dikirim,
  mandatory photo on Reject/Kurang > 0, Store-only upload, Admin-only
  view+verify, and every server-side validation are all byte-for-byte
  unchanged (verified — see the diff sanity checks in this build script).
- This package does NOT touch stock deduction, Dispatch Claim/Release
  concurrency, receipt confirm math validation, the DO receipt QR token
  mechanism, PO/Production/FG business logic, User Management, Invoice
  preview, or Surat Jalan print.
