# Amor Factory System — Phase 4 FG Production Source Refresh Patch

FILES-ONLY INCREMENTAL patch for an existing Phase 5.5 + User Management
deployment. NO DATABASE MIGRATION in this package — fg_batch_source.
source_version and fg_item.production_actual_snapshot already existed
since migrations 0001/0005. This domain's document root is
public_html/factory/ — extract this ZIP positioned INSIDE
public_html/factory/ so it merges into your existing
public_html/factory/api/. It overwrites code files but NEVER includes
app/config/config.php, so your database credentials are untouched.

Quick facts:
- New button on an existing FG draft/reopened batch: "Refresh Produksi
  Terbaru" — safely re-pulls the latest SUBMITTED Production actuals into
  fg_item.production_actual_snapshot and fg_batch_source.source_version.
- NEVER changes FG Verified, Packed, or stock — refresh writes ZERO
  stock_ledger rows. Only Submit/Resubmit posts stock, exactly as before.
- If a refresh reveals FG Verified > the new Production Actual, the batch
  is blocked from submit (409 FG_EXCEEDS_PRODUCTION) until an admin lowers
  FG Verified — it is never auto-reduced.
- "Filter Divisi Sumber" is now disabled and relabeled once a batch
  already exists for that date/factory (it was always preview-only before
  a draft is created — this patch only makes that clearer in the UI).
- This package does NOT touch PO, Production semantics, Driver Claim,
  Dispatch Pool, ShipmentService, Store Receipt, Invoice preview, or User
  Management.
