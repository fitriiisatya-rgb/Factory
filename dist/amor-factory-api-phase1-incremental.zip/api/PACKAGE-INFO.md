# Amor Factory — Phase 1 Fast-Track Incremental Package

INCREMENTAL update for an existing Phase 0.5 deployment. Extract this ZIP
over your existing public_html/api/ — it overwrites code files but never
includes app/config/config.php, so your database credentials and
SETUP_TOKEN are untouched.

**Start here**: dist/README-FIRST-CPANEL-PHASE1.md (delivered alongside
this ZIP) has the full step-by-step, non-technical guide.

Quick facts:
- Apply the new migration: api/_upgrade/ (requires ADMIN login; safe to
  leave in place permanently — see its own header comment)
- Import master/identity data: api/_import-master/ (requires ADMIN login;
  delete this folder once Phase 1 is reviewed and accepted)
- Still NOT imported: PO, production, FG, DO, shipment, stock, invoice,
  payment, returns, sales. Still NOT connected to the live frontend.
